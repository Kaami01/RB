import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Product } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const store = searchParams.get("store")

    let query = `SELECT * FROM products`
    const conditions: string[] = []
    const values: any[] = []

    if (category && category !== "todos") {
      conditions.push(`category = $${values.length + 1}`)
      values.push(category)
    }

    if (store && store !== "todos") {
      conditions.push(`store = $${values.length + 1}`)
      values.push(store)
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(" AND ")}`
    }

    query += ` ORDER BY created_at DESC`

    const products = (await sql.unsafe(query, values)) as Product[]
    return NextResponse.json(products)
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { category, store, title, description, price, rating, reviews, image, link } = body

    if (!category || !store || !title || !description || !price || !link) {
      return NextResponse.json(
        {
          error: "Missing required fields: category, store, title, description, price, link",
        },
        { status: 400 },
      )
    }

    const products = (await sql`
      INSERT INTO products (category, store, title, description, price, rating, reviews, image, link)
      VALUES (${category}, ${store}, ${title}, ${description}, ${price}, ${rating || 5.0}, ${reviews || "0"}, ${image || ""}, ${link})
      RETURNING *
    `) as Product[]

    return NextResponse.json(products[0], { status: 201 })
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
  }
}
