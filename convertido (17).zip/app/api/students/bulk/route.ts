import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { sendEmail, createWelcomeEmailTemplate } from "@/lib/email"
import { generateRandomPassword, hashPassword } from "@/lib/password"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { students, send_emails = true } = body

    if (!Array.isArray(students) || students.length === 0) {
      return NextResponse.json({ error: "Lista de estudantes é obrigatória" }, { status: 400 })
    }

    const results = []
    const errors = []

    for (const studentData of students) {
      try {
        const { name, email, kirvano_order_id, kirvano_customer_id, phone } = studentData

        // Verificar se o email já existe
        const existingUser = await sql.query("SELECT id FROM users WHERE email = $1", [email])

        if (existingUser.length > 0) {
          errors.push({
            email,
            error: "Email já cadastrado no sistema",
          })
          continue
        }

        // Gerar senha aleatória
        const plainPassword = generateRandomPassword(12)
        const hashedPassword = await hashPassword(plainPassword)

        // Criar usuário no banco
        const newStudent = await sql.query(
          `INSERT INTO users (
            name, email, password_hash, role, status, 
            kirvano_order_id, kirvano_customer_id, phone
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
          RETURNING *`,
          [name, email, hashedPassword, "aluno", "active", kirvano_order_id, kirvano_customer_id, phone],
        )

        const student = newStudent[0]

        // Enviar email de boas-vindas se solicitado
        let emailSent = false
        if (send_emails) {
          const loginUrl = `${process.env.NEXT_PUBLIC_APP_URL}/aluno`

          const emailHtml = createWelcomeEmailTemplate({
            name: student.name,
            email: student.email,
            password: plainPassword,
            loginUrl,
          })

          const emailResult = await sendEmail({
            to: student.email,
            subject: "🎉 Bem-vindo à R2B Academy - Suas credenciais de acesso",
            html: emailHtml,
          })

          emailSent = emailResult.success
        }

        const { password_hash, ...studentResult } = student
        results.push({
          ...studentResult,
          email_sent: emailSent,
          temporary_password: plainPassword,
        })
      } catch (error) {
        errors.push({
          email: studentData.email,
          error: "Erro ao criar estudante",
        })
      }
    }

    return NextResponse.json({
      success: results.length,
      errors: errors.length,
      results,
      errors,
    })
  } catch (error) {
    console.error("Error creating students in bulk:", error)
    return NextResponse.json({ error: "Failed to create students" }, { status: 500 })
  }
}
