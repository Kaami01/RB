import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Ticket } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const user_id = searchParams.get("user_id")

    let query = `SELECT * FROM tickets`
    const conditions: string[] = []
    const values: any[] = []

    if (status && status !== "all") {
      conditions.push(`status = $${values.length + 1}`)
      values.push(status)
    }

    if (user_id) {
      conditions.push(`user_id = $${values.length + 1}`)
      values.push(user_id)
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(" AND ")}`
    }

    query += ` ORDER BY created_at DESC`

    const tickets = (await sql.unsafe(query, values)) as Ticket[]
    return NextResponse.json(tickets)
  } catch (error) {
    console.error("Error fetching tickets:", error)
    return NextResponse.json({ error: "Failed to fetch tickets" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { subject, category, description, user_name, user_id } = body

    // Validar campos obrigatórios
    if (!subject || !category || !description || !user_name || !user_id) {
      return NextResponse.json(
        {
          error: "Missing required fields: subject, category, description, user_name, user_id",
        },
        { status: 400 },
      )
    }

    const tickets = (await sql`
      INSERT INTO tickets (subject, category, description, user_name, user_id, status)
      VALUES (${subject}, ${category}, ${description}, ${user_name}, ${user_id}, 'open')
      RETURNING *
    `) as Ticket[]

    return NextResponse.json(tickets[0], { status: 201 })
  } catch (error) {
    console.error("Error creating ticket:", error)
    return NextResponse.json(
      {
        error: "Failed to create ticket",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
