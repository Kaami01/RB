import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Ticket } from "@/lib/db"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const tickets = (await sql`SELECT * FROM tickets WHERE id = ${id}`) as Ticket[]

    if (tickets.length === 0) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    return NextResponse.json(tickets[0])
  } catch (error) {
    console.error("Error fetching ticket:", error)
    return NextResponse.json({ error: "Failed to fetch ticket" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const body = await request.json()
    console.log("Updating ticket with data:", body)

    const { status, response } = body

    // Validar status - deve ser exatamente um dos valores permitidos pela constraint
    const validStatuses = ["open", "answered", "closed"]

    if (status && !validStatuses.includes(status)) {
      console.error("Invalid status provided:", status)
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(", ")}` },
        { status: 400 },
      )
    }

    const finalStatus = status || "open"
    console.log("Final status to update:", finalStatus)

    const tickets = (await sql`
      UPDATE tickets 
      SET status = ${finalStatus}, response = ${response || null}, updated_at = NOW() 
      WHERE id = ${id}
      RETURNING *
    `) as Ticket[]

    if (tickets.length === 0) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    console.log("Ticket updated successfully:", tickets[0])
    return NextResponse.json(tickets[0])
  } catch (error) {
    console.error("Error updating ticket:", error)
    return NextResponse.json(
      {
        error: "Failed to update ticket",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const tickets = (await sql`DELETE FROM tickets WHERE id = ${id} RETURNING *`) as Ticket[]

    if (tickets.length === 0) {
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    return NextResponse.json(tickets[0])
  } catch (error) {
    console.error("Error deleting ticket:", error)
    return NextResponse.json({ error: "Failed to delete ticket" }, { status: 500 })
  }
}
