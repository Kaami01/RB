import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Community } from "@/lib/db"

export async function GET() {
  try {
    const communities = (await sql`SELECT * FROM communities ORDER BY created_at DESC`) as Community[]
    return NextResponse.json(communities)
  } catch (error) {
    console.error("Error fetching communities:", error)
    return NextResponse.json({ error: "Failed to fetch communities" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { icon, title, description, members, online, is_vip } = body

    if (!icon || !title || !description || !members || !online) {
      return NextResponse.json(
        {
          error: "Missing required fields: icon, title, description, members, online",
        },
        { status: 400 },
      )
    }

    const communities = (await sql`
      INSERT INTO communities (icon, title, description, members, online, is_vip)
      VALUES (${icon}, ${title}, ${description}, ${members}, ${online}, ${is_vip || false})
      RETURNING *
    `) as Community[]

    return NextResponse.json(communities[0], { status: 201 })
  } catch (error) {
    console.error("Error creating community:", error)
    return NextResponse.json({ error: "Failed to create community" }, { status: 500 })
  }
}
