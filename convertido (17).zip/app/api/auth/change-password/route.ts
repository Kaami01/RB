import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { verifyPassword, hashPassword } from "@/lib/password"

export async function POST(request: NextRequest) {
  try {
    const { userId, currentPassword, newPassword } = await request.json()

    if (!userId || !currentPassword || !newPassword) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Buscar o usuário no banco
    const userResult = await sql`
      SELECT id, password_hash FROM users 
      WHERE id = ${userId} AND role = 'aluno'
    `

    if (userResult.length === 0) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    const user = userResult[0]

    // Verificar se a senha atual está correta
    const isCurrentPasswordValid = await verifyPassword(currentPassword, user.password_hash)

    if (!isCurrentPasswordValid) {
      return NextResponse.json({ error: "Senha atual incorreta" }, { status: 400 })
    }

    // Validar nova senha
    if (newPassword.length < 6) {
      return NextResponse.json({ error: "A nova senha deve ter pelo menos 6 caracteres" }, { status: 400 })
    }

    // Hash da nova senha
    const newPasswordHash = await hashPassword(newPassword)

    // Atualizar senha no banco
    await sql`
      UPDATE users 
      SET password_hash = ${newPasswordHash}, updated_at = NOW()
      WHERE id = ${userId}
    `

    return NextResponse.json({
      success: true,
      message: "Senha alterada com sucesso",
    })
  } catch (error) {
    console.error("Error changing password:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
