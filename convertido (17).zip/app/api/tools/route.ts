import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Tool } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const enabled = searchParams.get("enabled")

    let query = `SELECT * FROM tools`

    if (enabled !== null) {
      query += ` WHERE enabled = $1`
      const tools = (await sql.unsafe(query, [enabled === "true"])) as Tool[]
      return NextResponse.json(tools)
    }

    query += ` ORDER BY created_at DESC`
    const tools = (await sql`SELECT * FROM tools ORDER BY created_at DESC`) as Tool[]
    return NextResponse.json(tools)
  } catch (error) {
    console.error("Error fetching tools:", error)
    return NextResponse.json({ error: "Failed to fetch tools" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { icon, title, description, link, enabled } = body

    if (!icon || !title || !description || !link) {
      return NextResponse.json(
        {
          error: "Missing required fields: icon, title, description, link",
        },
        { status: 400 },
      )
    }

    const tools = (await sql`
      INSERT INTO tools (icon, title, description, link, enabled)
      VALUES (${icon}, ${title}, ${description}, ${link}, ${enabled !== false})
      RETURNING *
    `) as Tool[]

    return NextResponse.json(tools[0], { status: 201 })
  } catch (error) {
    console.error("Error creating tool:", error)
    return NextResponse.json({ error: "Failed to create tool" }, { status: 500 })
  }
}
