import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET() {
  const checks = {
    database_connection: false,
    tables_exist: false,
    data_seeded: false,
    environment_vars: false,
    api_endpoints: false,
  }

  const results = {
    status: "checking",
    checks,
    details: {} as any,
    errors: [] as string[],
  }

  try {
    // 1. Verificar variáveis de ambiente
    if (process.env.DATABASE_URL) {
      checks.environment_vars = true
      results.details.database_url = "✅ DATABASE_URL configurada"
    } else {
      results.errors.push("❌ DATABASE_URL não encontrada")
    }

    // 2. Testar conexão com banco
    try {
      const connectionTest = await sql`SELECT NOW() as current_time`
      checks.database_connection = true
      results.details.connection = `✅ Conectado ao banco - ${connectionTest[0].current_time}`
    } catch (error) {
      results.errors.push(`❌ Erro de conexão: ${error}`)
    }

    // 3. Verificar se as tabelas existem
    try {
      const tables = await sql`
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name IN ('users', 'tips', 'products', 'communities', 'tools', 'tickets')
        ORDER BY table_name
      `

      const expectedTables = ["communities", "products", "tickets", "tips", "tools", "users"]
      const existingTables = tables.map((t) => t.table_name).sort()

      if (expectedTables.every((table) => existingTables.includes(table))) {
        checks.tables_exist = true
        results.details.tables = `✅ Todas as tabelas existem: ${existingTables.join(", ")}`
      } else {
        const missingTables = expectedTables.filter((table) => !existingTables.includes(table))
        results.errors.push(`❌ Tabelas faltando: ${missingTables.join(", ")}`)
        results.details.tables = `Existentes: ${existingTables.join(", ")}`
      }
    } catch (error) {
      results.errors.push(`❌ Erro ao verificar tabelas: ${error}`)
    }

    // 4. Verificar se há dados iniciais
    try {
      const counts = await Promise.all([
        sql`SELECT COUNT(*) as count FROM tips`,
        sql`SELECT COUNT(*) as count FROM products`,
        sql`SELECT COUNT(*) as count FROM communities`,
        sql`SELECT COUNT(*) as count FROM tools`,
      ])

      const dataCounts = {
        tips: Number.parseInt(counts[0][0].count),
        products: Number.parseInt(counts[1][0].count),
        communities: Number.parseInt(counts[2][0].count),
        tools: Number.parseInt(counts[3][0].count),
      }

      if (Object.values(dataCounts).every((count) => count > 0)) {
        checks.data_seeded = true
        results.details.data = `✅ Dados iniciais encontrados: ${JSON.stringify(dataCounts)}`
      } else {
        results.errors.push(`❌ Algumas tabelas estão vazias: ${JSON.stringify(dataCounts)}`)
      }
    } catch (error) {
      results.errors.push(`❌ Erro ao verificar dados: ${error}`)
    }

    // 5. Verificar se APIs básicas funcionam
    try {
      const apiTests = await Promise.all([
        sql`SELECT * FROM tips LIMIT 1`,
        sql`SELECT * FROM products LIMIT 1`,
        sql`SELECT * FROM communities LIMIT 1`,
      ])

      checks.api_endpoints = true
      results.details.api = "✅ Consultas básicas funcionando"
    } catch (error) {
      results.errors.push(`❌ Erro nas consultas: ${error}`)
    }

    // Status geral
    const allChecksPass = Object.values(checks).every((check) => check === true)
    results.status = allChecksPass ? "healthy" : "issues_found"
  } catch (error) {
    results.status = "error"
    results.errors.push(`❌ Erro geral: ${error}`)
  }

  return NextResponse.json(results)
}
