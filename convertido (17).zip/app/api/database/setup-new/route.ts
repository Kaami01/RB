import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function POST(request: NextRequest) {
  console.log("Setting up new database...")

  try {
    // Verificar conexão com o banco
    await sql`SELECT 1`
    console.log("Database connection successful")

    // Criar tabela de usuários
    console.log("Creating users table...")
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'aluno' CHECK (role IN ('admin', 'aluno')),
        phone VARCHAR(20),
        cpf VARCHAR(14),
        birth_date DATE,
        cep VARCHAR(9),
        street VARCHAR(255),
        number VARCHAR(20),
        complement VARCHAR(100),
        neighborhood VARCHAR(100),
        city VARCHAR(100),
        state VARCHAR(2),
        country VARCHAR(100) DEFAULT 'Brasil',
        status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'pending')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Criar tabela de dicas
    console.log("Creating tips table...")
    await sql`
      CREATE TABLE IF NOT EXISTS tips (
        id SERIAL PRIMARY KEY,
        category VARCHAR(100) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        content TEXT,
        published BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Criar tabela de produtos
    console.log("Creating products table...")
    await sql`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        category VARCHAR(100) NOT NULL,
        store VARCHAR(100) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        price VARCHAR(50) NOT NULL,
        rating DECIMAL(2,1) DEFAULT 0.0,
        reviews VARCHAR(50) DEFAULT '0',
        image TEXT,
        link TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Criar tabela de comunidades
    console.log("Creating communities table...")
    await sql`
      CREATE TABLE IF NOT EXISTS communities (
        id SERIAL PRIMARY KEY,
        icon VARCHAR(50) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        members VARCHAR(50) DEFAULT '0',
        online VARCHAR(50) DEFAULT '0',
        is_vip BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Criar tabela de ferramentas
    console.log("Creating tools table...")
    await sql`
      CREATE TABLE IF NOT EXISTS tools (
        id SERIAL PRIMARY KEY,
        icon VARCHAR(50) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        link TEXT NOT NULL,
        enabled BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Criar tabela de tickets
    console.log("Creating tickets table...")
    await sql`
      CREATE TABLE IF NOT EXISTS tickets (
        id SERIAL PRIMARY KEY,
        subject VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        status VARCHAR(50) DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
        user_name VARCHAR(255) NOT NULL,
        user_id VARCHAR(100),
        response TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Criar índices
    console.log("Creating indexes...")
    await sql`CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)`
    await sql`CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)`
    await sql`CREATE INDEX IF NOT EXISTS idx_users_status ON users(status)`
    await sql`CREATE INDEX IF NOT EXISTS idx_tips_category ON tips(category)`
    await sql`CREATE INDEX IF NOT EXISTS idx_tips_published ON tips(published)`
    await sql`CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)`
    await sql`CREATE INDEX IF NOT EXISTS idx_communities_is_vip ON communities(is_vip)`
    await sql`CREATE INDEX IF NOT EXISTS idx_tools_enabled ON tools(enabled)`
    await sql`CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status)`
    await sql`CREATE INDEX IF NOT EXISTS idx_tickets_user_id ON tickets(user_id)`

    // Criar função para atualizar updated_at
    console.log("Creating update_updated_at_column function...")
    await sql`
      CREATE OR REPLACE FUNCTION update_updated_at_column()
      RETURNS TRIGGER AS $$
      BEGIN
          NEW.updated_at = CURRENT_TIMESTAMP;
          RETURN NEW;
      END;
      $$ language 'plpgsql'
    `

    // Criar triggers
    console.log("Creating triggers...")
    await sql`DROP TRIGGER IF EXISTS update_users_updated_at ON users`
    await sql`CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()`

    await sql`DROP TRIGGER IF EXISTS update_tips_updated_at ON tips`
    await sql`CREATE TRIGGER update_tips_updated_at BEFORE UPDATE ON tips FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()`

    await sql`DROP TRIGGER IF EXISTS update_products_updated_at ON products`
    await sql`CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()`

    await sql`DROP TRIGGER IF EXISTS update_communities_updated_at ON communities`
    await sql`CREATE TRIGGER update_communities_updated_at BEFORE UPDATE ON communities FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()`

    await sql`DROP TRIGGER IF EXISTS update_tools_updated_at ON tools`
    await sql`CREATE TRIGGER update_tools_updated_at BEFORE UPDATE ON tools FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()`

    await sql`DROP TRIGGER IF EXISTS update_tickets_updated_at ON tickets`
    await sql`CREATE TRIGGER update_tickets_updated_at BEFORE UPDATE ON tickets FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()`

    // Verificar se todas as tabelas foram criadas
    console.log("Verifying tables...")
    const tables = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('users', 'tips', 'products', 'communities', 'tools', 'tickets')
    `

    const tableNames = tables.map((t: any) => t.table_name)
    const allTablesCreated =
      tableNames.includes("users") &&
      tableNames.includes("tips") &&
      tableNames.includes("products") &&
      tableNames.includes("communities") &&
      tableNames.includes("tools") &&
      tableNames.includes("tickets")

    if (allTablesCreated) {
      console.log("All tables created successfully!")
      return NextResponse.json({
        success: true,
        message: "Database setup completed successfully",
        tables: tableNames,
      })
    } else {
      console.error("Some tables were not created:", {
        expected: ["users", "tips", "products", "communities", "tools", "tickets"],
        created: tableNames,
      })
      return NextResponse.json(
        {
          success: false,
          message: "Some tables were not created",
          created: tableNames,
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Error setting up database:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to setup database",
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
