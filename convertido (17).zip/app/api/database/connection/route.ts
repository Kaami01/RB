import { NextResponse } from "next/server"
import { testConnection } from "@/lib/db"

export async function GET() {
  try {
    const connectionTest = await testConnection()

    return NextResponse.json({
      ...connectionTest,
      timestamp: new Date().toISOString(),
      environment: {
        hasUrl: !!process.env.DATABASE_URL,
        hasPublicUrl: !!process.env.NEXT_PUBLIC_DATABASE_URL,
        nodeEnv: process.env.NODE_ENV,
      },
    })
  } catch (error) {
    console.error("Erro ao testar conexão:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro ao testar conexão com banco de dados",
        error: error instanceof Error ? error.message : "Erro desconhecido",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
