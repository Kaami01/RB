import { type NextRequest, NextResponse } from "next/server"
import { sendEmail } from "@/lib/email"

export async function POST(request: NextRequest) {
  try {
    const { to, subject } = await request.json()

    // Template de teste
    const testEmailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Teste de Configuração</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #2563eb, #4f46e5); color: white; padding: 30px; text-align: center; border-radius: 10px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎉 Teste de Configuração</h1>
            <p>Seu sistema de email está funcionando perfeitamente!</p>
          </div>
          <div style="padding: 30px; background: #f8fafc; border-radius: 10px; margin-top: 20px;">
            <h2>✅ Configuração Bem-sucedida</h2>
            <p>Este é um email de teste para verificar se a integração com o Resend está funcionando corretamente.</p>
            <p><strong>Data/Hora:</strong> ${new Date().toLocaleString()}</p>
            <p><strong>Sistema:</strong> R2B Academy</p>
          </div>
        </div>
      </body>
      </html>
    `

    const result = await sendEmail({
      to: to || "teste@exemplo.com",
      subject: subject || "Teste de Configuração R2B Academy",
      html: testEmailHtml,
    })

    if (result.success) {
      return NextResponse.json({
        success: true,
        message: "Email de teste enviado com sucesso!",
        data: result.data,
      })
    } else {
      return NextResponse.json({ success: false, error: result.error }, { status: 400 })
    }
  } catch (error: any) {
    console.error("Error in test email:", error)
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}
