"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Eye,
  EyeOff,
  Lock,
  Mail,
  X,
  Menu,
  Play,
  CheckCircle,
  Star,
  Shield,
  Users,
  Target,
  DollarSign,
  Phone,
  MessageCircle,
  Truck,
  Calculator,
  HeadphonesIcon,
  ArrowRight,
  Globe,
  BookOpen,
  Video,
  BarChart3,
  FileText,
  Download,
  Minus,
  Plus,
} from "lucide-react"

export default function HomePage() {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (
      (email === "admin@r2b.com.br" && password === "123456") ||
      (email === "aluno@r2b.com.br" && password === "123456")
    ) {
      const userData = {
        email,
        role: email.includes("admin") ? "admin" : "aluno",
        name: email.includes("admin") ? "Administrador" : "João Silva",
      }

      localStorage.setItem("r2b_user", JSON.stringify(userData))

      if (userData.role === "admin") {
        window.location.href = "/admin"
      } else {
        window.location.href = "/aluno"
      }
    } else {
      alert("Credenciais inválidas!")
    }
  }

  const setDemoCredentials = (type: "admin" | "aluno") => {
    if (type === "admin") {
      setEmail("admin@r2b.com.br")
      setPassword("123456")
    } else {
      setEmail("aluno@r2b.com.br")
      setPassword("123456")
    }
  }

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth" })
    setIsMenuOpen(false)
  }

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Clean Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                  <Globe className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-semibold text-gray-900">R2B Academy</span>
              </div>

              <nav className="hidden md:flex items-center gap-8">
                {[
                  { label: "Método", id: "metodo" },
                  { label: "Recursos", id: "recursos" },
                  { label: "Resultados", id: "resultados" },
                  { label: "Preços", id: "precos" },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
                  >
                    {item.label}
                  </button>
                ))}
              </nav>
            </div>

            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                onClick={() => setIsLoginModalOpen(true)}
                className="text-gray-600 hover:text-gray-900"
              >
                Entrar
              </Button>
              <Button onClick={() => scrollToSection("precos")} className="bg-blue-600 hover:bg-blue-700 text-white">
                Começar Agora
              </Button>
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 text-gray-600 hover:text-gray-900"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100">
            <div className="px-6 py-4 space-y-4">
              {[
                { label: "Método", id: "metodo" },
                { label: "Recursos", id: "recursos" },
                { label: "Resultados", id: "resultados" },
                { label: "Preços", id: "precos" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="block text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="pt-20 pb-32 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <Badge className="bg-blue-50 text-blue-700 border-blue-200 mb-8">
              Método comprovado por +15.000 brasileiros
            </Badge>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-gray-900 mb-8 leading-tight">
              Domine a arte da
              <span className="block bg-gradient-to-r from-blue-600 to-blue-700 bg-clip-text text-transparent">
                importação profissional
              </span>
            </h1>

            <p className="text-xl text-gray-600 mb-12 leading-relaxed max-w-3xl mx-auto">
              Aprenda o método completo para importar produtos com segurança, economizar até 70% em suas compras e criar
              uma fonte de renda adicional.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Button
                size="lg"
                onClick={() => scrollToSection("precos")}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-medium"
              >
                Começar Agora
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => scrollToSection("metodo")}
                className="border-gray-300 text-gray-700 hover:bg-gray-50 px-8 py-4 text-lg font-medium"
              >
                <Play className="mr-2 h-5 w-5" />
                Ver Demonstração
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              {[
                { number: "15.000+", label: "Alunos ativos" },
                { number: "R$ 2.3M", label: "Economizados" },
                { number: "98%", label: "Satisfação" },
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-gray-900 mb-1">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Overview */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Tudo que você precisa para importar com sucesso</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Um sistema completo e estruturado para transformar você em um importador profissional
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {[
              {
                icon: Target,
                title: "Pesquisa de Produtos",
                description: "Aprenda a identificar produtos vencedores com alta demanda e margem de lucro",
                features: ["Ferramentas de análise", "Validação de mercado", "Tendências globais"],
              },
              {
                icon: Calculator,
                title: "Cálculos Precisos",
                description: "Calculadora exclusiva para saber exatamente todos os custos envolvidos",
                features: ["Impostos detalhados", "Taxas alfandegárias", "Margem de lucro"],
              },
              {
                icon: Truck,
                title: "Logística Segura",
                description: "Processo completo de importação sem riscos e com máxima eficiência",
                features: ["Fornecedores confiáveis", "Documentação legal", "Rastreamento completo"],
              },
            ].map((feature, index) => {
              const Icon = feature.icon
              return (
                <Card key={index} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-8">
                    <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-6">
                      <Icon className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">{feature.title}</h3>
                    <p className="text-gray-600 mb-6">{feature.description}</p>
                    <ul className="space-y-2">
                      {feature.features.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-center gap-3 text-sm text-gray-600">
                          <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Method Section */}
      <section id="metodo" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <Badge className="bg-blue-50 text-blue-700 border-blue-200 mb-6">Metodologia Comprovada</Badge>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Um método estruturado em 6 etapas simples</h2>
              <p className="text-xl text-gray-600 mb-8">
                Desenvolvemos um sistema passo-a-passo que elimina as complexidades da importação e garante resultados
                consistentes.
              </p>

              <div className="space-y-6">
                {[
                  { step: "01", title: "Análise de Mercado", description: "Identifique oportunidades lucrativas" },
                  { step: "02", title: "Seleção de Produtos", description: "Escolha produtos com alta demanda" },
                  { step: "03", title: "Fornecedores Confiáveis", description: "Acesse nossa rede verificada" },
                  { step: "04", title: "Cálculos Precisos", description: "Use nossa calculadora exclusiva" },
                  { step: "05", title: "Processo de Importação", description: "Execute com segurança total" },
                  { step: "06", title: "Maximização de Lucros", description: "Otimize seus resultados" },
                ].map((item, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0">
                      {item.step}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">{item.title}</h4>
                      <p className="text-gray-600 text-sm">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="aspect-video bg-gray-900 rounded-2xl overflow-hidden shadow-xl">
                <div className="relative w-full h-full flex items-center justify-center">
                  <Button className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white border-2 border-white/50 rounded-full p-6">
                    <Play className="h-8 w-8" />
                  </Button>
                  <div className="absolute bottom-6 left-6 right-6">
                    <div className="bg-black/50 backdrop-blur-sm rounded-lg p-4">
                      <h4 className="text-white font-semibold mb-1">Masterclass: Fundamentos da Importação</h4>
                      <p className="text-gray-300 text-sm">32 minutos • Gratuito</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Resources Section */}
      <section id="recursos" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Recursos e ferramentas inclusos</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Acesso completo a todas as ferramentas e recursos necessários para seu sucesso
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: BookOpen,
                title: "Curso Completo",
                description: "120+ aulas em vídeo",
                details: "Conteúdo estruturado do básico ao avançado",
              },
              {
                icon: Calculator,
                title: "Calculadora R2B",
                description: "Ferramenta exclusiva",
                details: "Calcule custos e margem de lucro automaticamente",
              },
              {
                icon: Users,
                title: "Rede de Fornecedores",
                description: "500+ fornecedores",
                details: "Fornecedores verificados e confiáveis",
              },
              {
                icon: MessageCircle,
                title: "Comunidade VIP",
                description: "15.000+ membros",
                details: "Suporte e networking com outros importadores",
              },
              {
                icon: FileText,
                title: "Templates Legais",
                description: "Documentos prontos",
                details: "Contratos e documentação necessária",
              },
              {
                icon: BarChart3,
                title: "Relatórios de Mercado",
                description: "Análises mensais",
                details: "Tendências e oportunidades atualizadas",
              },
              {
                icon: HeadphonesIcon,
                title: "Suporte Direto",
                description: "Atendimento prioritário",
                details: "Tire dúvidas com nossa equipe especializada",
              },
              {
                icon: Download,
                title: "Material Extra",
                description: "E-books e guias",
                details: "Conteúdo complementar para download",
              },
            ].map((resource, index) => {
              const Icon = resource.icon
              return (
                <Card key={index} className="border-0 shadow-sm hover:shadow-md transition-shadow text-center">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <Icon className="h-6 w-6 text-blue-600" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">{resource.title}</h3>
                    <p className="text-blue-600 font-medium text-sm mb-2">{resource.description}</p>
                    <p className="text-gray-600 text-sm">{resource.details}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section id="resultados" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Resultados que falam por si</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Veja como nossos alunos estão transformando suas vidas financeiras
            </p>
          </div>

          {/* Success Stories */}
          <div className="grid lg:grid-cols-3 gap-8 mb-20">
            {[
              {
                name: "Ana Silva",
                role: "Empresária",
                location: "São Paulo, SP",
                result: "Economizou R$ 18.500 em 6 meses",
                quote:
                  "O método é incrível. Consegui importar todos os equipamentos da minha empresa pagando menos da metade do preço.",
                avatar: "AS",
              },
              {
                name: "Carlos Mendes",
                role: "Engenheiro",
                location: "Rio de Janeiro, RJ",
                result: "Faturou R$ 32.000 revendendo",
                quote:
                  "Comecei importando para uso próprio, hoje tenho uma renda extra consistente de mais de 30k por mês.",
                avatar: "CM",
              },
              {
                name: "Marina Costa",
                role: "Designer",
                location: "Belo Horizonte, MG",
                result: "Economizou R$ 12.300 no primeiro trimestre",
                quote: "Simples, prático e muito eficiente. Em 3 meses já tinha economizado mais de 12 mil reais.",
                avatar: "MC",
              },
            ].map((story, index) => (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                      {story.avatar}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{story.name}</h4>
                      <p className="text-gray-600 text-sm">{story.role}</p>
                      <p className="text-gray-500 text-sm">{story.location}</p>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-6 italic">"{story.quote}"</p>

                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <p className="text-green-800 font-semibold text-center">{story.result}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Stats Grid */}
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { number: "15.000+", label: "Alunos transformados", icon: Users },
              { number: "R$ 2.3M", label: "Total economizado", icon: DollarSign },
              { number: "98%", label: "Taxa de satisfação", icon: Star },
              { number: "120+", label: "Horas de conteúdo", icon: Video },
            ].map((stat, index) => {
              const Icon = stat.icon
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-blue-50 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="precos" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Escolha seu plano</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Acesso completo ao método que já transformou milhares de vidas
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Pro Plan */}
            <Card className="border-2 border-blue-500 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-blue-500 text-white">Mais Popular</Badge>
              </div>
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Profissional</h3>
                <p className="text-gray-600 mb-6">Para resultados acelerados</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-900">R$ 497</span>
                  <span className="text-gray-600 ml-2">ou 12x R$ 49,90</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {[
                    "Tudo do plano Básico",
                    "Rede de fornecedores VIP",
                    "Comunidade exclusiva",
                    "Suporte prioritário",
                    "Templates legais",
                    "Acesso vitalício",
                  ].map((feature, index) => (
                    <li key={index} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Começar Agora</Button>
              </CardContent>
            </Card>
          {/* Guarantee */}
          <div className="text-center mt-16">
            <div className="inline-flex items-center gap-3 bg-green-50 border border-green-200 rounded-lg px-6 py-4">
              <Shield className="h-6 w-6 text-green-600" />
              <span className="text-green-800 font-medium">Garantia de 30 dias ou seu dinheiro de volta</span>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Perguntas frequentes</h2>
            <p className="text-xl text-gray-600">Tire suas dúvidas sobre o R2B Academy</p>
          </div>

          <div className="space-y-4">
            {[
              {
                question: "Preciso ter experiência prévia com importação?",
                answer:
                  "Não! O R2B Academy foi criado especialmente para iniciantes. Começamos do zero absoluto e te levamos ao nível profissional passo a passo.",
              },
              {
                question: "Quanto posso economizar realmente?",
                answer:
                  "Nossos alunos economizam em média entre 50% a 70% em suas compras. A economia exata depende dos produtos escolhidos, mas garantimos resultados significativos.",
              },
              {
                question: "É legal importar para uso próprio?",
                answer:
                  "Sim, é 100% legal! Importar para uso pessoal é um direito garantido por lei no Brasil. Ensinamos todas as regras e procedimentos legais.",
              },
              {
                question: "Como funciona a garantia?",
                answer:
                  "Você tem 30 dias para testar o método. Se não ficar satisfeito, devolvemos 100% do seu dinheiro sem perguntas.",
              },
              {
                question: "Vou ter suporte durante o curso?",
                answer:
                  "Sim! Oferecemos suporte por email, comunidade exclusiva e, nos planos superiores, suporte prioritário e mentoria.",
              },
              {
                question: "Por quanto tempo terei acesso?",
                answer:
                  "Depende do plano escolhido. O plano Básico oferece 1 ano de acesso, enquanto os planos Profissional e Empresarial oferecem acesso vitalício.",
              },
            ].map((faq, index) => (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="p-0">
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full p-6 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                  >
                    <h3 className="font-semibold text-gray-900 pr-4">{faq.question}</h3>
                    {openFaq === index ? (
                      <Minus className="h-5 w-5 text-gray-500 flex-shrink-0" />
                    ) : (
                      <Plus className="h-5 w-5 text-gray-500 flex-shrink-0" />
                    )}
                  </button>
                  {openFaq === index && (
                    <div className="px-6 pb-6">
                      <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-blue-600">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Pronto para transformar sua vida financeira?</h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            Junte-se a mais de 15.000 brasileiros que já descobriram o poder da importação profissional
          </p>
          <Button
            size="lg"
            onClick={() => scrollToSection("precos")}
            className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-medium"
          >
            Começar Minha Jornada Agora
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Globe className="h-4 w-4 text-white" />
                </div>
                <span className="text-xl font-semibold">R2B Academy</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md">
                A plataforma de ensino em importação mais completa do Brasil. Transformando vidas através do
                conhecimento.
              </p>
              <div className="flex items-center gap-4">
                <Badge className="bg-blue-600 text-white">15.000+ Alunos</Badge>
                <Badge className="bg-gray-700 text-white">98% Satisfação</Badge>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Produto</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button onClick={() => scrollToSection("metodo")} className="hover:text-white transition-colors">
                    Método
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("recursos")} className="hover:text-white transition-colors">
                    Recursos
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("precos")} className="hover:text-white transition-colors">
                    Preços
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Suporte</h3>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>suporte@r2bacademy.com</span>
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>(11) 99999-9999</span>
                </li>
                <li className="flex items-center gap-2">
                  <MessageCircle className="h-4 w-4" />
                  <span>WhatsApp</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400">&copy; 2024 R2B Academy. Todos os direitos reservados.</p>
            <div className="flex items-center gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
                Política de Privacidade
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
                Termos de Uso
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Login Modal */}
      {isLoginModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-gray-900">Área do Aluno</CardTitle>
                <p className="text-sm text-gray-600">Acesse sua conta para continuar</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setIsLoginModalOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>

            <CardContent className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-blue-900 mb-3">Credenciais de Demonstração:</h3>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDemoCredentials("admin")}
                    className="flex-1 border-blue-200 text-blue-700 hover:bg-blue-50"
                  >
                    Admin
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDemoCredentials("aluno")}
                    className="flex-1 border-blue-200 text-blue-700 hover:bg-blue-50"
                  >
                    Aluno
                  </Button>
                </div>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium text-gray-900">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 border-gray-300 focus:border-blue-500"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="password" className="text-sm font-medium text-gray-900">
                    Senha
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10 border-gray-300 focus:border-blue-500"
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-1 top-1 h-8 w-8 p-0 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3">
                  Entrar
                </Button>

                <p className="text-center text-sm text-gray-600">
                  Não tem uma conta?{" "}
                  <span className="text-blue-600 cursor-pointer hover:underline font-medium">Entre em contato</span>
                </p>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Demo Info */}
      <div className="fixed bottom-4 right-4 bg-white border border-gray-200 rounded-lg p-4 max-w-sm shadow-lg z-30">
        <h3 className="font-semibold text-gray-900 mb-2">🎯 Demonstração</h3>
        <p className="text-sm text-gray-600 mb-3">Credenciais para teste:</p>
        <div className="text-xs text-gray-700 space-y-1 bg-gray-50 rounded p-3">
          <div>
            <strong>Admin:</strong> admin@r2b.com.br / 123456
          </div>
          <div>
            <strong>Aluno:</strong> aluno@r2b.com.br / 123456
          </div>
        </div>
      </div>
    </div>
  )
}
