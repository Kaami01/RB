"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { CheckCircle, XCircle, AlertCircle, Database, Settings, RefreshCw, Table } from "lucide-react"

interface ConnectionStatus {
  success: boolean
  message: string
  timestamp: string
  environment: {
    hasUrl: boolean
    hasUrl: boolean
    nodeEnv: string
  }
}

interface TableInfo {
  name: string
  exists: boolean
  count?: number
  error?: string
}

interface ColumnInfo {
  column_name: string
  data_type: string
  is_nullable: string
}

export default function DiagnosticsPage() {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus | null>(null)
  const [tables, setTables] = useState<TableInfo[]>([])
  const [columns, setColumns] = useState<ColumnInfo[]>([])
  const [missingColumns, setMissingColumns] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [setupLoading, setSetupLoading] = useState(false)
  const [fixColumnsLoading, setFixColumnsLoading] = useState(false)

  const checkConnection = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/database/connection")
      const data = await response.json()
      setConnectionStatus(data)
    } catch (error) {
      setConnectionStatus({
        success: false,
        message: "Erro ao conectar com a API",
        timestamp: new Date().toISOString(),
        environment: { hasUrl: false, hasPublicUrl: false, nodeEnv: "unknown" },
      })
    }
    setLoading(false)
  }

  const checkTables = async () => {
    const tableNames = ["tips", "products", "communities", "tools", "tickets", "students"]
    const tableResults: TableInfo[] = []

    for (const tableName of tableNames) {
      try {
        const response = await fetch(`/api/${tableName}`)
        if (response.ok) {
          const data = await response.json()
          tableResults.push({
            name: tableName,
            exists: true,
            count: Array.isArray(data) ? data.length : 0,
          })
        } else {
          const errorData = await response.json()
          tableResults.push({
            name: tableName,
            exists: false,
            error: errorData.error || "Erro desconhecido",
          })
        }
      } catch (error) {
        tableResults.push({
          name: tableName,
          exists: false,
          error: error instanceof Error ? error.message : "Erro de conexão",
        })
      }
    }

    setTables(tableResults)
  }

  const checkColumns = async () => {
    try {
      const response = await fetch("/api/database/check-columns")
      const data = await response.json()

      if (data.success) {
        setColumns(data.columns)
        setMissingColumns(data.missingColumns)
      } else {
        setColumns([])
        setMissingColumns([])
      }
    } catch (error) {
      console.error("Erro ao verificar colunas:", error)
      setColumns([])
      setMissingColumns([])
    }
  }

  const setupDatabase = async () => {
    setSetupLoading(true)
    try {
      const response = await fetch("/api/database/setup", { method: "POST" })
      const data = await response.json()

      if (data.success) {
        alert("Banco de dados configurado com sucesso!")
        checkTables()
      } else {
        alert(`Erro na configuração: ${data.message}`)
      }
    } catch (error) {
      alert("Erro ao configurar banco de dados")
    }
    setSetupLoading(false)
  }

  const fixColumns = async () => {
    setFixColumnsLoading(true)
    try {
      const response = await fetch("/api/database/fix-columns", { method: "POST" })
      const data = await response.json()

      if (data.success) {
        alert("Colunas corrigidas com sucesso!")
        checkColumns()
      } else {
        alert(`Erro na correção: ${data.error}`)
      }
    } catch (error) {
      alert("Erro ao corrigir colunas")
    }
    setFixColumnsLoading(false)
  }

  useEffect(() => {
    checkConnection()
    checkTables()
    checkColumns()
  }, [])

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Diagnóstico do Sistema</h1>
          <p className="text-muted-foreground">Verifique a configuração do banco de dados</p>
        </div>
        <Button
          onClick={() => {
            checkConnection()
            checkTables()
            checkColumns()
          }}
          disabled={loading}
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Atualizar
        </Button>
      </div>

      {/* Teste Rápido */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-blue-700">🚀 Teste Rápido</CardTitle>
          <CardDescription>Teste imediato da nova configuração</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Button onClick={checkConnection} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
              <Database className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
              Testar Conexão
            </Button>
            <Button onClick={checkTables} variant="outline" disabled={loading}>
              <Settings className="w-4 h-4 mr-2" />
              Verificar Tabelas
            </Button>
            <Button onClick={checkColumns} variant="outline" disabled={loading}>
              <Table className="w-4 h-4 mr-2" />
              Verificar Colunas
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Status da Conexão */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Status da Conexão
          </CardTitle>
          <CardDescription>Verificação da conexão com o banco de dados Neon</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {connectionStatus ? (
            <>
              <div className="flex items-center gap-2">
                {connectionStatus.success ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
                <span className={connectionStatus.success ? "text-green-700" : "text-red-700"}>
                  {connectionStatus.message}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <strong>DATABASE_URL:</strong>{" "}
                  <Badge variant={connectionStatus.environment.hasUrl ? "default" : "destructive"}>
                    {connectionStatus.environment.hasUrl ? "Configurada" : "Não encontrada"}
                  </Badge>
                </div>
                <div>
                  <strong>Ambiente:</strong> {connectionStatus.environment.nodeEnv}
                </div>
              </div>

              {!connectionStatus.success && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Como corrigir:</strong>
                    <ol className="list-decimal list-inside mt-2 space-y-1">
                      <li>Verifique se DATABASE_URL está no arquivo .env.local</li>
                      <li>Confirme se as credenciais do Neon estão corretas</li>
                      <li>Teste a conexão diretamente no painel do Neon</li>
                      <li>Verifique se o IP está na whitelist (se aplicável)</li>
                    </ol>
                  </AlertDescription>
                </Alert>
              )}
            </>
          ) : (
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Verificando conexão...</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Status das Tabelas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Status das Tabelas
          </CardTitle>
          <CardDescription>Verificação das tabelas necessárias no banco</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {tables.length > 0 ? (
            <>
              <div className="grid gap-2">
                {tables.map((table) => (
                  <div key={table.name} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex items-center gap-2">
                      {table.exists ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-500" />
                      )}
                      <span className="font-medium">{table.name}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {table.exists ? (
                        <Badge variant="outline">{table.count} registros</Badge>
                      ) : (
                        <span className="text-red-600">{table.error}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <Separator />

              <div className="flex gap-2">
                <Button onClick={setupDatabase} disabled={setupLoading}>
                  {setupLoading ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Database className="w-4 h-4 mr-2" />
                  )}
                  Configurar Banco
                </Button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Verificando tabelas...</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Status das Colunas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Table className="w-5 h-5" />
            Status das Colunas
          </CardTitle>
          <CardDescription>Verificação das colunas da tabela users</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {columns.length > 0 ? (
            <>
              <div className="grid grid-cols-3 gap-2">
                {columns.map((column) => (
                  <div key={column.column_name} className="p-2 border rounded">
                    <div className="font-medium">{column.column_name}</div>
                    <div className="text-xs text-muted-foreground">{column.data_type}</div>
                  </div>
                ))}
              </div>

              {missingColumns.length > 0 && (
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertCircle className="h-4 w-4 text-yellow-600" />
                  <AlertDescription>
                    <strong className="text-yellow-700">Colunas ausentes:</strong>
                    <div className="mt-1 text-sm text-yellow-600">{missingColumns.join(", ")}</div>
                  </AlertDescription>
                </Alert>
              )}

              <Separator />

              <div className="flex gap-2">
                <Button onClick={fixColumns} disabled={fixColumnsLoading} variant="outline">
                  {fixColumnsLoading ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Table className="w-4 h-4 mr-2" />
                  )}
                  Corrigir Colunas
                </Button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Verificando colunas...</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Informações de Configuração */}
      <Card>
        <CardHeader>
          <CardTitle>Configuração Recomendada</CardTitle>
          <CardDescription>Variáveis de ambiente necessárias</CardDescription>
        </CardHeader>
        <CardContent>
          <pre className="bg-muted p-4 rounded text-sm overflow-x-auto">
            {`# .env.local
DATABASE_URL="postgresql://usuario:senha@host/database?sslmode=require"
RESEND_API_KEY="re_xxxxxxxxxx"
EMAIL_FROM="R2B Academy <onboarding@resend.dev>"
NEXT_PUBLIC_APP_URL="http://localhost:3000"`}
          </pre>
        </CardContent>
      </Card>
    </div>
  )
}
