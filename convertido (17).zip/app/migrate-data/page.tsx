"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Database,
  Upload,
  CheckCircle,
  XCircle,
  AlertCircle,
  Loader2,
  Users,
  Lightbulb,
  Package,
  MessageSquare,
  Wrench,
  Ticket,
} from "lucide-react"

interface MigrationStatus {
  users: { count: number; status: "pending" | "running" | "completed" | "error"; error?: string }
  tips: { count: number; status: "pending" | "running" | "completed" | "error"; error?: string }
  products: { count: number; status: "pending" | "running" | "completed" | "error"; error?: string }
  communities: { count: number; status: "pending" | "running" | "completed" | "error"; error?: string }
  tools: { count: number; status: "pending" | "running" | "completed" | "error"; error?: string }
  tickets: { count: number; status: "pending" | "running" | "completed" | "error"; error?: string }
}

interface DatabaseStatus {
  connected: boolean
  tablesExist: boolean
  tables: string[]
  counts: Record<string, number>
}

export default function MigrateDataPage() {
  const [databaseStatus, setDatabaseStatus] = useState<DatabaseStatus | null>(null)
  const [migrationStatus, setMigrationStatus] = useState<MigrationStatus>({
    users: { count: 0, status: "pending" },
    tips: { count: 0, status: "pending" },
    products: { count: 0, status: "pending" },
    communities: { count: 0, status: "pending" },
    tools: { count: 0, status: "pending" },
    tickets: { count: 0, status: "pending" },
  })
  const [isRunning, setIsRunning] = useState(false)
  const [logs, setLogs] = useState<string[]>([])
  const [localStorageData, setLocalStorageData] = useState<Record<string, any[]>>({})

  const dataTypeIcons = {
    users: Users,
    tips: Lightbulb,
    products: Package,
    communities: MessageSquare,
    tools: Wrench,
    tickets: Ticket,
  }

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString()
    setLogs((prev) => [...prev, `[${timestamp}] ${message}`])
  }

  const checkDatabaseStatus = async () => {
    try {
      const response = await fetch("/api/database/run-script")
      const data = await response.json()
      setDatabaseStatus({
        connected: data.success,
        tablesExist: data.tablesExist || false,
        tables: data.tables || [],
        counts: data.counts || {},
      })
      addLog(`Database status: ${data.success ? "Connected" : "Disconnected"}`)
      addLog(`Tables exist: ${data.tablesExist ? "Yes" : "No"}`)
    } catch (error) {
      addLog(`Error checking database: ${error}`)
      setDatabaseStatus({
        connected: false,
        tablesExist: false,
        tables: [],
        counts: {},
      })
    }
  }

  const loadLocalStorageData = () => {
    const data: Record<string, any[]> = {}

    // Carregar dados do localStorage
    try {
      data.users = JSON.parse(localStorage.getItem("users") || "[]")
      data.tips = JSON.parse(localStorage.getItem("tips") || "[]")
      data.products = JSON.parse(localStorage.getItem("products") || "[]")
      data.communities = JSON.parse(localStorage.getItem("communities") || "[]")
      data.tools = JSON.parse(localStorage.getItem("tools") || "[]")
      data.tickets = JSON.parse(localStorage.getItem("tickets") || "[]")
    } catch (error) {
      addLog(`Error loading localStorage data: ${error}`)
    }

    setLocalStorageData(data)

    // Atualizar contadores
    setMigrationStatus((prev) => ({
      users: { ...prev.users, count: data.users?.length || 0 },
      tips: { ...prev.tips, count: data.tips?.length || 0 },
      products: { ...prev.products, count: data.products?.length || 0 },
      communities: { ...prev.communities, count: data.communities?.length || 0 },
      tools: { ...prev.tools, count: data.tools?.length || 0 },
      tickets: { ...prev.tickets, count: data.tickets?.length || 0 },
    }))

    addLog(
      `Loaded localStorage data: ${Object.entries(data)
        .map(([key, value]) => `${key}(${value?.length || 0})`)
        .join(", ")}`,
    )
  }

  const setupDatabase = async () => {
    try {
      addLog("Setting up database tables...")
      const response = await fetch("/api/database/run-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scriptName: "001-create-complete-database.sql" }),
      })

      const data = await response.json()
      if (data.success) {
        addLog("Database setup completed successfully")
        await checkDatabaseStatus()
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      addLog(`Error setting up database: ${error}`)
    }
  }

  const migrateDataType = async (dataType: keyof MigrationStatus) => {
    const data = localStorageData[dataType]
    if (!data || data.length === 0) {
      setMigrationStatus((prev) => ({
        ...prev,
        [dataType]: { ...prev[dataType], status: "completed" },
      }))
      addLog(`No ${dataType} data to migrate`)
      return
    }

    setMigrationStatus((prev) => ({
      ...prev,
      [dataType]: { ...prev[dataType], status: "running" },
    }))

    try {
      addLog(`Migrating ${data.length} ${dataType} records...`)

      const response = await fetch("/api/migrate-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dataType, data }),
      })

      const result = await response.json()

      if (result.success) {
        setMigrationStatus((prev) => ({
          ...prev,
          [dataType]: { ...prev[dataType], status: "completed" },
        }))
        addLog(`✅ Successfully migrated ${result.data.count} ${dataType} records`)
      } else {
        throw new Error(result.error)
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error"
      setMigrationStatus((prev) => ({
        ...prev,
        [dataType]: { ...prev[dataType], status: "error", error: errorMessage },
      }))
      addLog(`❌ Error migrating ${dataType}: ${errorMessage}`)
    }
  }

  const runFullMigration = async () => {
    if (!databaseStatus?.tablesExist) {
      addLog("❌ Database tables don't exist. Please setup database first.")
      return
    }

    setIsRunning(true)
    addLog("🚀 Starting full migration...")

    const dataTypes: (keyof MigrationStatus)[] = ["users", "tips", "products", "communities", "tools", "tickets"]

    for (const dataType of dataTypes) {
      await migrateDataType(dataType)
      // Pequena pausa entre migrações
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    setIsRunning(false)
    addLog("🎉 Migration completed!")

    // Verificar status final
    await checkDatabaseStatus()
  }

  const clearLocalStorage = () => {
    const dataTypes = ["users", "tips", "products", "communities", "tools", "tickets"]
    dataTypes.forEach((type) => localStorage.removeItem(type))
    addLog("🧹 LocalStorage cleared")
    loadLocalStorageData()
  }

  useEffect(() => {
    checkDatabaseStatus()
    loadLocalStorageData()
  }, [])

  const totalRecords = Object.values(migrationStatus).reduce((sum, item) => sum + item.count, 0)
  const completedRecords = Object.values(migrationStatus)
    .filter((item) => item.status === "completed")
    .reduce((sum, item) => sum + item.count, 0)
  const progress = totalRecords > 0 ? (completedRecords / totalRecords) * 100 : 0

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Database className="h-8 w-8" />
        <div>
          <h1 className="text-3xl font-bold">Migração de Dados</h1>
          <p className="text-muted-foreground">Migre todos os dados do localStorage para o banco de dados Neon</p>
        </div>
      </div>

      {/* Status do Banco de Dados */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Status do Banco de Dados
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            {databaseStatus?.connected ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : (
              <XCircle className="h-5 w-5 text-red-500" />
            )}
            <span>Conexão: {databaseStatus?.connected ? "Conectado" : "Desconectado"}</span>
          </div>

          <div className="flex items-center gap-2">
            {databaseStatus?.tablesExist ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : (
              <XCircle className="h-5 w-5 text-red-500" />
            )}
            <span>Tabelas: {databaseStatus?.tablesExist ? "Criadas" : "Não existem"}</span>
          </div>

          {databaseStatus?.tables && databaseStatus.tables.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {databaseStatus.tables.map((table) => (
                <Badge key={table} variant="outline">
                  {table}: {databaseStatus.counts[table] || 0}
                </Badge>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <Button onClick={checkDatabaseStatus} variant="outline" size="sm">
              Verificar Status
            </Button>
            {!databaseStatus?.tablesExist && (
              <Button onClick={setupDatabase} size="sm">
                Configurar Banco
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Status da Migração */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Status da Migração
          </CardTitle>
          <CardDescription>
            Progresso: {completedRecords}/{totalRecords} registros ({progress.toFixed(1)}%)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Progress value={progress} className="w-full" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(migrationStatus).map(([dataType, status]) => {
              const Icon = dataTypeIcons[dataType as keyof typeof dataTypeIcons]
              return (
                <Card key={dataType}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4" />
                        <span className="font-medium capitalize">{dataType}</span>
                      </div>
                      <Badge
                        variant={
                          status.status === "completed"
                            ? "default"
                            : status.status === "running"
                              ? "secondary"
                              : status.status === "error"
                                ? "destructive"
                                : "outline"
                        }
                      >
                        {status.status === "running" && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                        {status.status === "completed" && <CheckCircle className="h-3 w-3 mr-1" />}
                        {status.status === "error" && <XCircle className="h-3 w-3 mr-1" />}
                        {status.count} registros
                      </Badge>
                    </div>
                    {status.error && <p className="text-sm text-red-500 mt-2">{status.error}</p>}
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="flex gap-2">
            <Button
              onClick={runFullMigration}
              disabled={isRunning || !databaseStatus?.tablesExist}
              className="flex items-center gap-2"
            >
              {isRunning && <Loader2 className="h-4 w-4 animate-spin" />}
              Iniciar Migração Completa
            </Button>
            <Button onClick={loadLocalStorageData} variant="outline">
              Recarregar Dados
            </Button>
            <Button onClick={clearLocalStorage} variant="destructive">
              Limpar LocalStorage
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Logs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Logs da Migração
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-muted p-4 rounded-lg max-h-64 overflow-y-auto">
            {logs.length === 0 ? (
              <p className="text-muted-foreground">Nenhum log ainda...</p>
            ) : (
              logs.map((log, index) => (
                <div key={index} className="text-sm font-mono mb-1">
                  {log}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Alertas */}
      {!databaseStatus?.connected && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Não foi possível conectar ao banco de dados. Verifique suas configurações.
          </AlertDescription>
        </Alert>
      )}

      {databaseStatus?.connected && !databaseStatus?.tablesExist && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            As tabelas do banco de dados não existem. Execute a configuração do banco primeiro.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
