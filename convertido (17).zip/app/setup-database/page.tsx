"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Database,
  RefreshCw,
  Play,
  Server,
  FileCode,
  Loader2,
} from "lucide-react"

export default function SetupDatabasePage() {
  const [connectionStatus, setConnectionStatus] = useState<"checking" | "success" | "error" | null>(null)
  const [connectionDetails, setConnectionDetails] = useState<any>(null)
  const [setupStatus, setSetupStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [setupResult, setSetupResult] = useState<any>(null)
  const [seedStatus, setSeedStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [seedResult, setSeedResult] = useState<any>(null)
  const [logs, setLogs] = useState<string[]>([])

  useEffect(() => {
    checkConnection()
  }, [])

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`])
  }

  const checkConnection = async () => {
    setConnectionStatus("checking")
    addLog("Verificando conexão com o banco de dados...")

    try {
      const response = await fetch("/api/database/connection")
      const data = await response.json()

      if (data.success) {
        setConnectionStatus("success")
        setConnectionDetails(data)
        addLog("✅ Conexão com o banco de dados estabelecida com sucesso!")
      } else {
        setConnectionStatus("error")
        setConnectionDetails(data)
        addLog("❌ Erro ao conectar com o banco de dados: " + data.error)
      }
    } catch (error) {
      setConnectionStatus("error")
      setConnectionDetails({ error: "Erro ao verificar conexão" })
      addLog("❌ Erro ao verificar conexão com o banco de dados")
    }
  }

  const setupNewDatabase = async () => {
    setSetupStatus("loading")
    addLog("Iniciando configuração do banco de dados...")

    try {
      const response = await fetch("/api/database/setup-new", {
        method: "POST",
      })
      const data = await response.json()

      if (data.success) {
        setSetupStatus("success")
        setSetupResult(data)
        addLog("✅ Banco de dados configurado com sucesso!")
        addLog(`Tabelas criadas: ${data.tables.join(", ")}`)
      } else {
        setSetupStatus("error")
        setSetupResult(data)
        addLog("❌ Erro ao configurar banco de dados: " + data.message)
        if (data.error) {
          addLog("Detalhes do erro: " + data.error)
        }
      }
    } catch (error) {
      setSetupStatus("error")
      setSetupResult({ error: "Erro ao configurar banco de dados" })
      addLog("❌ Erro ao configurar banco de dados")
    }
  }

  const seedSampleData = async () => {
    setSeedStatus("loading")
    addLog("Inserindo dados de exemplo no banco de dados...")

    try {
      const response = await fetch("/api/database/seed-data", {
        method: "POST",
      })
      const data = await response.json()

      if (data.success) {
        setSeedStatus("success")
        setSeedResult(data)
        addLog("✅ Dados de exemplo inseridos com sucesso!")
        addLog(`Registros inseridos: ${JSON.stringify(data.counts)}`)
      } else {
        setSeedStatus("error")
        setSeedResult(data)
        addLog("❌ Erro ao inserir dados de exemplo: " + data.message)
        if (data.error) {
          addLog("Detalhes do erro: " + data.error)
        }
      }
    } catch (error) {
      setSeedStatus("error")
      setSeedResult({ error: "Erro ao inserir dados de exemplo" })
      addLog("❌ Erro ao inserir dados de exemplo")
    }
  }

  return (
    <div className="container mx-auto py-10 max-w-4xl">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">Configuração do Banco de Dados</CardTitle>
              <CardDescription>Configure seu banco de dados Neon para a R2B Academy</CardDescription>
            </div>
            <Database className="h-8 w-8 text-blue-500" />
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Status da Conexão */}
          <div>
            <h3 className="text-lg font-medium mb-3 flex items-center gap-2">
              <Server className="h-5 w-5 text-gray-500" />
              Status da Conexão
            </h3>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {connectionStatus === "checking" && <Loader2 className="h-5 w-5 animate-spin text-blue-500" />}
                  {connectionStatus === "success" && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                  {connectionStatus === "error" && <XCircle className="h-5 w-5 text-red-500" />}
                  <span className="font-medium">
                    {connectionStatus === "checking" && "Verificando conexão..."}
                    {connectionStatus === "success" && "Conexão estabelecida"}
                    {connectionStatus === "error" && "Erro de conexão"}
                    {connectionStatus === null && "Não verificado"}
                  </span>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={checkConnection}
                  disabled={connectionStatus === "checking"}
                >
                  <RefreshCw className={`h-4 w-4 mr-2 ${connectionStatus === "checking" ? "animate-spin" : ""}`} />
                  Testar Novamente
                </Button>
              </div>

              {connectionStatus === "success" && connectionDetails && (
                <div className="text-sm text-gray-600 space-y-1">
                  <p>
                    Banco de dados: <span className="font-medium">{connectionDetails.database}</span>
                  </p>
                  <p>
                    Versão: <span className="font-medium">{connectionDetails.version}</span>
                  </p>
                  <div className="flex items-center gap-2 mt-2">
                    <span>Tabelas:</span>
                    {connectionDetails.tablesExist ? (
                      <Badge variant="success" className="bg-green-100 text-green-800">
                        Existem
                      </Badge>
                    ) : (
                      <Badge variant="destructive" className="bg-red-100 text-red-800">
                        Não existem
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {connectionStatus === "error" && connectionDetails && (
                <Alert variant="destructive" className="mt-2">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Erro de conexão</AlertTitle>
                  <AlertDescription>
                    {connectionDetails.error || "Não foi possível conectar ao banco de dados."}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </div>

          {/* Configuração do Banco */}
          <div>
            <h3 className="text-lg font-medium mb-3 flex items-center gap-2">
              <FileCode className="h-5 w-5 text-gray-500" />
              Configuração do Banco
            </h3>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="font-medium">Criar Tabelas do Sistema</p>
                  <p className="text-sm text-gray-600">
                    Cria todas as tabelas necessárias para o funcionamento do sistema
                  </p>
                </div>

                <Button
                  onClick={setupNewDatabase}
                  disabled={setupStatus === "loading" || connectionStatus !== "success"}
                >
                  {setupStatus === "loading" ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Criando...
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Criar Tabelas
                    </>
                  )}
                </Button>
              </div>

              {setupStatus === "success" && (
                <Alert className="bg-green-50 border-green-200 text-green-800">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>Configuração concluída</AlertTitle>
                  <AlertDescription>Todas as tabelas foram criadas com sucesso.</AlertDescription>
                </Alert>
              )}

              {setupStatus === "error" && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Erro na configuração</AlertTitle>
                  <AlertDescription>
                    {setupResult?.message || "Ocorreu um erro ao configurar o banco de dados."}
                    {setupResult?.error && (
                      <div className="mt-2 text-sm">
                        <strong>Detalhes:</strong> {setupResult.error}
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
              )}

              <Separator className="my-4" />

              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Inserir Dados de Exemplo</p>
                  <p className="text-sm text-gray-600">Popula o banco com dados de exemplo para testes</p>
                </div>

                <Button
                  variant="outline"
                  onClick={seedSampleData}
                  disabled={seedStatus === "loading" || setupStatus !== "success"}
                >
                  {seedStatus === "loading" ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Inserindo...
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Inserir Dados
                    </>
                  )}
                </Button>
              </div>

              {seedStatus === "success" && (
                <Alert className="bg-green-50 border-green-200 text-green-800 mt-4">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertTitle>Dados inseridos</AlertTitle>
                  <AlertDescription>
                    Dados de exemplo foram inseridos com sucesso.
                    {seedResult?.counts && (
                      <div className="mt-2 grid grid-cols-3 gap-2 text-sm">
                        <div>
                          Usuários: <strong>{seedResult.counts.users_count}</strong>
                        </div>
                        <div>
                          Dicas: <strong>{seedResult.counts.tips_count}</strong>
                        </div>
                        <div>
                          Produtos: <strong>{seedResult.counts.products_count}</strong>
                        </div>
                        <div>
                          Comunidades: <strong>{seedResult.counts.communities_count}</strong>
                        </div>
                        <div>
                          Ferramentas: <strong>{seedResult.counts.tools_count}</strong>
                        </div>
                        <div>
                          Tickets: <strong>{seedResult.counts.tickets_count}</strong>
                        </div>
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
              )}

              {seedStatus === "error" && (
                <Alert variant="destructive" className="mt-4">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Erro ao inserir dados</AlertTitle>
                  <AlertDescription>
                    {seedResult?.message || "Ocorreu um erro ao inserir os dados de exemplo."}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </div>

          {/* Logs */}
          <div>
            <h3 className="text-lg font-medium mb-3">Logs</h3>
            <div className="bg-gray-900 text-gray-100 p-4 rounded-lg h-48 overflow-y-auto font-mono text-sm">
              {logs.length === 0 ? (
                <p className="text-gray-500">Nenhum log disponível</p>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="mb-1">
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex justify-between border-t pt-6">
          <div className="text-sm text-gray-500">
            <p>
              Certifique-se de que a variável <code>DATABASE_URL</code> está configurada no seu arquivo{" "}
              <code>.env.local</code>
            </p>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => (window.location.href = "/admin")}>
              Ir para Admin
            </Button>
            <Button variant="outline" onClick={() => (window.location.href = "/aluno")}>
              Ir para Portal
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
