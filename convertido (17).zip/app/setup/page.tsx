"use client"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { CheckCircle, XCircle, AlertCircle, Mail, Database, Globe, Key } from "lucide-react"

export default function SetupPage() {
  const [config, setConfig] = useState({
    resendApiKey: "",
    emailFrom: "",
    appUrl: "",
    databaseUrl: "",
  })

  const [testResults, setTestResults] = useState({
    database: null as boolean | null,
    resend: null as boolean | null,
    email: null as boolean | null,
  })

  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // Carregar configurações atuais
    setConfig({
      resendApiKey: process.env.NEXT_PUBLIC_RESEND_API_KEY || "",
      emailFrom: process.env.NEXT_PUBLIC_EMAIL_FROM || "",
      appUrl: process.env.NEXT_PUBLIC_APP_URL || "",
      databaseUrl: process.env.NEXT_PUBLIC_DATABASE_URL ? "Configurado" : "",
    })
  }, [])

  const testDatabaseConnection = async () => {
    try {
      const response = await fetch("/api/database/status")
      const result = await response.json()
      setTestResults((prev) => ({ ...prev, database: response.ok }))

      if (response.ok) {
        toast({
          title: "✅ Banco de dados conectado!",
          description: `${result.tables?.length || 0} tabelas encontradas.`,
        })
      } else {
        toast({
          title: "❌ Erro na conexão",
          description: "Verifique as credenciais do banco.",
          variant: "destructive",
        })
      }
    } catch (error) {
      setTestResults((prev) => ({ ...prev, database: false }))
      toast({
        title: "❌ Erro na conexão",
        description: "Não foi possível conectar ao banco.",
        variant: "destructive",
      })
    }
  }

  const testResendConnection = async () => {
    try {
      // Teste simples de validação da API key
      const isValidKey = config.resendApiKey.startsWith("re_") && config.resendApiKey.length > 20
      setTestResults((prev) => ({ ...prev, resend: isValidKey }))

      if (isValidKey) {
        toast({
          title: "✅ Resend API configurado!",
          description: "Chave API válida detectada.",
        })
      } else {
        toast({
          title: "❌ Chave API inválida",
          description: "Verifique sua chave do Resend.",
          variant: "destructive",
        })
      }
    } catch (error) {
      setTestResults((prev) => ({ ...prev, resend: false }))
    }
  }

  const sendTestEmail = async () => {
    if (!config.emailFrom) {
      toast({
        title: "❌ Email não configurado",
        description: "Configure o EMAIL_FROM primeiro.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/test-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: "teste@exemplo.com", // Email de teste
          subject: "Teste de Configuração R2B Academy",
        }),
      })

      const result = await response.json()
      setTestResults((prev) => ({ ...prev, email: response.ok }))

      if (response.ok) {
        toast({
          title: "✅ Email de teste enviado!",
          description: "Configuração do Resend funcionando.",
        })
      } else {
        toast({
          title: "❌ Erro no envio",
          description: result.error || "Verifique as configurações.",
          variant: "destructive",
        })
      }
    } catch (error) {
      setTestResults((prev) => ({ ...prev, email: false }))
      toast({
        title: "❌ Erro no teste",
        description: "Não foi possível testar o email.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusIcon = (status: boolean | null) => {
    if (status === null) return <AlertCircle className="h-5 w-5 text-gray-400" />
    if (status === true) return <CheckCircle className="h-5 w-5 text-green-500" />
    return <XCircle className="h-5 w-5 text-red-500" />
  }

  const getStatusBadge = (status: boolean | null) => {
    if (status === null) return <Badge variant="outline">Não testado</Badge>
    if (status === true) return <Badge className="bg-green-100 text-green-700">Funcionando</Badge>
    return <Badge className="bg-red-100 text-red-700">Com erro</Badge>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">🚀 Configuração R2B Academy</h1>
          <p className="text-xl text-gray-600">Configure sua plataforma em poucos passos</p>
        </div>

        {/* Status Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Database className="h-5 w-5 text-blue-600" />
                Banco de Dados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                {getStatusIcon(testResults.database)}
                {getStatusBadge(testResults.database)}
              </div>
              <Button onClick={testDatabaseConnection} className="w-full" variant="outline">
                Testar Conexão
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Key className="h-5 w-5 text-purple-600" />
                Resend API
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                {getStatusIcon(testResults.resend)}
                {getStatusBadge(testResults.resend)}
              </div>
              <Button onClick={testResendConnection} className="w-full" variant="outline">
                Validar API Key
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Mail className="h-5 w-5 text-green-600" />
                Envio de Email
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                {getStatusIcon(testResults.email)}
                {getStatusBadge(testResults.email)}
              </div>
              <Button onClick={sendTestEmail} className="w-full" variant="outline" disabled={isLoading}>
                {isLoading ? "Enviando..." : "Testar Email"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Configuration Guide */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">📋 Guia de Configuração</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1 */}
            <div className="border-l-4 border-blue-500 pl-6">
              <h3 className="text-lg font-semibold mb-2">1. Configure o Resend</h3>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="resend-key">RESEND_API_KEY</Label>
                  <Input
                    id="resend-key"
                    value={config.resendApiKey}
                    onChange={(e) => setConfig((prev) => ({ ...prev, resendApiKey: e.target.value }))}
                    placeholder="re_123456789_SuaChaveAquiDoResend"
                    className="font-mono"
                  />
                  <p className="text-sm text-gray-600 mt-1">
                    Obtenha sua chave em:{" "}
                    <a
                      href="https://resend.com/api-keys"
                      target="_blank"
                      className="text-blue-600 underline"
                      rel="noreferrer"
                    >
                      resend.com/api-keys
                    </a>
                  </p>
                </div>

                <div>
                  <Label htmlFor="email-from">EMAIL_FROM</Label>
                  <Input
                    id="email-from"
                    value={config.emailFrom}
                    onChange={(e) => setConfig((prev) => ({ ...prev, emailFrom: e.target.value }))}
                    placeholder="R2B Academy <onboarding@resend.dev>"
                    className="font-mono"
                  />
                  <p className="text-sm text-gray-600 mt-1">
                    Use <code className="bg-gray-100 px-1 rounded">onboarding@resend.dev</code> para testes ou configure
                    seu domínio
                  </p>
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="border-l-4 border-green-500 pl-6">
              <h3 className="text-lg font-semibold mb-2">2. Exemplo de .env.local</h3>
              <pre className="bg-gray-100 p-4 rounded-lg text-sm overflow-x-auto">
                {`# Configurações de email com Resend
RESEND_API_KEY="re_123456789_SuaChaveAquiDoResend"
EMAIL_FROM="R2B Academy <onboarding@resend.dev>"

# URL da aplicação
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Banco de dados (já configurado)
DATABASE_URL="postgresql://..."
DATABASE_URL_UNPOOLED="postgresql://..."`}
              </pre>
            </div>

            {/* Step 3 */}
            <div className="border-l-4 border-purple-500 pl-6">
              <h3 className="text-lg font-semibold mb-2">3. Domínio Personalizado (Opcional)</h3>
              <p className="text-gray-600 mb-2">Para usar seu próprio domínio no email:</p>
              <ol className="list-decimal list-inside space-y-1 text-sm text-gray-600">
                <li>
                  Acesse{" "}
                  <a
                    href="https://resend.com/domains"
                    target="_blank"
                    className="text-blue-600 underline"
                    rel="noreferrer"
                  >
                    resend.com/domains
                  </a>
                </li>
                <li>Adicione seu domínio</li>
                <li>Configure os registros DNS</li>
                <li>
                  Use: <code className="bg-gray-100 px-1 rounded">R2B Academy &lt;contato@seudominio.com&gt;</code>
                </li>
              </ol>
            </div>

            {/* Quick Actions */}
            <div className="flex gap-4 pt-4">
              <Button onClick={() => window.open("/admin", "_blank")} className="bg-blue-600 hover:bg-blue-700">
                <Globe className="h-4 w-4 mr-2" />
                Ir para Admin
              </Button>
              <Button onClick={() => window.open("/diagnostics", "_blank")} variant="outline">
                <Database className="h-4 w-4 mr-2" />
                Diagnósticos
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Toaster />
    </div>
  )
}
