-- Adicionar campos específicos para integração com Kirvano
ALTER TABLE users ADD COLUMN IF NOT EXISTS kirvano_order_id VARCHAR(255);
ALTER TABLE users ADD COLUMN IF NOT EXISTS kirvano_customer_id VARCHAR(255);
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(20);
ALTER TABLE users ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active';

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_users_kirvano_order ON users(kirvano_order_id);
CREATE INDEX IF NOT EXISTS idx_users_kirvano_customer ON users(kirvano_customer_id);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Atualizar usuários existentes para ter status ativo
UPDATE users SET status = 'active' WHERE status IS NULL;
