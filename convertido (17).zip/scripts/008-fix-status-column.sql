-- Verificar se a tabela users existe
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_tables WHERE tablename = 'users') THEN
        RAISE NOTICE 'Criando tabela users...';
        
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL DEFAULT 'aluno',
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        
        RAISE NOTICE 'Tabela users criada com sucesso!';
    ELSE
        RAISE NOTICE 'Tabela users já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna status se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'status') THEN
        RAISE NOTICE 'Adicionando coluna status...';
        ALTER TABLE users ADD COLUMN status VARCHAR(50) NOT NULL DEFAULT 'active';
        RAISE NOTICE 'Coluna status adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna status já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna role se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'role') THEN
        RAISE NOTICE 'Adicionando coluna role...';
        ALTER TABLE users ADD COLUMN role VARCHAR(50) NOT NULL DEFAULT 'aluno';
        RAISE NOTICE 'Coluna role adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna role já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna phone se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'phone') THEN
        RAISE NOTICE 'Adicionando coluna phone...';
        ALTER TABLE users ADD COLUMN phone VARCHAR(20);
        RAISE NOTICE 'Coluna phone adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna phone já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna cpf se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'cpf') THEN
        RAISE NOTICE 'Adicionando coluna cpf...';
        ALTER TABLE users ADD COLUMN cpf VARCHAR(14);
        RAISE NOTICE 'Coluna cpf adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna cpf já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna birth_date se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'birth_date') THEN
        RAISE NOTICE 'Adicionando coluna birth_date...';
        ALTER TABLE users ADD COLUMN birth_date DATE;
        RAISE NOTICE 'Coluna birth_date adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna birth_date já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna cep se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'cep') THEN
        RAISE NOTICE 'Adicionando coluna cep...';
        ALTER TABLE users ADD COLUMN cep VARCHAR(10);
        RAISE NOTICE 'Coluna cep adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna cep já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna street se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'street') THEN
        RAISE NOTICE 'Adicionando coluna street...';
        ALTER TABLE users ADD COLUMN street VARCHAR(255);
        RAISE NOTICE 'Coluna street adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna street já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna number se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'number') THEN
        RAISE NOTICE 'Adicionando coluna number...';
        ALTER TABLE users ADD COLUMN number VARCHAR(20);
        RAISE NOTICE 'Coluna number adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna number já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna complement se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'complement') THEN
        RAISE NOTICE 'Adicionando coluna complement...';
        ALTER TABLE users ADD COLUMN complement VARCHAR(100);
        RAISE NOTICE 'Coluna complement adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna complement já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna neighborhood se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'neighborhood') THEN
        RAISE NOTICE 'Adicionando coluna neighborhood...';
        ALTER TABLE users ADD COLUMN neighborhood VARCHAR(100);
        RAISE NOTICE 'Coluna neighborhood adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna neighborhood já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna city se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'city') THEN
        RAISE NOTICE 'Adicionando coluna city...';
        ALTER TABLE users ADD COLUMN city VARCHAR(100);
        RAISE NOTICE 'Coluna city adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna city já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna state se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'state') THEN
        RAISE NOTICE 'Adicionando coluna state...';
        ALTER TABLE users ADD COLUMN state VARCHAR(2);
        RAISE NOTICE 'Coluna state adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna state já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna country se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'country') THEN
        RAISE NOTICE 'Adicionando coluna country...';
        ALTER TABLE users ADD COLUMN country VARCHAR(50) DEFAULT 'Brasil';
        RAISE NOTICE 'Coluna country adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna country já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna created_at se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'created_at') THEN
        RAISE NOTICE 'Adicionando coluna created_at...';
        ALTER TABLE users ADD COLUMN created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
        RAISE NOTICE 'Coluna created_at adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna created_at já existe.';
    END IF;
END
$$;

-- Verificar e adicionar coluna updated_at se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'updated_at') THEN
        RAISE NOTICE 'Adicionando coluna updated_at...';
        ALTER TABLE users ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
        RAISE NOTICE 'Coluna updated_at adicionada com sucesso!';
    ELSE
        RAISE NOTICE 'Coluna updated_at já existe.';
    END IF;
END
$$;

-- Criar índices para os campos principais
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_users_email') THEN
        CREATE UNIQUE INDEX idx_users_email ON users(email);
        RAISE NOTICE 'Índice idx_users_email criado.';
    ELSE
        RAISE NOTICE 'Índice idx_users_email já existe.';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_users_role') THEN
        CREATE INDEX idx_users_role ON users(role);
        RAISE NOTICE 'Índice idx_users_role criado.';
    ELSE
        RAISE NOTICE 'Índice idx_users_role já existe.';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_users_status') THEN
        CREATE INDEX idx_users_status ON users(status);
        RAISE NOTICE 'Índice idx_users_status criado.';
    ELSE
        RAISE NOTICE 'Índice idx_users_status já existe.';
    END IF;
END
$$;

-- Verificar estrutura final da tabela
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'users' 
ORDER BY ordinal_position;

-- Contar registros
SELECT COUNT(*) as total_users FROM users;

-- Mostrar mensagem de conclusão
DO $$
BEGIN
    RAISE NOTICE 'Script executado com sucesso! Todas as colunas necessárias foram adicionadas à tabela users.';
END
$$;
