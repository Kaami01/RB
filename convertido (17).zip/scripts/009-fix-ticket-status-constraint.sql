-- Verificar e corrigir constraint de status dos tickets
-- Primeiro, vamos ver se há tickets com status inválido
SELECT DISTINCT status FROM tickets;

-- Atualizar tickets com status inválido para 'open'
UPDATE tickets 
SET status = 'open' 
WHERE status NOT IN ('open', 'answered', 'closed');

-- Garantir que a constraint está correta
ALTER TABLE tickets DROP CONSTRAINT IF EXISTS tickets_status_check;
ALTER TABLE tickets ADD CONSTRAINT tickets_status_check CHECK (status IN ('open', 'answered', 'closed'));

-- Verificar se todos os tickets têm status válido
SELECT COUNT(*) as total_tickets, status 
FROM tickets 
GROUP BY status;
