-- Inserir dados de exemplo para dicas
INSERT INTO tips (category, title, description, content, published) VALUES
('roupas', 'Como identificar tecidos de qualidade', 'Aprenda a distinguir tecidos bons dos ruins antes de comprar', 'Ao comprar roupas online, especialmente de fornecedores chineses, é crucial saber identificar a qualidade dos tecidos. Procure por descrições detalhadas que mencionem a composição do tecido (algodão, poliéster, etc.), gramatura e acabamento. Evite produtos que não especificam o material ou usam termos vagos como "tecido macio".', true),
('tenis', 'Verificando a autenticidade de tênis', 'Dicas para identificar réplicas de qualidade e evitar produtos ruins', 'Para tênis, observe detalhes como costuras, qualidade da sola, acabamento dos materiais e comparação com fotos oficiais. Fornecedores confiáveis geralmente mostram fotos detalhadas e têm avaliações consistentes.', true),
('perfumes', 'Perfumes importados: o que observar', 'Como escolher perfumes importados de qualidade', 'Perfumes importados podem ser uma ótima opção, mas atenção à concentração (EDT, EDP), origem declarada e avaliações de outros compradores sobre durabilidade e projeção.', true),
('eletronicos', 'Eletrônicos seguros para importar', 'Quais eletrônicos vale a pena importar e quais evitar', 'Alguns eletrônicos são seguros para importar, como acessórios, cabos e gadgets simples. Evite produtos que precisam de certificação específica ou que podem ter problemas de compatibilidade.', false),
('geral', 'Negociando com fornecedores', 'Como negociar melhores preços e condições', 'A negociação é fundamental no comércio internacional. Seja respeitoso, faça pedidos em quantidade, construa relacionamento e sempre confirme detalhes por escrito.', true)
ON CONFLICT DO NOTHING;

-- Inserir dados de exemplo para produtos
INSERT INTO products (category, store, title, description, price, rating, reviews, image, link) VALUES
('roupas', 'aliexpress', 'Camisetas Básicas Premium', 'Camisetas de algodão 100% com ótimo caimento e durabilidade', '$3.99 - $8.99', 4.8, '2.3k', '/placeholder.svg?height=200&width=300', 'https://aliexpress.com/item/exemplo1'),
('tenis', 'dhgate', 'Tênis Esportivos Replica', 'Réplicas de alta qualidade com materiais premium', '$45.00 - $65.00', 4.6, '1.8k', '/placeholder.svg?height=200&width=300', 'https://dhgate.com/item/exemplo2'),
('perfumes', 'aliexpress', 'Perfumes Importados 100ml', 'Fragrâncias inspiradas em marcas famosas, longa duração', '$12.99 - $24.99', 4.7, '956', '/placeholder.svg?height=200&width=300', 'https://aliexpress.com/item/exemplo3'),
('eletronicos', '1688', 'Fones Bluetooth TWS', 'Fones sem fio com cancelamento de ruído', '$8.50 - $15.00', 4.5, '3.2k', '/placeholder.svg?height=200&width=300', 'https://1688.com/item/exemplo4'),
('acessorios', 'shein', 'Relógios Masculinos', 'Relógios esportivos com múltiplas funções', '$15.99 - $29.99', 4.4, '1.1k', '/placeholder.svg?height=200&width=300', 'https://shein.com/item/exemplo5')
ON CONFLICT DO NOTHING;

-- Inserir dados de exemplo para comunidades
INSERT INTO communities (icon, title, description, members, online, is_vip) VALUES
('👕', 'Roupas Premium', 'Comunidade focada em roupas de alta qualidade e tendências', '2.5k', '234', false),
('👟', 'Sneakers Brasil', 'Grupo especializado em tênis e calçados importados', '1.8k', '156', true),
('💎', 'Luxo Acessível', 'Produtos de luxo com preços acessíveis', '3.2k', '289', true),
('📱', 'Tech Imports', 'Eletrônicos e gadgets importados', '1.4k', '98', false),
('🌟', 'Geral R2B', 'Comunidade geral para todos os nichos', '5.1k', '445', false)
ON CONFLICT DO NOTHING;

-- Inserir dados de exemplo para ferramentas
INSERT INTO tools (icon, title, description, link, enabled) VALUES
('🔍', 'Pesquisa de Produtos', 'Ferramenta para encontrar produtos similares', 'https://exemplo.com/pesquisa', true),
('💰', 'Calculadora de Impostos', 'Calcule impostos e taxas de importação', 'https://exemplo.com/calculadora', true),
('📊', 'Análise de Tendências', 'Veja quais produtos estão em alta', 'https://exemplo.com/tendencias', true),
('🚚', 'Rastreamento de Pedidos', 'Rastreie seus pedidos em tempo real', 'https://exemplo.com/rastreamento', false),
('💬', 'Tradutor Automático', 'Traduza descrições de produtos', 'https://exemplo.com/tradutor', true)
ON CONFLICT DO NOTHING;

-- Inserir dados de exemplo para tickets
INSERT INTO tickets (subject, category, description, status, user_name, user_id, response) VALUES
('Problema com produto recebido', 'produto', 'O produto chegou com defeito, como proceder?', 'answered', 'João Silva', 'user123', 'Entre em contato com o fornecedor através da plataforma de compra.'),
('Dúvida sobre importação', 'importacao', 'Primeira vez importando, preciso de orientação', 'open', 'Maria Santos', 'user456', NULL),
('Sugestão de melhoria', 'sugestao', 'Seria legal ter mais dicas sobre eletrônicos', 'closed', 'Pedro Costa', 'user789', 'Obrigado pela sugestão! Já estamos trabalhando nisso.'),
('Problema de acesso', 'tecnico', 'Não consigo acessar algumas seções', 'open', 'Ana Oliveira', 'user101', NULL)
ON CONFLICT DO NOTHING;

-- Inserir usuário admin padrão (senha: admin123)
INSERT INTO users (email, name, role, password_hash) VALUES
('admin@r2b.com.br', 'Administrador', 'admin', '$2b$10$example.hash.here')
ON CONFLICT (email) DO NOTHING;
