-- Verificar se a tabela users existe
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_tables WHERE tablename = 'users') THEN
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL DEFAULT 'aluno',
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Tabela users criada com sucesso!';
    ELSE
        RAISE NOTICE 'Tabela users já existe.';
    END IF;
END
$$;

-- Adicionar coluna phone se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'phone') THEN
        ALTER TABLE users ADD COLUMN phone VARCHAR(20);
        RAISE NOTICE 'Coluna phone adicionada.';
    ELSE
        RAISE NOTICE 'Coluna phone já existe.';
    END IF;
END
$$;

-- Adicionar coluna cpf se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'cpf') THEN
        ALTER TABLE users ADD COLUMN cpf VARCHAR(14);
        RAISE NOTICE 'Coluna cpf adicionada.';
    ELSE
        RAISE NOTICE 'Coluna cpf já existe.';
    END IF;
END
$$;

-- Adicionar coluna birth_date se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'birth_date') THEN
        ALTER TABLE users ADD COLUMN birth_date DATE;
        RAISE NOTICE 'Coluna birth_date adicionada.';
    ELSE
        RAISE NOTICE 'Coluna birth_date já existe.';
    END IF;
END
$$;

-- Adicionar coluna cep se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'cep') THEN
        ALTER TABLE users ADD COLUMN cep VARCHAR(10);
        RAISE NOTICE 'Coluna cep adicionada.';
    ELSE
        RAISE NOTICE 'Coluna cep já existe.';
    END IF;
END
$$;

-- Adicionar coluna street se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'street') THEN
        ALTER TABLE users ADD COLUMN street VARCHAR(255);
        RAISE NOTICE 'Coluna street adicionada.';
    ELSE
        RAISE NOTICE 'Coluna street já existe.';
    END IF;
END
$$;

-- Adicionar coluna number se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'number') THEN
        ALTER TABLE users ADD COLUMN number VARCHAR(20);
        RAISE NOTICE 'Coluna number adicionada.';
    ELSE
        RAISE NOTICE 'Coluna number já existe.';
    END IF;
END
$$;

-- Adicionar coluna complement se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'complement') THEN
        ALTER TABLE users ADD COLUMN complement VARCHAR(100);
        RAISE NOTICE 'Coluna complement adicionada.';
    ELSE
        RAISE NOTICE 'Coluna complement já existe.';
    END IF;
END
$$;

-- Adicionar coluna neighborhood se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'neighborhood') THEN
        ALTER TABLE users ADD COLUMN neighborhood VARCHAR(100);
        RAISE NOTICE 'Coluna neighborhood adicionada.';
    ELSE
        RAISE NOTICE 'Coluna neighborhood já existe.';
    END IF;
END
$$;

-- Adicionar coluna city se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'city') THEN
        ALTER TABLE users ADD COLUMN city VARCHAR(100);
        RAISE NOTICE 'Coluna city adicionada.';
    ELSE
        RAISE NOTICE 'Coluna city já existe.';
    END IF;
END
$$;

-- Adicionar coluna state se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'state') THEN
        ALTER TABLE users ADD COLUMN state VARCHAR(2);
        RAISE NOTICE 'Coluna state adicionada.';
    ELSE
        RAISE NOTICE 'Coluna state já existe.';
    END IF;
END
$$;

-- Adicionar coluna country se não existir
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_attribute WHERE attrelid = 'users'::regclass AND attname = 'country') THEN
        ALTER TABLE users ADD COLUMN country VARCHAR(50) DEFAULT 'Brasil';
        RAISE NOTICE 'Coluna country adicionada.';
    ELSE
        RAISE NOTICE 'Coluna country já existe.';
    END IF;
END
$$;

-- Criar índices para os novos campos
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_users_cpf') THEN
        CREATE INDEX idx_users_cpf ON users(cpf);
        RAISE NOTICE 'Índice idx_users_cpf criado.';
    ELSE
        RAISE NOTICE 'Índice idx_users_cpf já existe.';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_users_city') THEN
        CREATE INDEX idx_users_city ON users(city);
        RAISE NOTICE 'Índice idx_users_city criado.';
    ELSE
        RAISE NOTICE 'Índice idx_users_city já existe.';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_users_state') THEN
        CREATE INDEX idx_users_state ON users(state);
        RAISE NOTICE 'Índice idx_users_state criado.';
    ELSE
        RAISE NOTICE 'Índice idx_users_state já existe.';
    END IF;
END
$$;

-- Verificar estrutura final da tabela
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'users' 
ORDER BY ordinal_position;

-- Contar registros
SELECT COUNT(*) as total_users FROM users;

-- Mostrar mensagem de conclusão
DO $$
BEGIN
    RAISE NOTICE 'Script executado com sucesso! Todas as colunas necessárias foram adicionadas à tabela users.';
END
$$;
