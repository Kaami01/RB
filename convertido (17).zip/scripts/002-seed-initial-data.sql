-- Inserir usuários padrão
INSERT INTO users (name, email, password_hash, role, status) VALUES
('Administrador', 'admin@r2b.com.br', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active'),
('João Silva', 'aluno@r2b.com.br', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'aluno', 'active');

-- Inserir dicas de exemplo
INSERT INTO tips (category, title, description, content, published) VALUES
('roupas', 'Como Identificar Tecidos de Qualidade', 'Aprenda a avaliar a qualidade dos tecidos antes de importar roupas, evitando produtos de baixa qualidade...', 'Ao importar roupas, é fundamental saber identificar tecidos de qualidade. Aqui estão as principais dicas:\n\n1. **Toque e Textura**: Tecidos de qualidade têm toque suave e consistente\n2. **Densidade**: Tecidos mais densos geralmente são de melhor qualidade\n3. **Elasticidade**: Teste a elasticidade do tecido\n4. **Acabamento**: Verifique costuras e acabamentos\n5. **Composição**: Leia sempre a etiqueta de composição', true),
('tenis', 'Melhores Épocas para Importar Calçados', 'Descubra os períodos ideais para importar tênis e aproveitar as melhores oportunidades de mercado...', 'O timing é crucial na importação de calçados. Considere:\n\n**Melhores épocas:**\n- Janeiro a Março: Preparação para outono/inverno\n- Julho a Setembro: Preparação para primavera/verão\n\n**Fatores importantes:**\n- Sazonalidade no Brasil\n- Períodos de produção na China\n- Feriados chineses (Ano Novo Chinês)\n- Demanda do mercado brasileiro', true),
('perfumes', 'Cuidados no Transporte de Fragrâncias', 'Dicas essenciais para garantir que seus perfumes cheguem em perfeitas condições, evitando vazamentos...', 'Transportar perfumes requer cuidados especiais:\n\n**Embalagem:**\n- Use bubble wrap duplo\n- Embale cada frasco individualmente\n- Use caixas rígidas\n\n**Documentação:**\n- Declare corretamente como "cosméticos"\n- Evite termos como "perfume" na declaração\n- Mantenha notas fiscais organizadas\n\n**Transporte:**\n- Evite temperaturas extremas\n- Prefira correios para pequenas quantidades', true),
('eletronicos', 'Documentação para Eletrônicos', 'Entenda quais documentos são necessários para importar eletrônicos sem problemas na alfândega...', 'Importar eletrônicos exige documentação específica:\n\n**Documentos obrigatórios:**\n- Invoice comercial detalhada\n- Certificado de conformidade (quando aplicável)\n- Manual em português\n- Termo de responsabilidade\n\n**Dicas importantes:**\n- Declare valor real do produto\n- Mantenha comprovantes de pagamento\n- Verifique se precisa de homologação ANATEL\n- Considere seguro para produtos caros', true);

-- Inserir produtos de exemplo
INSERT INTO products (category, store, title, description, price, rating, reviews, image, link) VALUES
('roupas', 'aliexpress', 'Camisetas Básicas Premium', 'Camisetas de algodão 100% com ótima qualidade e preço competitivo', '$3.99 - $8.99', 4.8, '2.3k', '/placeholder.svg?height=150&width=200', 'https://aliexpress.com/item/example1'),
('tenis', 'dhgate', 'Tênis Esportivos Replica', 'Réplicas de alta qualidade de marcas famosas', '$25.00 - $45.00', 4.2, '856', '/placeholder.svg?height=150&width=200', 'https://dhgate.com/item/example2'),
('perfumes', 'aliexpress', 'Perfumes Importados 100ml', 'Fragrâncias inspiradas em marcas famosas com longa duração', '$12.99 - $29.99', 4.6, '1.2k', '/placeholder.svg?height=150&width=200', 'https://aliexpress.com/item/example3'),
('eletronicos', '1688', 'Fones Bluetooth TWS', 'Fones sem fio com cancelamento de ruído e case carregador', '$8.50 - $18.00', 4.3, '567', '/placeholder.svg?height=150&width=200', 'https://1688.com/item/example4'),
('roupas', 'amazon', 'Vestidos Femininos', 'Vestidos casuais e elegantes para todas as ocasiões', '$15.99 - $35.99', 4.5, '1.8k', '/placeholder.svg?height=150&width=200', 'https://amazon.com/item/example5'),
('acessorios', 'aliexpress', 'Relógios Inteligentes', 'Smartwatches com múltiplas funcionalidades', '$19.99 - $49.99', 4.4, '3.2k', '/placeholder.svg?height=150&width=200', 'https://aliexpress.com/item/example6');

-- Inserir comunidades de exemplo
INSERT INTO communities (icon, title, description, members, online, is_vip) VALUES
('👕', 'Roupas & Moda', 'Discussões sobre importação de roupas, tendências e fornecedores', '1.2k', '89', false),
('👟', 'Tênis & Calçados', 'Especialistas em importação de calçados esportivos e casuais', '856', '45', false),
('🧴', 'Perfumes & Cosméticos', 'Comunidade focada em fragrâncias e produtos de beleza', '634', '23', false),
('📱', 'Eletrônicos & Tech', 'Importação de gadgets, smartphones e tecnologia', '923', '67', false),
('⭐', 'Grupo Geral VIP', 'Discussões gerais, networking e oportunidades exclusivas', '2.8k', '156', true),
('💎', 'Importadores Premium', 'Grupo exclusivo para importadores experientes', '445', '78', true);

-- Inserir ferramentas de exemplo
INSERT INTO tools (icon, title, description, link, enabled) VALUES
('Calculator', 'Calculadora de Frete + Taxa', 'Calcule o custo total da sua importação incluindo frete e impostos', '/tools/calculator', true),
('Box', 'Simulador de Caixa', 'Simule o redirecionamento e otimize o espaço da sua encomenda', '/tools/box-simulator', true),
('HelpCircle', 'Dúvidas Frequentes', 'Encontre respostas para as perguntas mais comuns sobre importação', '/tools/faq', true),
('Headphones', 'Suporte Direto', 'Fale diretamente com nossa equipe de suporte especializada', '/tools/support', true),
('FileText', 'Gerador de Declaração', 'Gere declarações personalizadas para suas encomendas', '/tools/declaration', true),
('TrendingUp', 'Análise de Mercado', 'Relatórios e insights sobre tendências de importação', '/tools/market-analysis', true);

-- Inserir tickets de exemplo
INSERT INTO tickets (subject, category, description, status, user_name, user_id, response) VALUES
('Dúvida sobre taxa de importação', 'importacao', 'Como calcular corretamente a taxa de importação para produtos acima de $50?', 'answered', 'João Silva', 'aluno@r2b.com.br', 'A taxa de importação é calculada sobre o valor da mercadoria + frete. Para produtos acima de $50, é cobrado 60% sobre o valor excedente. Por exemplo: produto de $80 + frete $20 = $100 total. Taxa = ($100 - $50) × 0.6 = $30.'),
('Problema com rastreamento', 'tecnico', 'Meu código de rastreamento não está funcionando no site dos correios', 'open', 'João Silva', 'aluno@r2b.com.br', null),
('Sugestão de melhoria', 'sugestao', 'Seria interessante ter uma calculadora de peso volumétrico', 'closed', 'João Silva', 'aluno@r2b.com.br', 'Obrigado pela sugestão! Já estamos desenvolvendo essa funcionalidade e ela estará disponível em breve.');
