-- Adicionar novas colunas para dados pessoais e endereço
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS cpf VARCHAR(14),
ADD COLUMN IF NOT EXISTS birth_date DATE,
ADD COLUMN IF NOT EXISTS cep VARCHAR(10),
ADD COLUMN IF NOT EXISTS street VARCHAR(255),
ADD COLUMN IF NOT EXISTS number VARCHAR(20),
ADD COLUMN IF NOT EXISTS complement VARCHAR(100),
ADD COLUMN IF NOT EXISTS neighborhood VARCHAR(100),
ADD COLUMN IF NOT EXISTS city VARCHAR(100),
ADD COLUMN IF NOT EXISTS state VARCHAR(2),
ADD COLUMN IF NOT EXISTS country VARCHAR(50) DEFAULT 'Brasil';

-- Remover colunas da Kirvano (se existirem)
ALTER TABLE users 
DROP COLUMN IF EXISTS kirvano_order_id,
DROP COLUMN IF EXISTS kirvano_customer_id;

-- Criar índices para os novos campos
CREATE INDEX IF NOT EXISTS idx_users_cpf ON users(cpf);
CREATE INDEX IF NOT EXISTS idx_users_city ON users(city);
CREATE INDEX IF NOT EXISTS idx_users_state ON users(state);

-- Atualizar dados de exemplo
UPDATE users SET 
    cpf = '123.456.789-01',
    birth_date = '1990-05-15',
    cep = '01234-567',
    street = 'Rua das Flores',
    number = '123',
    neighborhood = 'Centro',
    city = 'São Paulo',
    state = 'SP'
WHERE email = 'joao@exemplo.com';

UPDATE users SET 
    cpf = '987.654.321-02',
    birth_date = '1985-08-22',
    cep = '04567-890',
    street = 'Avenida Paulista',
    number = '456',
    complement = 'Apto 101',
    neighborhood = 'Bela Vista',
    city = 'São Paulo',
    state = 'SP'
WHERE email = 'maria@exemplo.com';

UPDATE users SET 
    cpf = '456.789.123-03',
    birth_date = '1992-12-10',
    cep = '12345-678',
    street = 'Rua da Liberdade',
    number = '789',
    neighborhood = 'Liberdade',
    city = 'São Paulo',
    state = 'SP'
WHERE email = 'pedro@exemplo.com';

-- Verificar estrutura atualizada
SELECT 'Tabela users atualizada com sucesso!' as message;
SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'users' ORDER BY ordinal_position;
