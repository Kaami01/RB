-- Verificar se a tabela users existe e tem as colunas corretas
DO $$ 
BEGIN
    -- Criar tabela users se não existir
    IF NOT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'users') THEN
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL DEFAULT 'aluno',
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            kirvano_order_id VARCHAR(255),
            kirvano_customer_id VARCHAR(255),
            phone VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        RAISE NOTICE 'Tabela users criada com sucesso';
    ELSE
        RAISE NOTICE 'Tabela users já existe';
    END IF;

    -- Adicionar colunas que podem estar faltando
    BEGIN
        ALTER TABLE users ADD COLUMN IF NOT EXISTS kirvano_order_id VARCHAR(255);
        ALTER TABLE users ADD COLUMN IF NOT EXISTS kirvano_customer_id VARCHAR(255);
        ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(50);
        ALTER TABLE users ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'active';
        ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'aluno';
        
        RAISE NOTICE 'Colunas adicionadas/verificadas com sucesso';
    EXCEPTION
        WHEN duplicate_column THEN
            RAISE NOTICE 'Colunas já existem';
    END;

    -- Criar índices para melhor performance
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
    CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
    CREATE INDEX IF NOT EXISTS idx_users_kirvano_order ON users(kirvano_order_id);

    RAISE NOTICE 'Índices criados/verificados com sucesso';
END $$;

-- Inserir usuário admin padrão se não existir
INSERT INTO users (name, email, password_hash, role, status)
SELECT 'Administrador', 'admin@r2b.com.br', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.PJ/..G', 'admin', 'active'
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'admin@r2b.com.br'
);
