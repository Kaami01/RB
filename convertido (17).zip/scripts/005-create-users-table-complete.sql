-- Remover tabela users se existir (para recriação completa)
DROP TABLE IF EXISTS users CASCADE;

-- Criar tabela users completa
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'aluno',
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    kirvano_order_id VARCHAR(255),
    kirvano_customer_id VARCHAR(255),
    phone VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar índices
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_kirvano_order ON users(kirvano_order_id);

-- Inserir usuário admin padrão
INSERT INTO users (name, email, password_hash, role, status) VALUES 
('Administrador', 'admin@r2bacademy.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.PJ/..G', 'admin', 'active');

-- Inserir alguns estudantes de exemplo
INSERT INTO users (name, email, password_hash, role, status, kirvano_order_id, phone) VALUES 
('João Silva', 'joao@exemplo.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.PJ/..G', 'aluno', 'active', 'KRV001', '(11) 99999-9999'),
('Maria Santos', 'maria@exemplo.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.PJ/..G', 'aluno', 'active', 'KRV002', '(11) 88888-8888'),
('Pedro Costa', 'pedro@exemplo.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.PJ/..G', 'aluno', 'pending', 'KRV003', '(11) 77777-7777');

-- Verificar se a tabela foi criada corretamente
SELECT 'Tabela users criada com sucesso!' as message;
SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'users' ORDER BY ordinal_position;
