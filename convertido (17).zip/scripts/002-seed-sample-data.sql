-- Dados de exemplo para testar o sistema R2B Academy

-- Limpar dados existentes
TRUNCATE users, tips, products, communities, tools, tickets RESTART IDENTITY CASCADE;

-- Inserir usuário admin
INSERT INTO users (name, email, password_hash, role, status) VALUES 
('Administrador', 'admin@r2b.com.br', '$2b$10$X7VYHy.C1ORQ9nMO1GKJz.F/hL/3ND6nIGgdKO1wP5i8gGIhvFIWi', 'admin', 'active')
ON CONFLICT (email) DO NOTHING;

-- Inserir alguns estudantes de exemplo
INSERT INTO users (name, email, password_hash, role, phone, cpf, status) VALUES 
('João Silva', 'joao@exemplo.com', '$2b$10$X7VYHy.C1ORQ9nMO1GKJz.F/hL/3ND6nIGgdKO1wP5i8gGIhvFIWi', 'aluno', '(11) 98765-4321', '12345678901', 'active'),
('Maria Oliveira', 'maria@exemplo.com', '$2b$10$X7VYHy.C1ORQ9nMO1GKJz.F/hL/3ND6nIGgdKO1wP5i8gGIhvFIWi', 'aluno', '(21) 98765-4321', '98765432109', 'active'),
('Pedro Santos', 'pedro@exemplo.com', '$2b$10$X7VYHy.C1ORQ9nMO1GKJz.F/hL/3ND6nIGgdKO1wP5i8gGIhvFIWi', 'aluno', '(31) 98765-4321', '45678912345', 'inactive')
ON CONFLICT (email) DO NOTHING;

-- Inserir dicas de exemplo
INSERT INTO tips (category, title, description, content, published) VALUES 
('Tecidos', 'Como Identificar Tecidos de Qualidade', 'Aprenda a identificar tecidos de alta qualidade para suas importações', 'Conteúdo detalhado sobre identificação de tecidos...', true),
('Fornecedores', 'Top 10 Fornecedores Confiáveis', 'Lista dos melhores fornecedores verificados', 'Conteúdo detalhado sobre fornecedores...', true),
('Logística', 'Otimizando Custos de Frete', 'Estratégias para reduzir custos de frete internacional', 'Conteúdo detalhado sobre logística...', false)
ON CONFLICT DO NOTHING;

-- Inserir produtos de exemplo
INSERT INTO products (category, store, title, description, price, rating, reviews, link) VALUES 
('Tecidos', 'AliExpress', 'Tecido de Algodão Premium', 'Tecido 100% algodão de alta qualidade', 'US$ 5,99/metro', 4.8, '256', 'https://exemplo.com/produto1'),
('Acessórios', 'Alibaba', 'Kit de Botões Sortidos', 'Kit com 100 botões de diversos tamanhos e cores', 'US$ 8,50', 4.5, '128', 'https://exemplo.com/produto2'),
('Máquinas', '1688', 'Máquina de Costura Industrial', 'Máquina de costura industrial de alta velocidade', 'US$ 299,00', 4.9, '45', 'https://exemplo.com/produto3')
ON CONFLICT DO NOTHING;

-- Inserir comunidades de exemplo
INSERT INTO communities (icon, title, description, members, online, is_vip) VALUES 
('users', 'Importadores Iniciantes', 'Grupo para quem está começando no mundo da importação', '1.2k', '45', false),
('zap', 'Experts em Dropshipping', 'Comunidade exclusiva para dropshippers avançados', '850', '32', true),
('globe', 'Importadores de Tecidos', 'Grupo focado em importação de tecidos e materiais têxteis', '650', '28', false)
ON CONFLICT DO NOTHING;

-- Inserir ferramentas de exemplo
INSERT INTO tools (icon, title, description, link, enabled) VALUES 
('calculator', 'Calculadora de Impostos', 'Calcule todos os impostos e taxas para sua importação', 'https://exemplo.com/calculadora', true),
('search', 'Verificador de Fornecedores', 'Verifique a reputação e confiabilidade de fornecedores', 'https://exemplo.com/verificador', true),
('truck', 'Rastreador de Encomendas', 'Acompanhe suas encomendas internacionais', 'https://exemplo.com/rastreador', false)
ON CONFLICT DO NOTHING;

-- Inserir tickets de exemplo
INSERT INTO tickets (subject, category, description, status, user_name, user_id) VALUES 
('Dúvida sobre impostos', 'Suporte', 'Tenho dúvidas sobre o cálculo de impostos para tecidos', 'open', 'João Silva', '1'),
('Problema com acesso', 'Técnico', 'Não consigo acessar a ferramenta de cálculo', 'in_progress', 'Maria Oliveira', '2'),
('Sugestão de conteúdo', 'Conteúdo', 'Gostaria de sugerir um tema para próximas dicas', 'resolved', 'Pedro Santos', '3')
ON CONFLICT DO NOTHING;
