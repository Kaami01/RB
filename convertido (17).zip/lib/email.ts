import { Resend } from "resend"

const resend = new Resend(process.env.RESEND_API_KEY || process.env.NEXT_PUBLIC_RESEND_API_KEY)

interface EmailOptions {
  to: string
  subject: string
  html: string
}

export async function sendEmail({ to, subject, html }: EmailOptions) {
  console.log("Attempting to send email to:", to)
  console.log("Email subject:", subject)

  try {
    if (!process.env.RESEND_API_KEY && !process.env.NEXT_PUBLIC_RESEND_API_KEY) {
      console.log("No Resend API key found, skipping email")
      return {
        success: false,
        error: "Resend API key not configured",
      }
    }

    const fromEmail =
      process.env.EMAIL_FROM || process.env.NEXT_PUBLIC_EMAIL_FROM || "R2B Academy <onboarding@resend.dev>"

    console.log("Sending email from:", fromEmail)

    const result = await resend.emails.send({
      from: fromEmail,
      to: [to],
      subject: subject,
      html: html,
    })

    console.log("Email sent successfully:", result)
    return {
      success: true,
      data: result,
    }
  } catch (error) {
    console.error("Error sending email:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown email error",
    }
  }
}

interface WelcomeEmailData {
  name: string
  email: string
  password: string
  loginUrl: string
}

export function createWelcomeEmailTemplate({ name, email, password, loginUrl }: WelcomeEmailData): string {
  return `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Bem-vindo à R2B Academy</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }
        .credentials { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea; }
        .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>🎉 Bem-vindo à R2B Academy!</h1>
        <p>Sua conta foi criada com sucesso</p>
      </div>
      
      <div class="content">
        <p>Olá <strong>${name}</strong>,</p>
        
        <p>É com grande prazer que damos as boas-vindas à <strong>R2B Academy</strong>! Sua conta foi criada e você já pode acessar nossa plataforma.</p>
        
        <div class="credentials">
          <h3>📧 Suas Credenciais de Acesso:</h3>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Senha Temporária:</strong> <code style="background: #f1f3f4; padding: 4px 8px; border-radius: 4px; font-family: monospace;">${password}</code></p>
        </div>
        
        <div class="warning">
          <strong>⚠️ Importante:</strong> Por segurança, recomendamos que você altere sua senha no primeiro acesso.
        </div>
        
        <div style="text-align: center;">
          <a href="${loginUrl}" class="button">🚀 Acessar Plataforma</a>
        </div>
        
        <h3>🎯 O que você encontrará na plataforma:</h3>
        <ul>
          <li>📚 Dicas e conteúdos exclusivos</li>
          <li>🛍️ Produtos recomendados</li>
          <li>👥 Comunidades ativas</li>
          <li>🔧 Ferramentas úteis</li>
          <li>💬 Suporte especializado</li>
        </ul>
        
        <p>Se você tiver alguma dúvida ou precisar de ajuda, não hesite em entrar em contato conosco através do sistema de suporte da plataforma.</p>
        
        <p>Mais uma vez, seja muito bem-vindo(a)!</p>
        
        <p>Atenciosamente,<br>
        <strong>Equipe R2B Academy</strong></p>
      </div>
      
      <div class="footer">
        <p>Este é um email automático, por favor não responda.</p>
        <p>© 2024 R2B Academy. Todos os direitos reservados.</p>
      </div>
    </body>
    </html>
  `
}
