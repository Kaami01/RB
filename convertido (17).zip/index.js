export default function Page() {
  return (
    <>
    <!-- Secção 0: Barra de Alerta/Anúncio -->
    <div className="alert-bar">
        <div className="alert-content">
            <span className="pulse-icon">⚠️</span>
            <p>ÚLTIMAS HORAS: Inscrições para o R2B com Desconto Exclusivo e Bónus Extras a Encerrar! Não Perca!</p>
        </div>
    </div>

    <!-- Header com Navegação Circular -->
    <header className="main-header">
        <nav className="circular-nav">
            <button className="menu-toggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul className="nav-items">
                <li><a href="#metodo">O Método</a></li>
                <li><a href="#modulos">Módulos</a></li>
                <li><a href="#depoimentos">Depoimentos</a></li>
                <li><a href="#oferta">Garantir Vaga</a></li>
            </ul>
        </nav>
        
        <div className="logo-container">
            <div className="logo-text">R2B</div>
        </div>

        <!-- Login Button -->
        <div className="login-container">
            <button id="loginBtn" className="login-button">
                <i className="fas fa-user"></i>
                <span>Login</span>
            </button>
        </div>
    </header>

    <!-- Login Modal -->
    <div id="loginModal" className="login-modal">
        <div className="modal-backdrop"></div>
        <div className="modal-content">
            <!-- Header -->
            <div className="modal-header">
                <div className="modal-title-section">
                    <h2>Área do Aluno</h2>
                    <p>Acesse sua conta para continuar</p>
                </div>
                <button id="closeModal" className="modal-close">
                    <i className="fas fa-times"></i>
                </button>
            </div>

            <!-- Demo Credentials -->
            <div className="demo-credentials-section">
                <h3>🎯 Credenciais de Teste:</h3>
                <div className="demo-buttons">
                    <button id="adminLogin" className="demo-btn admin">Admin</button>
                    <button id="alunoLogin" className="demo-btn aluno">Aluno</button>
                </div>
            </div>

            <!-- Form -->
            <form id="loginForm" className="login-form">
                <div id="errorMessage" className="error-message" style="display: none;"></div>

                <!-- Email Field -->
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <div className="input-wrapper">
                        <i className="fas fa-envelope input-icon"></i>
                        <input id="email" type="email" placeholder="seu@email.com" required>
                    </div>
                </div>

                <!-- Password Field -->
                <div className="form-group">
                    <label htmlFor="password">Senha</label>
                    <div className="input-wrapper">
                        <i className="fas fa-lock input-icon"></i>
                        <input id="password" type="password" placeholder="••••••••" required>
                        <button type="button" id="togglePassword" className="password-toggle">
                            <i className="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" id="submitBtn" className="submit-btn">
                    <span id="submitText">Entrar</span>
                </button>

                <!-- Footer -->
                <div className="form-footer">
                    <p>Não tem uma conta? <span className="contact-link">Entre em contato conosco</span></p>
                </div>
            </form>
        </div>
    </div>

    <!-- Demo Info -->
    <div id="demoInfo" className="demo-info">
        <div className="demo-content">
            <h3>🎯 Demo do Sistema de Login</h3>
            <p>Use estas credenciais para testar:</p>
            <div className="demo-credentials">
                <div><strong>Admin:</strong> admin@r2b.com.br / 123456</div>
                <div><strong>Aluno:</strong> aluno@r2b.com.br / 123456</div>
            </div>
        </div>
    </div>

    <!-- Secção 1: Herói Diagonal (Above the Fold) -->
    <section className="hero-section">
        <div className="diagonal-split">
            <div className="hero-content">
                <div className="layered-headline">
                    <h1 className="headline-layer">FINALMENTE REVELADO:</h1>
                    <h1 className="headline-layer accent">O Método Passo a Passo</h1>
                    <h1 className="headline-layer">Usado por Brasileiros Comuns para</h1>
                    <h1 className="headline-layer accent">Importar QUALQUER Produto</h1>
                    <h1 className="headline-layer">dos EUA e China Pagando Até 70% Menos</h1>
                </div>
                <p className="hero-description">Descubra como o R2B transforma iniciantes em importadores profissionais lucrativos em semanas (e não anos!). Junte-se à elite da importação inteligente!</p>
                <div className="floating-cta">
                    <a href="#oferta" className="cta-button primary">🔥 SIM! QUERO ACESSO IMEDIATO AO R2B! 🔥</a>
                    <div className="cta-shadow"></div>
                </div>
                <p className="trust-badges">
                    <span>✅ Compra 100% Segura</span> | 
                    <span>🔒 Garantia Blindada de 7 Dias</span> | 
                    <span>⚡ Acesso Imediato</span>
                </p>
            </div>
            <div className="video-container">
                <div className="video-frame">
                    <iframe width="760" height="315" src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div className="video-progress">
                    <span className="progress-point">Intro</span>
                    <span className="progress-point">Problema</span>
                    <span className="progress-point">Solução</span>
                    <span className="progress-point">Prova</span>
                    <span className="progress-point">Oferta</span>
                </div>
            </div>
        </div>
        <div className="scroll-indicator">
            <span>Descubra Mais</span>
            <div className="scroll-arrow"></div>
        </div>
    </section>

    <!-- Secção 2: Problema/Agitação com Narrativa Paralela -->
    <section className="problem-section" id="problema">
        <h2 className="centered">Você se Identifica com Algum Destes Pesadelos da Importação?</h2>
        <div className="parallel-narrative">
            <div className="narrative-column pain">
                <div className="scrolly-item">
                    <div className="icon-container">
                        <div className="icon pain-icon">💸</div>
                    </div>
                    <h3>Medo Constante de Taxas Surpresa</h3>
                    <p>Você já deixou de comprar algo por não saber quanto realmente pagaria de imposto, ou pior, já foi surpreendido com uma taxa tão alta que tornou a importação inviável?</p>
                </div>
                <div className="scrolly-item">
                    <div className="icon-container">
                        <div className="icon pain-icon">🚫</div>
                    </div>
                    <h3>Frustração com Produtos Retidos</h3>
                    <p>A angústia de esperar semanas por uma encomenda, apenas para descobrir que ela ficou presa na alfândega ou, pior ainda, desapareceu no limbo dos correios?</p>
                </div>
                <div className="scrolly-item">
                    <div className="icon-container">
                        <div className="icon pain-icon">🌍</div>
                    </div>
                    <h3>Fornecedores Não Confiáveis</h3>
                    <p>O receio de cair em golpes, comprar produtos falsificados ou lidar com vendedores que simplesmente não entregam o prometido?</p>
                </div>
            </div>
            <div className="narrative-divider">
                <div className="versus-badge">VS</div>
            </div>
            <div className="narrative-column solution">
                <div className="scrolly-item">
                    <div className="icon-container">
                        <div className="icon solution-icon">✅</div>
                    </div>
                    <h3>Previsibilidade Total de Custos</h3>
                    <p>Calcule com precisão todos os impostos e taxas ANTES de comprar, eliminando surpresas desagradáveis e garantindo que sua importação seja viável.</p>
                </div>
                <div className="scrolly-item">
                    <div className="icon-container">
                        <div className="icon solution-icon">📦</div>
                    </div>
                    <h3>Importações Sem Retenção</h3>
                    <p>Aprenda as técnicas exatas para garantir que seus produtos passem pela alfândega sem problemas e cheguem às suas mãos no menor tempo possível.</p>
                </div>
                <div className="scrolly-item">
                    <div className="icon-container">
                        <div className="icon solution-icon">🔍</div>
                    </div>
                    <h3>Fornecedores Verificados e Confiáveis</h3>
                    <p>Acesse nossa lista exclusiva de fornecedores verificados e aprenda a identificar vendedores confiáveis por conta própria, eliminando riscos.</p>
                </div>
            </div>
        </div>
        <div className="data-visualization">
            <h3>A Diferença R2B na Prática: Economia Real em Produtos Populares</h3>
            <div className="price-comparison">
                <div className="product">
                    <img src="https://via.placeholder.com/120x120/3A7BD5/FFFFFF?text=iPhone" alt="Smartphone">
                    <h4>iPhone 14 Pro</h4>
                    <div className="price-bars">
                        <div className="price-bar brazil">
                            <span className="price-label">Brasil: R$ 9.499</span>
                        </div>
                        <div className="price-bar r2b">
                            <span className="price-label">Com R2B: R$ 5.699</span>
                            <div className="saving-badge">-40%</div>
                        </div>
                    </div>
                </div>
                <div className="product">
                    <img src="https://via.placeholder.com/120x120/3A7BD5/FFFFFF?text=MacBook" alt="Laptop">
                    <h4>MacBook Air M2</h4>
                    <div className="price-bars">
                        <div className="price-bar brazil">
                            <span className="price-label">Brasil: R$ 12.999</span>
                        </div>
                        <div className="price-bar r2b">
                            <span className="price-label">Com R2B: R$ 7.799</span>
                            <div className="saving-badge">-40%</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Secção 3: O Método R2B -->
    <section className="method-section" id="metodo">
        <h2 className="centered">O Método R2B: Sua Rota Direta e Segura Para o Universo da Importação Lucrativa</h2>
        <div className="method-intro">
            <p>O R2B não é apenas mais um cursinho online. É uma <strong>formação completa e transformadora</strong> que pega você pela mão, desde o absoluto zero, e o transforma num especialista capaz de importar qualquer produto com total segurança.</p>
        </div>
        <div className="non-linear-flow">
            <div className="flow-node">
                <div className="node-content">
                    <div className="node-icon">
                        <img src="https://via.placeholder.com/40x40/FFFFFF/3A7BD5?text=🧠" alt="Ícone Mentalidade">
                    </div>
                    <h3>Mentalidade de Importador</h3>
                    <p>Desenvolva a visão estratégica necessária para identificar oportunidades e tomar decisões inteligentes.</p>
                    <button className="expand-btn">+</button>
                    <div className="expanded-content">
                        <p>Você aprenderá a pensar como um importador profissional, identificando tendências, calculando riscos e maximizando lucros.</p>
                    </div>
                </div>
                <div className="connector"></div>
            </div>
            <div className="flow-node">
                <div className="node-content">
                    <div className="node-icon">
                        <img src="https://via.placeholder.com/40x40/FFFFFF/3A7BD5?text=🔍" alt="Ícone Pesquisa">
                    </div>
                    <h3>Pesquisa Estratégica</h3>
                    <p>Descubra como encontrar produtos com alta demanda e fornecedores confiáveis nos EUA e China.</p>
                    <button className="expand-btn">+</button>
                    <div className="expanded-content">
                        <p>Técnicas avançadas para identificar produtos com alto potencial de lucro e baixa concorrência no mercado brasileiro.</p>
                    </div>
                </div>
                <div className="connector"></div>
            </div>
            <div className="flow-node">
                <div className="node-content">
                    <div className="node-icon">
                        <img src="https://via.placeholder.com/40x40/FFFFFF/3A7BD5?text=📊" alt="Ícone Calculadora">
                    </div>
                    <h3>Cálculo Preciso</h3>
                    <p>Aprenda a calcular todos os custos envolvidos ANTES de realizar qualquer compra internacional.</p>
                    <button className="expand-btn">+</button>
                    <div className="expanded-content">
                        <p>Domine nossa planilha exclusiva que calcula automaticamente impostos, taxas e custos logísticos para qualquer produto.</p>
                    </div>
                </div>
                <div className="connector"></div>
            </div>
            <div className="flow-node">
                <div className="node-content">
                    <div className="node-icon">
                        <img src="https://via.placeholder.com/40x40/FFFFFF/3A7BD5?text=🚚" alt="Ícone Envio">
                    </div>
                    <h3>Logística Otimizada</h3>
                    <p>Domine o uso de redirecionadores e consolidadores para economizar significativamente no frete.</p>
                    <button className="expand-btn">+</button>
                    <div className="expanded-content">
                        <p>Estratégias para reduzir custos de envio em até 70% e garantir que seus produtos cheguem com segurança e rapidez.</p>
                    </div>
                </div>
                <div className="connector"></div>
            </div>
            <div className="flow-node">
                <div className="node-content">
                    <div className="node-icon">
                        <img src="https://via.placeholder.com/40x40/FFFFFF/3A7BD5?text=🏛️" alt="Ícone Alfândega">
                    </div>
                    <h3>Descomplicando a Alfândega</h3>
                    <p>Entenda como funciona a tributação e aprenda a navegar pelo processo alfandegário sem problemas.</p>
                    <button className="expand-btn">+</button>
                    <div className="expanded-content">
                        <p>Técnicas 100% legais para minimizar impostos e garantir que seus produtos não sejam retidos na alfândega.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Secção 4: Módulos do Curso -->
    <section className="modules-section" id="modulos">
        <h2 className="centered">Mergulhe no Conhecimento Que Vai Revolucionar Suas Importações</h2>
        <div className="module-grid">
            <div className="module-card">
                <div className="module-number">01</div>
                <h3>A Base Sólida do Importador Inteligente</h3>
                <ul className="module-topics">
                    <li>Mentalidade correta para importar com sucesso</li>
                    <li>Desmistificando termos técnicos da importação</li>
                    <li>Panorama dos principais mercados globais</li>
                    <li>Identificação de oportunidades escondidas</li>
                </ul>
                <div className="module-result">
                    <h4>Resultado Prático:</h4>
                    <p>Visão clara do mundo da importação, pronto para tomar decisões informadas e evitar erros comuns.</p>
                </div>
            </div>
            <div className="module-card">
                <div className="module-number">02</div>
                <h3>Encontrando Produtos Vencedores e Fornecedores de Ouro</h3>
                <ul className="module-topics">
                    <li>Técnicas para garimpar produtos com alta demanda</li>
                    <li>Como encontrar fornecedores ultra confiáveis</li>
                    <li>Negociação internacional como um profissional</li>
                    <li>Garantindo originalidade e qualidade dos produtos</li>
                </ul>
                <div className="module-result">
                    <h4>Resultado Prático:</h4>
                    <p>Arsenal de estratégias para encontrar produtos campeões e fornecedores parceiros confiáveis.</p>
                </div>
            </div>
            <div className="module-card">
                <div className="module-number">03</div>
                <h3>Descomplicando a Alfândega e os Impostos</h3>
                <ul className="module-topics">
                    <li>Tributação brasileira para importações explicada</li>
                    <li>Cálculo preciso de impostos (II, IPI, ICMS)</li>
                    <li>Estratégias 100% legais para minimizar custos</li>
                    <li>Documentação necessária e como prepará-la</li>
                </ul>
                <div className="module-result">
                    <h4>Resultado Prático:</h4>
                    <p>Domínio total sobre custos de importação, com segurança e previsibilidade.</p>
                </div>
            </div>
            <div className="module-card">
                <div className="module-number">04</div>
                <h3>Redirecionadores de Encomendas - O Segredo para Economizar</h3>
                <ul className="module-topics">
                    <li>Escolhendo os melhores e mais baratos serviços</li>
                    <li>Consolidação de compras num único frete</li>
                    <li>Otimização de peso e dimensões dos pacotes</li>
                    <li>Rastreamento e segurança das encomendas</li>
                </ul>
                <div className="module-result">
                    <h4>Resultado Prático:</h4>
                    <p>Transforme o frete internacional no seu aliado, economizando centenas ou milhares de reais.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Secção 5: Métricas e Resultados -->
    <section className="metrics-section">
        <h2 className="centered">O Impacto Real do R2B em Números</h2>
        <div className="metrics-container">
            <div className="metric-item">
                <div className="metric-value" data-value="3500">0</div>
                <div className="metric-label">Alunos Transformados</div>
            </div>
            <div className="metric-item">
                <div className="metric-value" data-value="70">0</div>
                <div className="metric-label">% de Economia Média</div>
            </div>
            <div className="metric-item">
                <div className="metric-value" data-value="12.5">0</div>
                <div className="metric-label">Milhões Economizados</div>
            </div>
            <div className="metric-item">
                <div className="metric-value" data-value="98.7">0</div>
                <div className="metric-label">% de Satisfação</div>
            </div>
        </div>
    </section>

    <!-- Secção 6: Testemunhos -->
    <section className="testimonials-section" id="depoimentos">
        <h2 className="centered">Não Acredite Apenas em Nossas Palavras</h2>
        <div className="testimonial-container">
            <div className="testimonial-item">
                <div className="testimonial-image">
                    <img src="https://via.placeholder.com/500x200/3A7BD5/FFFFFF?text=João+Silva" alt="João Silva">
                </div>
                <div className="testimonial-content">
                    <p>"O R2B mudou completamente minha visão sobre importação! Antes eu tinha muito medo, mas agora consigo comprar produtos incríveis economizando muito. Em apenas 3 meses, já economizei mais de R$ 8.000 em compras pessoais."</p>
                    <div className="testimonial-author">
                        <strong>João Silva</strong>
                        <span>São Paulo/SP</span>
                    </div>
                </div>
            </div>
            <div className="testimonial-item video">
                <div className="testimonial-video">
                    <iframe width="100%" height="100%" src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Depoimento de Maria Oliveira" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div className="testimonial-content">
                    <p>"Consegui montar minha loja online graças ao R2B! Hoje importo diretamente da China e vendo no Brasil com uma margem incrível. Meu faturamento mensal já ultrapassou R$ 15.000 e continua crescendo."</p>
                    <div className="testimonial-author">
                        <strong>Maria Oliveira</strong>
                        <span>Rio de Janeiro/RJ</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Secção 7: Bónus -->
    <section className="bonuses-section">
        <h2 className="centered">🎁 OFERTA ESPECIAL: Bónus Exclusivos Para Quem Agir Agora!</h2>
        <div className="bonuses-container">
            <div className="bonus-item">
                <div className="bonus-icon">
                    <img src="imagens/icon-savings.png" alt="Planilha de Cálculos">
                </div>
                <div className="bonus-content">
                    <h3>BÓNUS #1: Planilha Mágica de Cálculo de Custos</h3>
                    <p>Nossa planilha exclusiva e automatizada para você saber INSTANTANEAMENTE todos os custos envolvidos na sua importação.</p>
                    <div className="bonus-value">R$ 197</div>
                </div>
            </div>
            <div className="bonus-item">
                <div className="bonus-icon">
                    <img src="imagens/icon-redirect.png" alt="Lista de Fornecedores">
                </div>
                <div className="bonus-content">
                    <h3>BÓNUS #2: Lista VIP de Fornecedores e Redirecionadores</h3>
                    <p>Acesso à nossa lista secreta com os melhores fornecedores e redirecionadores testados e aprovados.</p>
                    <div className="bonus-value">R$ 497</div>
                </div>
            </div>
            <div className="bonus-item">
                <div className="bonus-icon">
                    <img src="imagens/icon-suppliers.png" alt="Comunidade">
                </div>
                <div className="bonus-content">
                    <h3>BÓNUS #3: Acesso à Comunidade Secreta de Alunos</h3>
                    <p>Troque experiências, tire dúvidas e faça networking no nosso grupo VIP exclusivo.</p>
                    <div className="bonus-value">R$ 497/ano</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Secção 8: FAQ -->
    <section className="faq-section">
        <h2 className="centered">Perguntas Frequentes</h2>
        <div className="faq-filter">
            <div className="faq-search">
                <input type="text" id="faqSearchInput" className="faq-search-input" placeholder="Buscar pergunta...">
                <button id="faqSearchBtn" className="faq-search-btn"><i className="fas fa-search"></i></button>
            </div>
            <div className="faq-categories">
                <button className="category-btn active" data-category="all">Todas</button>
                <button className="category-btn" data-category="curso">Sobre o Curso</button>
                <button className="category-btn" data-category="pagamento">Pagamento</button>
                <button className="category-btn" data-category="importacao">Importação</button>
            </div>
        </div>
        <div className="faq-list">
            <div className="faq-item" data-category="curso">
                <div className="faq-question">
                    <h3>Preciso ter experiência prévia com importação?</h3>
                    <button className="accordion-toggle">+</button>
                </div>
                <div className="faq-answer">
                    <p>Não! O R2B foi desenhado para levar você do absoluto zero ao nível avançado. Explicamos tudo passo a passo, sem jargões complicados, para que qualquer pessoa possa aprender, mesmo sem nenhuma experiência prévia.</p>
                </div>
            </div>
            <div className="faq-item" data-category="pagamento">
                <div className="faq-question">
                    <h3>Como funciona a garantia de 7 dias?</h3>
                    <button className="accordion-toggle">+</button>
                </div>
                <div className="faq-answer">
                    <p>É simples: você tem 7 dias para testar o curso. Se não gostar por qualquer motivo, basta enviar um e-mail para suporte@r2b.com.br solicitando o reembolso. Devolveremos 100% do seu dinheiro, sem perguntas e sem burocracia.</p>
                </div>
            </div>
            <div className="faq-item" data-category="importacao">
                <div className="faq-question">
                    <h3>É realmente possível economizar até 70% nas importações?</h3>
                    <button className="accordion-toggle">+</button>
                </div>
                <div className="faq-answer">
                    <p>Sim! Dependendo do produto e da estratégia utilizada, é possível economizar entre 30% e 70% em comparação com os preços praticados no Brasil. No curso, mostramos exatamente como calcular essa economia para cada tipo de produto.</p>
                </div>
            </div>
            <div className="faq-item" data-category="curso">
                <div className="faq-question">
                    <h3>Por quanto tempo terei acesso ao curso?</h3>
                    <button className="accordion-toggle">+</button>
                </div>
                <div className="faq-answer">
                    <p>O acesso é vitalício! Você poderá assistir às aulas quantas vezes quiser, para sempre. Além disso, todas as atualizações futuras do curso serão incluídas sem custo adicional.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Secção 9: Oferta e CTA Final -->
    <section className="offer-section" id="oferta">
        <div className="offer-container">
            <h2>Sua Decisão Agora Define Seu Futuro na Importação</h2>
            <div className="offer-content">
                <div className="offer-value">
                    <div className="offer-item">
                        <span className="offer-label">Curso Completo R2B:</span>
                        <span className="offer-price">R$ 1.997</span>
                    </div>
                    <div className="offer-item">
                        <span className="offer-label">Bónus Exclusivos:</span>
                        <span className="offer-price">R$ 1.191</span>
                    </div>
                    <div className="offer-item total">
                        <span className="offer-label">Valor Total:</span>
                        <span className="offer-price">R$ 3.188</span>
                    </div>
                </div>
                <div className="offer-discount">
                    <div className="discount-badge">
                        <span>DESCONTO ESPECIAL</span>
                        <span className="discount-value">84% OFF</span>
                    </div>
                    <div className="final-price">
                        <div className="old-price">De R$ 3.188 por apenas:</div>
                        <div className="current-price">12x de R$ 49,90</div>
                        <div className="cash-price">ou R$ 497 à vista!</div>
                    </div>
                </div>
            </div>
            <div className="final-cta">
                <a href="#" className="cta-button primary">🚀 SIM! QUERO TRANSFORMAR MINHAS IMPORTAÇÕES AGORA! 🚀</a>
                <p className="security-badges">
                    <span><i className="fas fa-lock"></i> Pagamento 100% Seguro</span>
                    <span><i className="fas fa-bolt"></i> Acesso Imediato</span>
                    <span><i className="fas fa-shield-alt"></i> Garantia de 7 Dias</span>
                </p>
            </div>
        </div>
    </section>

    <!-- Secção 10: Garantia -->
    <section className="guarantee-section">
        <div className="guarantee-container">
            <div className="guarantee-seal">
                <img src="imagens/seal-guarantee.png" alt="Selo de Garantia 7 Dias">
            </div>
            <div className="guarantee-content">
                <h2>Garantia Incondicional de 7 Dias</h2>
                <p>Experimente o R2B sem risco algum. Se em até 7 dias você não estiver completamente satisfeito, por qualquer motivo, basta nos enviar um e-mail e devolveremos 100% do seu dinheiro. Sem perguntas, sem burocracia.</p>
                <p>Assumimos todo o risco porque confiamos no poder transformador do nosso método.</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer className="main-footer">
        <div className="footer-content">
            <div className="footer-logo">
                <div className="logo-text">R2B</div>
            </div>
            <div className="footer-links">
                <div className="footer-column">
                    <h3>Links Rápidos</h3>
                    <ul>
                        <li><a href="#metodo">O Método</a></li>
                        <li><a href="#modulos">Módulos</a></li>
                        <li><a href="#depoimentos">Depoimentos</a></li>
                        <li><a href="#oferta">Garantir Vaga</a></li>
                    </ul>
                </div>
                <div className="footer-column">
                    <h3>Suporte</h3>
                    <ul>
                        <li><a href="#">Política de Privacidade</a></li>
                        <li><a href="#">Termos de Uso</a></li>
                        <li><a href="#">Política de Reembolso</a></li>
                        <li><a href="#">Fale Conosco</a></li>
                    </ul>
                </div>
                <div className="footer-column">
                    <h3>Contato</h3>
                    <ul>
                        <li><a href="mailto:suporte@r2b.com.br">suporte@r2b.com.br</a></li>
                        <li><a href="tel:+5511999999999">+55 (11) 99999-9999</a></li>
                        <li>Horário: Seg-Sex, 9h às 18h</li>
                    </ul>
                </div>
            </div>
        </div>
        <div className="footer-bottom">
            <p>&copy; 2025 R2B - Redirecionadora two Brasil. Todos os direitos reservados.</p>
        </div>
    </footer>

    <script src="script.js"></script>

</>
  )
}
