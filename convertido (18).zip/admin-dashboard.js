export default function Page() {
  return (
    <>
    <!-- Loading Screen -->
    <div id="loadingScreen" className="loading">
        <div>
            <i className="fas fa-spinner fa-spin" style="margin-right: 12px; font-size: 24px;"></i>
            Carregando Dashboard...
        </div>
    </div>

    <!-- Main App -->
    <div id="mainApp" style="display: none;">
        <div className="app-container">
            <!-- Sidebar -->
            <div id="sidebar" className="sidebar">
                <div className="sidebar-header">
                    <div className="sidebar-title">R2B Admin</div>
                    <button id="sidebarClose" className="sidebar-close">
                        <i className="fas fa-times"></i>
                    </button>
                </div>

                <nav className="sidebar-nav">
                    <button className="nav-item active" data-section="dashboard">
                        <i className="fas fa-chart-bar"></i>
                        Dashboard
                    </button>
                    <button className="nav-item" data-section="users">
                        <i className="fas fa-users"></i>
                        Usuários
                    </button>
                    <button className="nav-item" data-section="analytics">
                        <i className="fas fa-chart-line"></i>
                        Estatísticas
                    </button>
                    <button className="nav-item" data-section="content">
                        <i className="fas fa-file-text"></i>
                        Conteúdo
                    </button>
                    <button className="nav-item" data-section="support">
                        <i className="fas fa-comments"></i>
                        Suporte
                    </button>
                    <button className="nav-item" data-section="financial">
                        <i className="fas fa-dollar-sign"></i>
                        Financeiro
                    </button>
                    <button className="nav-item" data-section="settings">
                        <i className="fas fa-cog"></i>
                        Configurações
                    </button>
                    <button className="nav-item" data-section="tickets">
                        <i className="fas fa-ticket-alt"></i>
                        Tickets
                    </button>
                </nav>

                <div className="sidebar-user">
                    <div className="user-info">
                        <div className="user-avatar">
                            <i className="fas fa-shield-alt"></i>
                        </div>
                        <div className="user-details">
                            <div className="user-name">Administrador</div>
                            <div className="user-email">admin@r2b.com.br</div>
                        </div>
                        <button id="logoutSidebar" className="logout-btn">
                            <i className="fas fa-sign-out-alt"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div className="main-content">
                <!-- Header -->
                <header className="header">
                    <div className="header-content">
                        <div className="header-left">
                            <button id="menuToggle" className="menu-toggle">
                                <i className="fas fa-bars"></i>
                            </button>
                            <div className="header-title">
                                <h1 id="pageTitle">Dashboard</h1>
                                <div className="header-subtitle">Painel de controle administrativo</div>
                            </div>
                        </div>

                        <div className="header-right">
                            <button className="notification-btn">
                                <i className="fas fa-bell"></i>
                                <span className="notification-badge"></span>
                            </button>
                            <button id="logoutHeader" className="logout-header">
                                <i className="fas fa-sign-out-alt"></i>
                                <span className="logout-text">Sair</span>
                            </button>
                        </div>
                    </div>
                </header>

                <!-- Dashboard Content -->
                <main className="dashboard-content">
                    <!-- Dashboard Overview -->
                    <div id="dashboard-section" className="section-content active">
                        <!-- Stats Cards -->
                        <div className="stats-grid">
                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Total de Usuários</h3>
                                        <div className="stat-value">1,247</div>
                                    </div>
                                    <div className="stat-icon blue">
                                        <i className="fas fa-users"></i>
                                    </div>
                                </div>
                                <div className="stat-footer positive">
                                    <i className="fas fa-trending-up"></i>
                                    +12.5% este mês
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Usuários Ativos</h3>
                                        <div className="stat-value">892</div>
                                    </div>
                                    <div className="stat-icon green">
                                        <i className="fas fa-chart-line"></i>
                                    </div>
                                </div>
                                <div className="stat-footer">
                                    <i className="fas fa-clock"></i>
                                    Últimos 7 dias
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Novos Hoje</h3>
                                        <div className="stat-value">23</div>
                                    </div>
                                    <div className="stat-icon orange">
                                        <i className="fas fa-user-plus"></i>
                                    </div>
                                </div>
                                <div className="stat-footer">
                                    <i className="fas fa-calendar"></i>
                                    Últimas 24h
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Tempo Médio</h3>
                                        <div className="stat-value">12m 34s</div>
                                    </div>
                                    <div className="stat-icon purple">
                                        <i className="fas fa-clock"></i>
                                    </div>
                                </div>
                                <div className="stat-footer">
                                    <i className="fas fa-eye"></i>
                                    Por sessão
                                </div>
                            </div>
                        </div>

                        <!-- Charts -->
                        <div className="charts-grid">
                            <div className="chart-card">
                                <h3 className="chart-title">Acessos Diários</h3>
                                <div className="chart-container">
                                    <canvas id="accessChart"></canvas>
                                </div>
                            </div>

                            <div className="chart-card">
                                <h3 className="chart-title">Novos Cadastros</h3>
                                <div className="chart-container">
                                    <canvas id="registrationChart"></canvas>
                                </div>
                            </div>
                        </div>

                        <!-- Recent Activity -->
                        <div className="charts-grid">
                            <div className="table-card">
                                <div className="table-header">
                                    <h3 className="table-title">Páginas Mais Acessadas</h3>
                                </div>
                                <div className="table-container">
                                    <table className="data-table">
                                        <thead>
                                            <tr>
                                                <th>Página</th>
                                                <th>Visualizações</th>
                                                <th>Tempo Médio</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>/aluno</td>
                                                <td>2,341</td>
                                                <td>8m 45s</td>
                                            </tr>
                                            <tr>
                                                <td>/aluno/modulos</td>
                                                <td>1,876</td>
                                                <td>12m 23s</td>
                                            </tr>
                                            <tr>
                                                <td>/aluno/materiais</td>
                                                <td>1,234</td>
                                                <td>6m 12s</td>
                                            </tr>
                                            <tr>
                                                <td>/</td>
                                                <td>987</td>
                                                <td>3m 45s</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div className="table-card">
                                <div className="table-header">
                                    <h3 className="table-title">Atividade Recente</h3>
                                </div>
                                <div style="padding: 28px;">
                                    <div style="margin-bottom: 20px; padding: 20px; border: 1px solid #e5e7eb; border-radius: 12px; transition: all 0.2s;" onmouseover="this.style.borderColor='#f97316'" onmouseout="this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                            <div style="width: 10px; height: 10px; background: #f97316; border-radius: 50%;"></div>
                                            <strong style="color: #111827;">Novo ticket de suporte</strong>
                                        </div>
                                        <div style="color: #6b7280; font-size: 14px; margin-bottom: 6px;">João Silva</div>
                                        <div style="color: #9ca3af; font-size: 12px;">Há 5 minutos</div>
                                    </div>
                                    <div style="margin-bottom: 20px; padding: 20px; border: 1px solid #e5e7eb; border-radius: 12px; transition: all 0.2s;" onmouseover="this.style.borderColor='#f97316'" onmouseout="this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                            <div style="width: 10px; height: 10px; background: #16a34a; border-radius: 50%;"></div>
                                            <strong style="color: #111827;">Novo usuário cadastrado</strong>
                                        </div>
                                        <div style="color: #6b7280; font-size: 14px; margin-bottom: 6px;">Maria Santos</div>
                                        <div style="color: #9ca3af; font-size: 12px;">Há 15 minutos</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Users Section -->
                    <div id="users-section" className="section-content">
                        <div style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 32px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                                <div>
                                    <h2 style="font-size: 32px; font-weight: 800; color: #111827; margin-bottom: 8px;">Gestão de Usuários</h2>
                                    <p style="color: #6b7280; font-size: 16px;">Gerencie todos os usuários da plataforma</p>
                                </div>
                                <div style="display: flex; gap: 12px;">
                                    <button className="btn btn-secondary">
                                        <i className="fas fa-download"></i>
                                        Exportar CSV
                                    </button>
                                    <button className="btn btn-primary">
                                        <i className="fas fa-plus"></i>
                                        Novo Usuário
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Filters -->
                        <div className="filters-card">
                            <div className="filters-row">
                                <div className="search-input">
                                    <i className="fas fa-search search-icon"></i>
                                    <input type="text" id="userSearch" placeholder="Buscar por nome ou email...">
                                </div>
                                <select id="userFilter" className="filter-select">
                                    <option value="all">Todos os usuários</option>
                                    <option value="aluno">Apenas alunos</option>
                                    <option value="admin">Apenas admins</option>
                                </select>
                            </div>
                        </div>

                        <!-- Users Table -->
                        <div className="table-card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Usuário</th>
                                            <th>Tipo</th>
                                            <th>Status</th>
                                            <th>Registro</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody id="usersTableBody">
                                        <tr>
                                            <td>
                                                <div>
                                                    <div style="font-weight: 600; color: #111827; margin-bottom: 4px;">João Silva</div>
                                                    <div style="font-size: 14px; color: #6b7280;">joao@email.com</div>
                                                </div>
                                            </td>
                                            <td><span className="badge blue">aluno</span></td>
                                            <td><span className="badge green">Ativo</span></td>
                                            <td style="color: #6b7280;">15/01/2024</td>
                                            <td>
                                                <div style="display: flex; gap: 8px;">
                                                    <button className="action-btn view"><i className="fas fa-eye"></i></button>
                                                    <button className="action-btn edit"><i className="fas fa-edit"></i></button>
                                                    <button className="action-btn delete"><i className="fas fa-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div>
                                                    <div style="font-weight: 600; color: #111827; margin-bottom: 4px;">Maria Santos</div>
                                                    <div style="font-size: 14px; color: #6b7280;">maria@email.com</div>
                                                </div>
                                            </td>
                                            <td><span className="badge blue">aluno</span></td>
                                            <td><span className="badge green">Ativo</span></td>
                                            <td style="color: #6b7280;">14/01/2024</td>
                                            <td>
                                                <div style="display: flex; gap: 8px;">
                                                    <button className="action-btn view"><i className="fas fa-eye"></i></button>
                                                    <button className="action-btn edit"><i className="fas fa-edit"></i></button>
                                                    <button className="action-btn delete"><i className="fas fa-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div>
                                                    <div style="font-weight: 600; color: #111827; margin-bottom: 4px;">Pedro Costa</div>
                                                    <div style="font-size: 14px; color: #6b7280;">pedro@email.com</div>
                                                </div>
                                            </td>
                                            <td><span className="badge blue">aluno</span></td>
                                            <td><span className="badge red">Inativo</span></td>
                                            <td style="color: #6b7280;">13/01/2024</td>
                                            <td>
                                                <div style="display: flex; gap: 8px;">
                                                    <button className="action-btn view"><i className="fas fa-eye"></i></button>
                                                    <button className="action-btn edit"><i className="fas fa-edit"></i></button>
                                                    <button className="action-btn delete"><i className="fas fa-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div>
                                                    <div style="font-weight: 600; color: #111827; margin-bottom: 4px;">Ana Oliveira</div>
                                                    <div style="font-size: 14px; color: #6b7280;">ana@email.com</div>
                                                </div>
                                            </td>
                                            <td><span className="badge purple">admin</span></td>
                                            <td><span className="badge green">Ativo</span></td>
                                            <td style="color: #6b7280;">12/01/2024</td>
                                            <td>
                                                <div style="display: flex; gap: 8px;">
                                                    <button className="action-btn view"><i className="fas fa-eye"></i></button>
                                                    <button className="action-btn edit"><i className="fas fa-edit"></i></button>
                                                    <button className="action-btn delete"><i className="fas fa-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Analytics Section -->
                    <div id="analytics-section" className="section-content">
                        <div style="margin-bottom: 32px;">
                            <h2 style="font-size: 32px; font-weight: 800; color: #111827; margin-bottom: 8px;">Estatísticas e Performance</h2>
                            <p style="color: #6b7280; font-size: 16px;">Análise detalhada do desempenho da plataforma</p>
                        </div>
                        
                        <div className="charts-grid">
                            <div className="chart-card" style="grid-column: span 2;">
                                <h3 className="chart-title">Acessos vs Cadastros</h3>
                                <div className="chart-container">
                                    <canvas id="analyticsChart"></canvas>
                                </div>
                            </div>

                            <div className="chart-card">
                                <h3 className="chart-title">Distribuição de Usuários</h3>
                                <div className="chart-container">
                                    <canvas id="userDistributionChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Section -->
                    <div id="content-section" className="section-content">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px;">
                            <div>
                                <h2 style="font-size: 32px; font-weight: 800; color: #111827; margin-bottom: 8px;">Gerenciamento de Conteúdo</h2>
                                <p style="color: #6b7280; font-size: 16px;">Gerencie dicas, links e materiais da plataforma</p>
                            </div>
                            <button className="btn btn-primary">
                                <i className="fas fa-plus"></i>
                                Novo Conteúdo
                            </button>
                        </div>

                        <div className="charts-grid">
                            <div className="table-card">
                                <div className="table-header">
                                    <h3 className="table-title">Dicas para Alunos</h3>
                                </div>
                                <div style="padding: 28px;">
                                    <div style="border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin-bottom: 20px; transition: all 0.2s;" onmouseover="this.style.borderColor='#f97316'" onmouseout="this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                                            <h4 style="font-weight: 600; color: #111827;">Como calcular impostos</h4>
                                            <span className="badge blue">Importação</span>
                                        </div>
                                        <p style="font-size: 14px; color: #6b7280; margin-bottom: 16px; line-height: 1.5;">Guia completo para calcular impostos de importação...</p>
                                        <div style="display: flex; gap: 12px;">
                                            <button className="btn btn-sm" style="background: #3b82f6; color: white;">Editar</button>
                                            <button className="btn btn-sm" style="background: #dc2626; color: white;">Excluir</button>
                                        </div>
                                    </div>
                                    <div style="border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; transition: all 0.2s;" onmouseover="this.style.borderColor='#f97316'" onmouseout="this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                                            <h4 style="font-weight: 600; color: #111827;">Melhores fornecedores</h4>
                                            <span className="badge green">Fornecedores</span>
                                        </div>
                                        <p style="font-size: 14px; color: #6b7280; margin-bottom: 16px; line-height: 1.5;">Lista atualizada dos melhores fornecedores...</p>
                                        <div style="display: flex; gap: 12px;">
                                            <button className="btn btn-sm" style="background: #3b82f6; color: white;">Editar</button>
                                            <button className="btn btn-sm" style="background: #dc2626; color: white;">Excluir</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="table-card">
                                <div className="table-header">
                                    <h3 className="table-title">Links Úteis por Nicho</h3>
                                </div>
                                <div style="padding: 28px;">
                                    <div style="border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin-bottom: 20px; transition: all 0.2s;" onmouseover="this.style.borderColor='#f97316'" onmouseout="this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                                            <h4 style="font-weight: 600; color: #111827;">Roupas e Acessórios</h4>
                                            <span className="badge purple">15 links</span>
                                        </div>
                                        <p style="font-size: 14px; color: #6b7280; margin-bottom: 16px; line-height: 1.5;">Fornecedores especializados em moda...</p>
                                        <div style="display: flex; gap: 12px;">
                                            <button className="btn btn-sm" style="background: #3b82f6; color: white;">Gerenciar</button>
                                            <button className="btn btn-sm" style="background: #16a34a; color: white;">Adicionar Link</button>
                                        </div>
                                    </div>
                                    <div style="border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; transition: all 0.2s;" onmouseover="this.style.borderColor='#f97316'" onmouseout="this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                                            <h4 style="font-weight: 600; color: #111827;">Eletrônicos</h4>
                                            <span className="badge purple">23 links</span>
                                        </div>
                                        <p style="font-size: 14px; color: #6b7280; margin-bottom: 16px; line-height: 1.5;">Fornecedores de eletrônicos confiáveis...</p>
                                        <div style="display: flex; gap: 12px;">
                                            <button className="btn btn-sm" style="background: #3b82f6; color: white;">Gerenciar</button>
                                            <button className="btn btn-sm" style="background: #16a34a; color: white;">Adicionar Link</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Support Section -->
                    <div id="support-section" className="section-content">
                        <div style="margin-bottom: 32px;">
                            <h2 style="font-size: 32px; font-weight: 800; color: #111827; margin-bottom: 8px;">Suporte e Mensagens</h2>
                            <p style="color: #6b7280; font-size: 16px;">Gerencie mensagens e solicitações de suporte</p>
                        </div>
                        
                        <div className="charts-grid">
                            <div className="table-card">
                                <div className="table-header">
                                    <h3 className="table-title">Status das Mensagens</h3>
                                </div>
                                <div style="padding: 28px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding: 12px; background: #fef3e2; border-radius: 8px;">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <div style="width: 12px; height: 12px; background: #f97316; border-radius: 50%;"></div>
                                            <span style="font-size: 14px; color: #92400e; font-weight: 600;">Pendentes</span>
                                        </div>
                                        <span style="font-size: 18px; font-weight: 700; color: #92400e;">12</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding: 12px; background: #dcfce7; border-radius: 8px;">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <div style="width: 12px; height: 12px; background: #16a34a; border-radius: 50%;"></div>
                                            <span style="font-size: 14px; color: #166534; font-weight: 600;">Resolvidas</span>
                                        </div>
                                        <span style="font-size: 18px; font-weight: 700; color: #166534;">45</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; background: #dbeafe; border-radius: 8px;">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <div style="width: 12px; height: 12px; background: #3b82f6; border-radius: 50%;"></div>
                                            <span style="font-size: 14px; color: #1e40af; font-weight: 600;">Em andamento</span>
                                        </div>
                                        <span style="font-size: 18px; font-weight: 700; color: #1e40af;">8</span>
                                    </div>
                                </div>
                            </div>

                            <div className="table-card" style="grid-column: span 2;">
                                <div className="table-header">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <h3 className="table-title">Mensagens Recentes</h3>
                                        <button className="btn btn-primary">Ver todas</button>
                                    </div>
                                </div>
                                <div style="padding: 28px;">
                                    <div style="border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin-bottom: 20px; transition: all 0.2s;" onmouseover="this.style.borderColor='#f97316'" onmouseout="this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 12px;">
                                            <div>
                                                <h4 style="font-weight: 600; color: #111827; margin-bottom: 4px;">Dúvida sobre importação</h4>
                                                <p style="font-size: 14px; color: #6b7280;">Por: João Silva</p>
                                            </div>
                                            <div style="display: flex; gap: 8px;">
                                                <span className="badge orange">Pendente</span>
                                                <button className="action-btn view"><i className="fas fa-eye"></i></button>
                                            </div>
                                        </div>
                                        <p style="font-size: 14px; color: #374151; margin-bottom: 16px; line-height: 1.5;">Como calcular os impostos de importação?</p>
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span style="font-size: 12px; color: #9ca3af;">15/01/2024</span>
                                            <div style="display: flex; gap: 12px;">
                                                <button className="btn btn-sm" style="background: #16a34a; color: white;">Responder</button>
                                                <button className="btn btn-sm" style="background: #3b82f6; color: white;">Marcar como resolvida</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Financial Section -->
                    <div id="financial-section" className="section-content">
                        <div style="margin-bottom: 32px;">
                            <h2 style="font-size: 32px; font-weight: 800; color: #111827; margin-bottom: 8px;">Financeiro</h2>
                            <p style="color: #6b7280; font-size: 16px;">Acompanhe receitas, vendas e métricas financeiras</p>
                        </div>
                        
                        <div className="stats-grid">
                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Receita Total</h3>
                                        <div className="stat-value">R$ 45,670</div>
                                    </div>
                                    <div className="stat-icon green">
                                        <i className="fas fa-dollar-sign"></i>
                                    </div>
                                </div>
                                <div className="stat-footer positive">
                                    <i className="fas fa-trending-up"></i>
                                    +15.3% este mês
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Vendas Este Mês</h3>
                                        <div className="stat-value">127</div>
                                    </div>
                                    <div className="stat-icon blue">
                                        <i className="fas fa-chart-line"></i>
                                    </div>
                                </div>
                                <div className="stat-footer">
                                    <i className="fas fa-calendar"></i>
                                    Janeiro 2024
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Ticket Médio</h3>
                                        <div className="stat-value">R$ 359</div>
                                    </div>
                                    <div className="stat-icon purple">
                                        <i className="fas fa-chart-bar"></i>
                                    </div>
                                </div>
                                <div className="stat-footer positive">
                                    <i className="fas fa-trending-up"></i>
                                    +8.2% vs mês anterior
                                </div>
                            </div>
                        </div>

                        <div className="chart-card">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                <h3 className="chart-title">Vendas por Período</h3>
                                <button className="btn btn-primary">
                                    <i className="fas fa-download"></i>
                                    Exportar Relatório
                                </button>
                            </div>
                            <div className="chart-container">
                                <canvas id="salesChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Settings Section -->
                    <div id="settings-section" className="section-content">
                        <div style="margin-bottom: 32px;">
                            <h2 style="font-size: 32px; font-weight: 800; color: #111827; margin-bottom: 8px;">Configurações do Sistema</h2>
                            <p style="color: #6b7280; font-size: 16px;">Gerencie configurações e status do sistema</p>
                        </div>
                        
                        <div className="charts-grid">
                            <div className="table-card">
                                <div className="table-header">
                                    <h3 className="table-title">Status do Sistema</h3>
                                </div>
                                <div style="padding: 28px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding: 16px; background: #dcfce7; border-radius: 10px;">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i className="fas fa-check-circle" style="color: #16a34a; font-size: 18px;"></i>
                                            <span style="color: #166534; font-weight: 600;">API Principal</span>
                                        </div>
                                        <span style="font-size: 14px; font-weight: 600; color: #16a34a;">Online</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding: 16px; background: #dcfce7; border-radius: 10px;">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i className="fas fa-check-circle" style="color: #16a34a; font-size: 18px;"></i>
                                            <span style="color: #166534; font-weight: 600;">Banco de Dados</span>
                                        </div>
                                        <span style="font-size: 14px; font-weight: 600; color: #16a34a;">Conectado</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding: 16px; background: #fef3e2; border-radius: 10px;">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i className="fas fa-exclamation-circle" style="color: #f97316; font-size: 18px;"></i>
                                            <span style="color: #92400e; font-weight: 600;">Sistema de Email</span>
                                        </div>
                                        <span style="font-size: 14px; font-weight: 600; color: #f97316;">Lento</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 16px; background: #dcfce7; border-radius: 10px;">
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <i className="fas fa-check-circle" style="color: #16a34a; font-size: 18px;"></i>
                                            <span style="color: #166534; font-weight: 600;">CDN</span>
                                        </div>
                                        <span style="font-size: 14px; font-weight: 600; color: #16a34a;">Operacional</span>
                                    </div>
                                </div>
                            </div>

                            <div className="table-card">
                                <div className="table-header">
                                    <h3 className="table-title">Ferramentas Administrativas</h3>
                                </div>
                                <div style="padding: 28px;">
                                    <button style="width: 100%; text-align: left; padding: 16px; border: 1px solid #e5e7eb; border-radius: 12px; background: white; cursor: pointer; margin-bottom: 16px; transition: all 0.2s; font-weight: 500;" onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#f97316'" onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span style="color: #374151;">Limpar usuários inativos</span>
                                            <i className="fas fa-chevron-right" style="color: #9ca3af;"></i>
                                        </div>
                                    </button>
                                    <button style="width: 100%; text-align: left; padding: 16px; border: 1px solid #e5e7eb; border-radius: 12px; background: white; cursor: pointer; margin-bottom: 16px; transition: all 0.2s; font-weight: 500;" onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#f97316'" onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span style="color: #374151;">Log de atividades</span>
                                            <i className="fas fa-chevron-right" style="color: #9ca3af;"></i>
                                        </div>
                                    </button>
                                    <button style="width: 100%; text-align: left; padding: 16px; border: 1px solid #e5e7eb; border-radius: 12px; background: white; cursor: pointer; margin-bottom: 16px; transition: all 0.2s; font-weight: 500;" onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#f97316'" onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span style="color: #374151;">Backup do sistema</span>
                                            <i className="fas fa-chevron-right" style="color: #9ca3af;"></i>
                                        </div>
                                    </button>
                                    <button style="width: 100%; text-align: left; padding: 16px; border: 1px solid #e5e7eb; border-radius: 12px; background: white; cursor: pointer; transition: all 0.2s; font-weight: 500;" onmouseover="this.style.background='#f9fafb'; this.style.borderColor='#f97316'" onmouseout="this.style.background='white'; this.style.borderColor='#e5e7eb'">
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span style="color: #374151;">Configurações de email</span>
                                            <i className="fas fa-chevron-right" style="color: #9ca3af;"></i>
                                        </div>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tickets Section -->
                    <div id="tickets-section" className="section-content">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px;">
                            <div>
                                <h2 style="font-size: 32px; font-weight: 800; color: #111827; margin-bottom: 8px;">Gerenciamento de Tickets</h2>
                                <p style="color: #6b7280; font-size: 16px;">Gerencie todos os tickets de suporte dos usuários</p>
                            </div>
                            <div style="display: flex; gap: 12px;">
                                <button className="btn btn-secondary" onclick="exportTickets()">
                                    <i className="fas fa-download"></i>
                                    Exportar
                                </button>
                            </div>
                        </div>

                        <!-- Filters -->
                        <div className="filters-card">
                            <div className="filters-row">
                                <div className="search-input">
                                    <i className="fas fa-search search-icon"></i>
                                    <input type="text" id="ticketSearch" placeholder="Buscar por assunto ou usuário...">
                                </div>
                                <select id="ticketStatusFilter" className="filter-select">
                                    <option value="all">Todos os status</option>
                                    <option value="open">Em Aberto</option>
                                    <option value="answered">Respondidos</option>
                                    <option value="closed">Concluídos</option>
                                </select>
                                <select id="ticketCategoryFilter" className="filter-select">
                                    <option value="all">Todas as categorias</option>
                                    <option value="importacao">Importação</option>
                                    <option value="curso">Curso</option>
                                    <option value="pagamento">Pagamento</option>
                                    <option value="tecnico">Técnico</option>
                                    <option value="outros">Outros</option>
                                </select>
                            </div>
                        </div>

                        <!-- Tickets Stats -->
                        <div className="stats-grid" style="margin-bottom: 32px;">
                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Total de Tickets</h3>
                                        <div className="stat-value" id="totalTickets">0</div>
                                    </div>
                                    <div className="stat-icon blue">
                                        <i className="fas fa-ticket-alt"></i>
                                    </div>
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Em Aberto</h3>
                                        <div className="stat-value" id="openTickets">0</div>
                                    </div>
                                    <div className="stat-icon orange">
                                        <i className="fas fa-clock"></i>
                                    </div>
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Respondidos</h3>
                                        <div className="stat-value" id="answeredTickets">0</div>
                                    </div>
                                    <div className="stat-icon blue">
                                        <i className="fas fa-reply"></i>
                                    </div>
                                </div>
                            </div>

                            <div className="stat-card">
                                <div className="stat-header">
                                    <div className="stat-info">
                                        <h3>Concluídos</h3>
                                        <div className="stat-value" id="closedTickets">0</div>
                                    </div>
                                    <div className="stat-icon green">
                                        <i className="fas fa-check-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tickets Table -->
                        <div className="table-card">
                            <div className="table-container">
                                <table className="data-table">
                                    <thead>
                                        <tr>
                                            <th>Ticket</th>
                                            <th>Usuário</th>
                                            <th>Categoria</th>
                                            <th>Status</th>
                                            <th>Data</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody id="ticketsTableBody">
                                        <!-- Tickets serão carregados aqui -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- Overlay -->
    <div id="overlay" className="overlay"></div>

    <!-- Modal de Resposta -->
    <div id="responseModal" className="modal" style="display: none;">
        <div className="modal-content">
            <div className="modal-header">
                <h3>Responder Ticket</h3>
                <button onclick="closeResponseModal()" className="modal-close">&times;</button>
            </div>
            
            <div id="ticketDetails" style="margin-bottom: 24px; padding: 20px; background: #f9fafb; border-radius: 12px;">
                <!-- Detalhes do ticket -->
            </div>
            
            <form id="responseForm">
                <div className="form-group">
                    <label>Resposta:</label>
                    <textarea id="responseText" rows="5" placeholder="Digite sua resposta..." required></textarea>
                </div>
                
                <div className="form-group">
                    <label>Novo Status:</label>
                    <select id="newStatus">
                        <option value="answered">Respondido</option>
                        <option value="closed">Concluído</option>
                    </select>
                </div>
                
                <div style="display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" onclick="closeResponseModal()" className="btn" style="background: #e5e7eb; color: #374151;">Cancelar</button>
                    <button type="submit" className="btn btn-primary">Enviar Resposta</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Mock data
        const mockUsers = [
            { id: 1, name: "João Silva", email: "joao@email.com", type: "aluno", registeredAt: "2024-01-15", status: "active" },
            { id: 2, name: "Maria Santos", email: "maria@email.com", type: "aluno", registeredAt: "2024-01-14", status: "active" },
            { id: 3, name: "Pedro Costa", email: "pedro@email.com", type: "aluno", registeredAt: "2024-01-13", status: "inactive" },
            { id: 4, name: "Ana Oliveira", email: "ana@email.com", type: "admin", registeredAt: "2024-01-12", status: "active" },
            { id: 5, name: "Carlos Lima", email: "carlos@email.com", type: "aluno", registeredAt: "2024-01-11", status: "active" }
        ];

        const mockAccessData = [
            { date: "01/01", acessos: 120, cadastros: 15 },
            { date: "02/01", acessos: 145, cadastros: 22 },
            { date: "03/01", acessos: 167, cadastros: 18 },
            { date: "04/01", acessos: 189, cadastros: 25 },
            { date: "05/01", acessos: 201, cadastros: 30 },
            { date: "06/01", acessos: 178, cadastros: 19 },
            { date: "07/01", acessos: 234, cadastros: 28 }
        ];

        // Global variables
        let currentSection = 'dashboard';
        let charts = {};

        // Initialize app
        document.addEventListener('DOMContentLoaded', function() {
            checkAuth();
            initializeEventListeners();
            initializeCharts();
        });

        // Authentication check
        function checkAuth() {
            const savedUser = localStorage.getItem('r2b_user');
            if (savedUser) {
                const userData = JSON.parse(savedUser);
                if (userData.role === 'admin') {
                    showMainApp();
                } else {
                    redirectToHome();
                }
            } else {
                redirectToHome();
            }
        }

        function showMainApp() {
            document.getElementById('loadingScreen').style.display = 'none';
            document.getElementById('mainApp').style.display = 'block';
        }

        function redirectToHome() {
            window.location.href = 'index.html';
        }

        // Event listeners
        function initializeEventListeners() {
            // Sidebar toggle
            document.getElementById('menuToggle').addEventListener('click', toggleSidebar);
            document.getElementById('sidebarClose').addEventListener('click', closeSidebar);
            document.getElementById('overlay').addEventListener('click', closeSidebar);

            // Navigation
            document.querySelectorAll('.nav-item').forEach(item => {
                item.addEventListener('click', function() {
                    const section = this.getAttribute('data-section');
                    navigateToSection(section);
                });
            });

            // Logout buttons
            document.getElementById('logoutSidebar').addEventListener('click', logout);
            document.getElementById('logoutHeader').addEventListener('click', logout);

            // User filters
            document.getElementById('userSearch').addEventListener('input', filterUsers);
            document.getElementById('userFilter').addEventListener('change', filterUsers);

            // Ticket filters
            document.getElementById('ticketSearch').addEventListener('input', filterTickets);
            document.getElementById('ticketStatusFilter').addEventListener('change', filterTickets);
            document.getElementById('ticketCategoryFilter').addEventListener('change', filterTickets);
            document.getElementById('responseForm').addEventListener('submit', handleTicketResponse);
        }

        // Sidebar functions
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');
            
            if (window.innerWidth < 1024) {
                sidebar.classList.toggle('open');
                overlay.classList.toggle('show');
            }
        }

        function closeSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');
            
            sidebar.classList.remove('open');
            overlay.classList.remove('show');
        }

        // Navigation
        function navigateToSection(section) {
            // Update active nav item
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            document.querySelector(`[data-section="${section}"]`).classList.add('active');

            // Update page title
            const titles = {
                'dashboard': 'Dashboard',
                'users': 'Usuários',
                'analytics': 'Estatísticas',
                'content': 'Conteúdo',
                'support': 'Suporte',
                'financial': 'Financeiro',
                'settings': 'Configurações',
                'tickets': 'Tickets'
            };
            document.getElementById('pageTitle').textContent = titles[section];

            // Show/hide sections
            document.querySelectorAll('.section-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(`${section}-section`).classList.add('active');

            currentSection = section;
            closeSidebar();

            if (section === 'tickets') {
                loadTickets();
            }
        }

        // User filtering
        function filterUsers() {
            const searchTerm = document.getElementById('userSearch').value.toLowerCase();
            const filterType = document.getElementById('userFilter').value;
            
            const filteredUsers = mockUsers.filter(user => {
                const matchesSearch = user.name.toLowerCase().includes(searchTerm) || 
                                    user.email.toLowerCase().includes(searchTerm);
                const matchesFilter = filterType === 'all' || user.type === filterType;
                return matchesSearch && matchesFilter;
            });

            renderUsersTable(filteredUsers);
        }

        function renderUsersTable(users) {
            const tbody = document.getElementById('usersTableBody');
            tbody.innerHTML = '';

            users.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>
                        <div>
                            <div style="font-weight: 600; color: #111827; margin-bottom: 4px;">${user.name}</div>
                            <div style="font-size: 14px; color: #6b7280;">${user.email}</div>
                        </div>
                    </td>
                    <td><span className="badge ${user.type === 'admin' ? 'purple' : 'blue'}">${user.type}</span></td>
                    <td><span className="badge ${user.status === 'active' ? 'green' : 'red'}">${user.status === 'active' ? 'Ativo' : 'Inativo'}</span></td>
                    <td style="color: #6b7280;">${user.registeredAt}</td>
                    <td>
                        <div style="display: flex; gap: 8px;">
                            <button className="action-btn view"><i className="fas fa-eye"></i></button>
                            <button className="action-btn edit"><i className="fas fa-edit"></i></button>
                            <button className="action-btn delete"><i className="fas fa-trash"></i></button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        // Charts initialization
        function initializeCharts() {
            // Access Chart
            const accessCtx = document.getElementById('accessChart').getContext('2d');
            charts.accessChart = new Chart(accessCtx, {
                type: 'line',
                data: {
                    labels: mockAccessData.map(d => d.date),
                    datasets: [{
                        label: 'Acessos',
                        data: mockAccessData.map(d => d.acessos),
                        borderColor: '#f97316',
                        backgroundColor: 'rgba(249, 115, 22, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#f3f4f6'
                            }
                        },
                        x: {
                            grid: {
                                color: '#f3f4f6'
                            }
                        }
                    }
                }
            });

            // Registration Chart
            const registrationCtx = document.getElementById('registrationChart').getContext('2d');
            charts.registrationChart = new Chart(registrationCtx, {
                type: 'bar',
                data: {
                    labels: mockAccessData.map(d => d.date),
                    datasets: [{
                        label: 'Cadastros',
                        data: mockAccessData.map(d => d.cadastros),
                        backgroundColor: '#3b82f6',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#f3f4f6'
                            }
                        },
                        x: {
                            grid: {
                                color: '#f3f4f6'
                            }
                        }
                    }
                }
            });

            // Analytics Chart
            const analyticsCtx = document.getElementById('analyticsChart').getContext('2d');
            charts.analyticsChart = new Chart(analyticsCtx, {
                type: 'line',
                data: {
                    labels: mockAccessData.map(d => d.date),
                    datasets: [{
                        label: 'Acessos',
                        data: mockAccessData.map(d => d.acessos),
                        borderColor: '#f97316',
                        backgroundColor: 'rgba(249, 115, 22, 0.1)',
                        tension: 0.4
                    }, {
                        label: 'Cadastros',
                        data: mockAccessData.map(d => d.cadastros),
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#f3f4f6'
                            }
                        },
                        x: {
                            grid: {
                                color: '#f3f4f6'
                            }
                        }
                    }
                }
            });

            // User Distribution Chart
            const userDistCtx = document.getElementById('userDistributionChart').getContext('2d');
            charts.userDistributionChart = new Chart(userDistCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Alunos Ativos', 'Alunos Inativos', 'Admins'],
                    datasets: [{
                        data: [892, 345, 10],
                        backgroundColor: ['#f97316', '#3b82f6', '#10b981'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        }
                    }
                }
            });

            // Sales Chart
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            charts.salesChart = new Chart(salesCtx, {
                type: 'bar',
                data: {
                    labels: mockAccessData.map(d => d.date),
                    datasets: [{
                        label: 'Vendas',
                        data: mockAccessData.map(d => d.cadastros * 2),
                        backgroundColor: '#f97316',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#f3f4f6'
                            }
                        },
                        x: {
                            grid: {
                                color: '#f3f4f6'
                            }
                        }
                    }
                }
            });
        }

        // Ticket functions
        function loadTickets() {
            const tickets = JSON.parse(localStorage.getItem('r2b_tickets') || '[]');
            updateTicketStats(tickets);
            renderTicketsTable(tickets);
        }

        function updateTicketStats(tickets) {
            const total = tickets.length;
            const open = tickets.filter(t => t.status === 'open').length;
            const answered = tickets.filter(t => t.status === 'answered').length;
            const closed = tickets.filter(t => t.status === 'closed').length;
            
            document.getElementById('totalTickets').textContent = total;
            document.getElementById('openTickets').textContent = open;
            document.getElementById('answeredTickets').textContent = answered;
            document.getElementById('closedTickets').textContent = closed;
        }

        function renderTicketsTable(tickets) {
            const tbody = document.getElementById('ticketsTableBody');
            if (!tbody) return;
            
            if (tickets.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px; color: #6b7280;">Nenhum ticket encontrado</td></tr>';
                return;
            }
            
            const statusText = {
                open: 'Em Aberto',
                answered: 'Respondido',
                closed: 'Concluído'
            };
            
            const categoryText = {
                importacao: 'Importação',
                curso: 'Curso',
                pagamento: 'Pagamento',
                tecnico: 'Técnico',
                outros: 'Outros'
            };
            
            tbody.innerHTML = tickets.map(ticket => `
                <tr>
                    <td>
                        <div>
                            <div style="font-weight: 600; color: #111827; margin-bottom: 4px;">${ticket.subject}</div>
                            <div style="font-size: 14px; color: #6b7280;">#${ticket.id}</div>
                        </div>
                    </td>
                    <td>
                        <div>
                            <div style="font-weight: 500; color: #111827;">${ticket.userName}</div>
                            <div style="font-size: 14px; color: #6b7280;">${ticket.userId}</div>
                        </div>
                    </td>
                    <td><span className="badge blue">${categoryText[ticket.category] || ticket.category}</span></td>
                    <td><span className="badge ${ticket.status === 'open' ? 'orange' : ticket.status === 'answered' ? 'blue' : 'green'}">${statusText[ticket.status]}</span></td>
                    <td style="color: #6b7280;">${new Date(ticket.createdAt).toLocaleDateString('pt-BR')}</td>
                    <td>
                        <div style="display: flex; gap: 8px;">
                            <button className="action-btn view" onclick="viewTicket(${ticket.id})"><i className="fas fa-eye"></i></button>
                            ${ticket.status !== 'closed' ? `<button className="action-btn edit" onclick="respondTicket(${ticket.id})"><i className="fas fa-reply"></i></button>` : ''}
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        function filterTickets() {
            const searchTerm = document.getElementById('ticketSearch').value.toLowerCase();
            const statusFilter = document.getElementById('ticketStatusFilter').value;
            const categoryFilter = document.getElementById('ticketCategoryFilter').value;
            
            const tickets = JSON.parse(localStorage.getItem('r2b_tickets') || '[]');
            
            const filteredTickets = tickets.filter(ticket => {
                const matchesSearch = ticket.subject.toLowerCase().includes(searchTerm) || 
                                    ticket.userName.toLowerCase().includes(searchTerm) ||
                                    ticket.userId.toLowerCase().includes(searchTerm);
                const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter;
                const matchesCategory = categoryFilter === 'all' || ticket.category === categoryFilter;
                
                return matchesSearch && matchesStatus && matchesCategory;
            });
            
            renderTicketsTable(filteredTickets);
        }

        function viewTicket(ticketId) {
            const tickets = JSON.parse(localStorage.getItem('r2b_tickets') || '[]');
            const ticket = tickets.find(t => t.id === ticketId);
            
            if (ticket) {
                alert(`Ticket: ${ticket.subject}\n\nDescrição: ${ticket.description}\n\nUsuário: ${ticket.userName} (${ticket.userId})\n\nStatus: ${ticket.status}`);
            }
        }

        function respondTicket(ticketId) {
            const tickets = JSON.parse(localStorage.getItem('r2b_tickets') || '[]');
            const ticket = tickets.find(t => t.id === ticketId);
            
            if (ticket) {
                document.getElementById('ticketDetails').innerHTML = `
                    <h4 style="margin-bottom: 12px; color: #111827; font-size: 18px;">${ticket.subject}</h4>
                    <p style="margin-bottom: 8px; color: #6b7280;"><strong>Usuário:</strong> ${ticket.userName} (${ticket.userId})</p>
                    <p style="margin-bottom: 8px; color: #6b7280;"><strong>Categoria:</strong> ${ticket.category}</p>
                    <p style="color: #374151; line-height: 1.5;"><strong>Descrição:</strong> ${ticket.description}</p>
                `;
                
                document.getElementById('responseForm').dataset.ticketId = ticketId;
                document.getElementById('responseModal').style.display = 'flex';
            }
        }

        function closeResponseModal() {
            document.getElementById('responseModal').style.display = 'none';
            document.getElementById('responseText').value = '';
            document.getElementById('newStatus').value = 'answered';
        }

        function handleTicketResponse(e) {
            e.preventDefault();
            
            const ticketId = parseInt(e.target.dataset.ticketId);
            const responseText = document.getElementById('responseText').value;
            const newStatus = document.getElementById('newStatus').value;
            
            const tickets = JSON.parse(localStorage.getItem('r2b_tickets') || '[]');
            const ticketIndex = tickets.findIndex(t => t.id === ticketId);
            
            if (ticketIndex !== -1) {
                tickets[ticketIndex].response = responseText;
                tickets[ticketIndex].status = newStatus;
                tickets[ticketIndex].responseAt = new Date().toISOString();
                
                localStorage.setItem('r2b_tickets', JSON.stringify(tickets));
                
                closeResponseModal();
                loadTickets();
                
                alert('Resposta enviada com sucesso!');
            }
        }

        function exportTickets() {
            const tickets = JSON.parse(localStorage.getItem('r2b_tickets') || '[]');
            
            if (tickets.length === 0) {
                alert('Não há tickets para exportar.');
                return;
            }
            
            const csv = [
                ['ID', 'Usuário', 'Email', 'Assunto', 'Categoria', 'Status', 'Data Criação', 'Resposta'],
                ...tickets.map(ticket => [
                    ticket.id,
                    ticket.userName,
                    ticket.userId,
                    ticket.subject,
                    ticket.category,
                    ticket.status,
                    new Date(ticket.createdAt).toLocaleDateString('pt-BR'),
                    ticket.response || ''
                ])
            ].map(row => row.join(',')).join('\n');
            
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'tickets.csv';
            a.click();
            window.URL.revokeObjectURL(url);
        }

        // Logout function
        function logout() {
            localStorage.removeItem('r2b_user');
            window.location.href = 'index.html';
        }

        // Responsive handling
        window.addEventListener('resize', function() {
            if (window.innerWidth >= 1024) {
                closeSidebar();
            }
        });
    </script>
</>
  )
}
