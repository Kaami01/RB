"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"
import {
  Search,
  Edit,
  Trash2,
  Mail,
  Users,
  UserPlus,
  Upload,
  Copy,
  CheckCircle,
  XCircle,
  Clock,
  MapPin,
  User,
  Phone,
  Loader2,
} from "lucide-react"

interface Student {
  id: number
  name: string
  email: string
  phone?: string
  cpf?: string
  birth_date?: string
  cep?: string
  street?: string
  number?: string
  complement?: string
  neighborhood?: string
  city?: string
  state?: string
  status: string
  created_at: string
  updated_at: string
}

export function StudentsSection({ students, setStudents, onRefresh }: any) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [isCreating, setIsCreating] = useState(false)
  const [isBulkCreating, setIsBulkCreating] = useState(false)
  const [editingStudent, setEditingStudent] = useState<Student | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const filteredStudents = students.filter((student: Student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (student.cpf && student.cpf.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (student.city && student.city.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesStatus = filterStatus === "all" || student.status === filterStatus
    return matchesSearch && matchesStatus
  })

  const handleCreateStudent = async (studentData: any) => {
    console.log("Creating student with data:", studentData)
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/students", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(studentData),
      })

      console.log("Response status:", response.status)
      console.log("Response headers:", Object.fromEntries(response.headers.entries()))

      const responseText = await response.text()
      console.log("Response text:", responseText)

      let result
      try {
        result = JSON.parse(responseText)
      } catch (parseError) {
        console.error("Failed to parse response as JSON:", parseError)
        throw new Error(`Invalid response format: ${responseText}`)
      }

      if (!response.ok) {
        console.error("API error:", result)
        throw new Error(result.error || `HTTP ${response.status}: ${result.details || "Unknown error"}`)
      }

      console.log("Student created successfully:", result)

      setStudents([result, ...students])
      setIsCreating(false)

      toast({
        title: "✅ Estudante criado com sucesso!",
        description: `${result.name} foi adicionado. ${result.email_sent ? "Email enviado!" : "Email não enviado."}`,
      })

      if (result.temporary_password) {
        toast({
          title: "🔑 Senha temporária gerada",
          description: `Senha: ${result.temporary_password}`,
          duration: 10000,
        })
      }

      onRefresh()
    } catch (error: any) {
      console.error("Error creating student:", error)
      toast({
        title: "❌ Erro ao criar estudante",
        description: error.message || "Erro desconhecido. Verifique o console para mais detalhes.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdateStudent = async (studentData: any) => {
    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/students/${editingStudent!.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(studentData),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to update student")
      }

      const updatedStudent = await response.json()
      setStudents(students.map((student: Student) => (student.id === updatedStudent.id ? updatedStudent : student)))
      setEditingStudent(null)

      toast({
        title: "✅ Estudante atualizado!",
        description: "Dados atualizados com sucesso.",
      })

      onRefresh()
    } catch (error: any) {
      toast({
        title: "❌ Erro ao atualizar estudante",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteStudent = async (studentId: number) => {
    if (!confirm("Tem certeza que deseja remover este estudante? Esta ação não pode ser desfeita.")) {
      return
    }

    try {
      const response = await fetch(`/api/students/${studentId}`, {
        method: "DELETE",
      })

      if (!response.ok) throw new Error("Failed to delete student")

      setStudents(students.filter((student: Student) => student.id !== studentId))

      toast({
        title: "🗑️ Estudante removido",
        description: "O estudante foi removido da plataforma.",
        variant: "destructive",
      })

      onRefresh()
    } catch (error) {
      toast({
        title: "❌ Erro ao remover estudante",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      })
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "📋 Copiado!",
      description: "Texto copiado para a área de transferência.",
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-700">Ativo</Badge>
      case "inactive":
        return <Badge className="bg-red-100 text-red-700">Inativo</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-700">Pendente</Badge>
      default:
        return <Badge className="bg-gray-100 text-gray-700">{status}</Badge>
    }
  }

  const formatCPF = (cpf: string) => {
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  const formatCEP = (cep: string) => {
    return cep.replace(/(\d{5})(\d{3})/, "$1-$2")
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Gerenciar Estudantes</h2>
          <p className="text-gray-600">Crie e gerencie contas de estudantes com dados completos</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setIsBulkCreating(true)}
            variant="outline"
            className="border-indigo-300 text-indigo-700 hover:bg-indigo-50"
          >
            <Upload className="h-4 w-4 mr-2" />
            Importar em Lote
          </Button>
          <Button
            onClick={() => setIsCreating(true)}
            className="bg-indigo-600 hover:bg-indigo-700 shadow-lg"
            disabled={isSubmitting}
          >
            {isSubmitting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <UserPlus className="h-4 w-4 mr-2" />}
            Novo Estudante
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total de Estudantes</p>
                <p className="text-2xl font-bold text-gray-900">{students.length}</p>
              </div>
              <Users className="h-8 w-8 text-indigo-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Estudantes Ativos</p>
                <p className="text-2xl font-bold text-green-600">
                  {students.filter((s: Student) => s.status === "active").length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Estudantes Inativos</p>
                <p className="text-2xl font-bold text-red-600">
                  {students.filter((s: Student) => s.status === "inactive").length}
                </p>
              </div>
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pendentes</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {students.filter((s: Student) => s.status === "pending").length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por nome, email, CPF ou cidade..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-gray-300"
              />
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">Todos os status</option>
              <option value="active">Ativo</option>
              <option value="inactive">Inativo</option>
              <option value="pending">Pendente</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Students Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStudents.map((student: Student) => (
          <Card key={student.id} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start mb-2">
                {getStatusBadge(student.status)}
                <div className="text-xs text-gray-500">ID: {student.id}</div>
              </div>
              <CardTitle className="text-lg">{student.name}</CardTitle>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <span className="text-gray-600 truncate">{student.email}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(student.email)}
                    className="h-6 w-6 p-0"
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>

                {student.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">{student.phone}</span>
                  </div>
                )}

                {student.cpf && (
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">{formatCPF(student.cpf)}</span>
                  </div>
                )}

                {student.city && student.state && (
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">
                      {student.city}, {student.state}
                    </span>
                  </div>
                )}

                {student.birth_date && (
                  <div className="text-xs text-gray-500">
                    Nascimento: {new Date(student.birth_date).toLocaleDateString()}
                  </div>
                )}

                <div className="text-xs text-gray-500">
                  Criado em {new Date(student.created_at).toLocaleDateString()}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-2">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingStudent(student)}
                  className="border-blue-300 text-blue-700 hover:bg-blue-50"
                  disabled={isSubmitting}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDeleteStudent(student.id)}
                  className="border-red-300 text-red-700 hover:bg-red-50"
                  disabled={isSubmitting}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredStudents.length === 0 && (
        <Card className="border-0 shadow-lg">
          <CardContent className="p-12 text-center">
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Nenhum estudante encontrado</h3>
            <p className="text-gray-600 mb-6">
              {searchTerm ? "Tente outros termos de busca." : "Comece criando seu primeiro estudante!"}
            </p>
            {!searchTerm && (
              <Button
                onClick={() => setIsCreating(true)}
                className="bg-indigo-600 hover:bg-indigo-700"
                disabled={isSubmitting}
              >
                <UserPlus className="h-4 w-4 mr-2" />
                Criar Primeiro Estudante
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Modal */}
      <StudentFormModal
        isOpen={isCreating || editingStudent !== null}
        onClose={() => {
          setIsCreating(false)
          setEditingStudent(null)
        }}
        onSubmit={editingStudent ? handleUpdateStudent : handleCreateStudent}
        student={editingStudent}
        mode={editingStudent ? "edit" : "create"}
        isSubmitting={isSubmitting}
      />

      {/* Bulk Create Modal */}
      <BulkStudentModal isOpen={isBulkCreating} onClose={() => setIsBulkCreating(false)} onSubmit={() => {}} />
    </div>
  )
}

// Modal para criar/editar estudante
function StudentFormModal({ isOpen, onClose, onSubmit, student, mode, isSubmitting }: any) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    cpf: "",
    birth_date: "",
    cep: "",
    street: "",
    number: "",
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
    status: "active",
    send_email: true,
  })

  const [isLoadingCEP, setIsLoadingCEP] = useState(false)

  useEffect(() => {
    if (student) {
      setFormData({
        name: student.name || "",
        email: student.email || "",
        phone: student.phone || "",
        cpf: student.cpf || "",
        birth_date: student.birth_date || "",
        cep: student.cep || "",
        street: student.street || "",
        number: student.number || "",
        complement: student.complement || "",
        neighborhood: student.neighborhood || "",
        city: student.city || "",
        state: student.state || "",
        status: student.status || "active",
        send_email: false,
      })
    } else {
      setFormData({
        name: "",
        email: "",
        phone: "",
        cpf: "",
        birth_date: "",
        cep: "",
        street: "",
        number: "",
        complement: "",
        neighborhood: "",
        city: "",
        state: "",
        status: "active",
        send_email: true,
      })
    }
  }, [student, isOpen])

  const handleCEPChange = async (cep: string) => {
    setFormData({ ...formData, cep })

    // Remove caracteres não numéricos
    const cleanCEP = cep.replace(/[^\d]/g, "")

    if (cleanCEP.length === 8) {
      setIsLoadingCEP(true)
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanCEP}/json/`)
        const data = await response.json()

        if (!data.erro) {
          setFormData((prev) => ({
            ...prev,
            street: data.logradouro || "",
            neighborhood: data.bairro || "",
            city: data.localidade || "",
            state: data.uf || "",
          }))
        }
      } catch (error) {
        console.error("Erro ao buscar CEP:", error)
      } finally {
        setIsLoadingCEP(false)
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted with data:", formData)
    onSubmit(formData)
  }

  const formatCPFInput = (value: string) => {
    const numbers = value.replace(/[^\d]/g, "")
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  const formatCEPInput = (value: string) => {
    const numbers = value.replace(/[^\d]/g, "")
    return numbers.replace(/(\d{5})(\d{3})/, "$1-$2")
  }

  const formatPhoneInput = (value: string) => {
    const numbers = value.replace(/[^\d]/g, "")
    if (numbers.length <= 10) {
      return numbers.replace(/(\d{2})(\d{4})(\d{4})/, "($1) $2-$3")
    } else {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")
    }
  }

  const estados = [
    "AC",
    "AL",
    "AP",
    "AM",
    "BA",
    "CE",
    "DF",
    "ES",
    "GO",
    "MA",
    "MT",
    "MS",
    "MG",
    "PA",
    "PB",
    "PR",
    "PE",
    "PI",
    "RJ",
    "RN",
    "RS",
    "RO",
    "RR",
    "SC",
    "SP",
    "SE",
    "TO",
  ]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{mode === "edit" ? "Editar Estudante" : "Novo Estudante"}</DialogTitle>
          <DialogDescription>
            {mode === "edit"
              ? "Edite as informações do estudante abaixo."
              : "Preencha as informações para criar um novo estudante."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Dados Pessoais */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Dados Pessoais</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nome Completo *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: João Silva Santos"
                  required
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="joao@email.com"
                  required
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="cpf">CPF</Label>
                <Input
                  id="cpf"
                  value={formData.cpf}
                  onChange={(e) => setFormData({ ...formData, cpf: formatCPFInput(e.target.value) })}
                  placeholder="123.456.789-01"
                  maxLength={14}
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="birth_date">Data de Nascimento</Label>
                <Input
                  id="birth_date"
                  type="date"
                  value={formData.birth_date}
                  onChange={(e) => setFormData({ ...formData, birth_date: e.target.value })}
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: formatPhoneInput(e.target.value) })}
                  placeholder="(11) 99999-9999"
                  maxLength={15}
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value })}
                  disabled={isSubmitting}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Ativo</SelectItem>
                    <SelectItem value="inactive">Inativo</SelectItem>
                    <SelectItem value="pending">Pendente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Endereço */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Endereço</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="cep">CEP</Label>
                <Input
                  id="cep"
                  value={formData.cep}
                  onChange={(e) => handleCEPChange(formatCEPInput(e.target.value))}
                  placeholder="12345-678"
                  maxLength={9}
                  disabled={isSubmitting}
                />
                {isLoadingCEP && <p className="text-xs text-gray-500 mt-1">Buscando endereço...</p>}
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="street">Logradouro</Label>
                <Input
                  id="street"
                  value={formData.street}
                  onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                  placeholder="Rua das Flores"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="number">Número</Label>
                <Input
                  id="number"
                  value={formData.number}
                  onChange={(e) => setFormData({ ...formData, number: e.target.value })}
                  placeholder="123"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="complement">Complemento</Label>
                <Input
                  id="complement"
                  value={formData.complement}
                  onChange={(e) => setFormData({ ...formData, complement: e.target.value })}
                  placeholder="Apto 101"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="neighborhood">Bairro</Label>
                <Input
                  id="neighborhood"
                  value={formData.neighborhood}
                  onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                  placeholder="Centro"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="city">Cidade</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="São Paulo"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <Label htmlFor="state">Estado</Label>
                <Select
                  value={formData.state}
                  onValueChange={(value) => setFormData({ ...formData, state: value })}
                  disabled={isSubmitting}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="UF" />
                  </SelectTrigger>
                  <SelectContent>
                    {estados.map((estado) => (
                      <SelectItem key={estado} value={estado}>
                        {estado}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Configurações */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 border-b pb-2">Configurações</h3>
            {mode === "create" && (
              <div className="flex items-center space-x-2">
                <Switch
                  id="send_email"
                  checked={formData.send_email}
                  onCheckedChange={(checked) => setFormData({ ...formData, send_email: checked })}
                  disabled={isSubmitting}
                />
                <Label htmlFor="send_email">Enviar email de boas-vindas com credenciais</Label>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  {mode === "edit" ? "Salvando..." : "Criando..."}
                </>
              ) : mode === "edit" ? (
                "Salvar Alterações"
              ) : (
                "Criar Estudante"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

// Modal para importação em lote (simplificado)
function BulkStudentModal({ isOpen, onClose, onSubmit }: any) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Importar Estudantes em Lote</DialogTitle>
          <DialogDescription>
            Funcionalidade em desenvolvimento. Use a criação individual por enquanto.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button onClick={onClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
