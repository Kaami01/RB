export default function Page() {
  return (
    <>
    <!-- Sidebar -->
    <div id="sidebar" className="sidebar">
        <div className="sidebar-header">
            <div className="logo">
                <i className="fas fa-globe"></i>
                <span>R2B Hub</span>
            </div>
        </div>

        <nav className="sidebar-nav">
            <a href="#dicas" className="nav-item active" data-section="dicas">
                <i className="fas fa-lightbulb"></i>
                <span>Dicas de Importação</span>
            </a>
            <a href="#comunidade" className="nav-item" data-section="comunidade">
                <i className="fas fa-comments"></i>
                <span>Comunidade</span>
            </a>
            <a href="#links" className="nav-item" data-section="links">
                <i className="fas fa-shopping-cart"></i>
                <span>Links de Compra</span>
            </a>
            <a href="#ferramentas" className="nav-item" data-section="ferramentas">
                <i className="fas fa-tools"></i>
                <span>Ferramentas</span>
            </a>
            <a href="#suporte" className="nav-item" data-section="suporte">
                <i className="fas fa-headset"></i>
                <span>Suporte</span>
            </a>
        </nav>

        <div className="sidebar-footer">
            <div className="user-profile">
                <img src="https://via.placeholder.com/40x40/FF7A00/FFFFFF?text=JS" alt="Avatar" className="user-avatar">
                <div className="user-info">
                    <p className="user-name">João Silva</p>
                    <p className="user-status">Membro Premium</p>
                </div>
                <button id="logoutBtn" className="logout-btn">
                    <i className="fas fa-sign-out-alt"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Header -->
    <header className="mobile-header">
        <button id="menuToggle" className="menu-toggle">
            <i className="fas fa-bars"></i>
        </button>
        <div className="mobile-logo">
            <i className="fas fa-globe"></i>
            <span>R2B Hub</span>
        </div>
        <button id="mobileLogout" className="mobile-logout">
            <i className="fas fa-sign-out-alt"></i>
        </button>
    </header>

    <!-- Main Content -->
    <main className="main-content">
        <!-- Dicas de Importação -->
        <section id="dicas-section" className="content-section active">
            <div className="section-header">
                <h1><i className="fas fa-lightbulb"></i> Dicas de Importação</h1>
                <p>Dicas estratégicas para maximizar seus lucros na importação</p>
            </div>

            <div className="tips-filters">
                <button className="filter-btn active" data-category="all">Todas</button>
                <button className="filter-btn" data-category="roupas">Roupas</button>
                <button className="filter-btn" data-category="tenis">Tênis</button>
                <button className="filter-btn" data-category="perfumes">Perfumes</button>
                <button className="filter-btn" data-category="eletronicos">Eletrônicos</button>
            </div>

            <div className="tips-grid">
                <div className="tip-card" data-category="roupas">
                    <div className="tip-category">Roupas</div>
                    <h3>Como Identificar Tecidos de Qualidade</h3>
                    <p>Aprenda a avaliar a qualidade dos tecidos antes de importar roupas, evitando produtos de baixa qualidade...</p>
                    <div className="tip-meta">
                        <span className="tip-date">Há 2 dias</span>
                        <button className="tip-expand">Ver mais</button>
                    </div>
                </div>

                <div className="tip-card" data-category="tenis">
                    <div className="tip-category">Tênis</div>
                    <h3>Melhores Épocas para Importar Calçados</h3>
                    <p>Descubra os períodos ideais para importar tênis e aproveitar as melhores oportunidades de mercado...</p>
                    <div className="tip-meta">
                        <span className="tip-date">Há 4 dias</span>
                        <button className="tip-expand">Ver mais</button>
                    </div>
                </div>

                <div className="tip-card" data-category="perfumes">
                    <div className="tip-category">Perfumes</div>
                    <h3>Cuidados no Transporte de Fragrâncias</h3>
                    <p>Dicas essenciais para garantir que seus perfumes cheguem em perfeitas condições, evitando vazamentos...</p>
                    <div className="tip-meta">
                        <span className="tip-date">Há 1 semana</span>
                        <button className="tip-expand">Ver mais</button>
                    </div>
                </div>

                <div className="tip-card" data-category="eletronicos">
                    <div className="tip-category">Eletrônicos</div>
                    <h3>Documentação para Eletrônicos</h3>
                    <p>Entenda quais documentos são necessários para importar eletrônicos sem problemas na alfândega...</p>
                    <div className="tip-meta">
                        <span className="tip-date">Há 1 semana</span>
                        <button className="tip-expand">Ver mais</button>
                    </div>
                </div>

                <div className="tip-card" data-category="roupas">
                    <div className="tip-category">Roupas</div>
                    <h3>Tabelas de Medidas Internacionais</h3>
                    <p>Guia completo para entender as diferenças entre tabelas de medidas de diferentes países...</p>
                    <div className="tip-meta">
                        <span className="tip-date">Há 2 semanas</span>
                        <button className="tip-expand">Ver mais</button>
                    </div>
                </div>

                <div className="tip-card" data-category="tenis">
                    <div className="tip-category">Tênis</div>
                    <h3>Verificação de Autenticidade</h3>
                    <p>Como identificar tênis originais e evitar produtos falsificados em suas importações...</p>
                    <div className="tip-meta">
                        <span className="tip-date">Há 2 semanas</span>
                        <button className="tip-expand">Ver mais</button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Comunidade -->
        <section id="comunidade-section" className="content-section">
            <div className="section-header">
                <h1><i className="fas fa-comments"></i> Comunidade por Nichos</h1>
                <p>Conecte-se com outros importadores e compartilhe experiências</p>
            </div>

            <div className="community-grid">
                <div className="community-card">
                    <div className="community-icon">
                        <i className="fas fa-tshirt"></i>
                    </div>
                    <h3>Roupas & Moda</h3>
                    <p>Discussões sobre importação de roupas, tendências e fornecedores</p>
                    <div className="community-stats">
                        <span><i className="fas fa-users"></i> 1.2k membros</span>
                        <span><i className="fas fa-circle online"></i> 89 online</span>
                    </div>
                    <button className="join-btn">Entrar no Grupo</button>
                </div>

                <div className="community-card">
                    <div className="community-icon">
                        <i className="fas fa-running"></i>
                    </div>
                    <h3>Tênis & Calçados</h3>
                    <p>Especialistas em importação de calçados esportivos e casuais</p>
                    <div className="community-stats">
                        <span><i className="fas fa-users"></i> 856 membros</span>
                        <span><i className="fas fa-circle online"></i> 45 online</span>
                    </div>
                    <button className="join-btn">Entrar no Grupo</button>
                </div>

                <div className="community-card">
                    <div className="community-icon">
                        <i className="fas fa-spray-can"></i>
                    </div>
                    <h3>Perfumes & Cosméticos</h3>
                    <p>Comunidade focada em fragrâncias e produtos de beleza</p>
                    <div className="community-stats">
                        <span><i className="fas fa-users"></i> 634 membros</span>
                        <span><i className="fas fa-circle online"></i> 23 online</span>
                    </div>
                    <button className="join-btn">Entrar no Grupo</button>
                </div>

                <div className="community-card">
                    <div className="community-icon">
                        <i className="fas fa-mobile-alt"></i>
                    </div>
                    <h3>Eletrônicos & Tech</h3>
                    <p>Importação de gadgets, smartphones e tecnologia</p>
                    <div className="community-stats">
                        <span><i className="fas fa-users"></i> 923 membros</span>
                        <span><i className="fas fa-circle online"></i> 67 online</span>
                    </div>
                    <button className="join-btn">Entrar no Grupo</button>
                </div>

                <div className="community-card featured">
                    <div className="community-icon">
                        <i className="fas fa-star"></i>
                    </div>
                    <h3>Grupo Geral VIP</h3>
                    <p>Discussões gerais, networking e oportunidades exclusivas</p>
                    <div className="community-stats">
                        <span><i className="fas fa-users"></i> 2.8k membros</span>
                        <span><i className="fas fa-circle online"></i> 156 online</span>
                    </div>
                    <button className="join-btn premium">Acesso Premium</button>
                </div>
            </div>

            <div className="live-chat">
                <h3><i className="fas fa-comments"></i> Chat Ao Vivo</h3>
                <div className="chat-container">
                    <div className="chat-messages">
                        <div className="message">
                            <span className="user">@carlos_imports:</span>
                            <span className="text">Alguém já importou da AliExpress recentemente?</span>
                            <span className="time">14:32</span>
                        </div>
                        <div className="message">
                            <span className="user">@maria_fashion:</span>
                            <span className="text">Sim! Chegou tudo certinho em 15 dias</span>
                            <span className="time">14:35</span>
                        </div>
                        <div className="message">
                            <span className="user">@tech_lover:</span>
                            <span className="text">Cuidado com eletrônicos, tem muito produto falsificado</span>
                            <span className="time">14:38</span>
                        </div>
                    </div>
                    <div className="chat-input">
                        <input type="text" placeholder="Digite sua mensagem...">
                        <button><i className="fas fa-paper-plane"></i></button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Links de Compra -->
        <section id="links-section" className="content-section">
            <div className="section-header">
                <h1><i className="fas fa-shopping-cart"></i> Links de Compra Curados</h1>
                <p>Links verificados e organizados por nossa equipe</p>
            </div>

            <div className="links-controls">
                <div className="search-bar">
                    <i className="fas fa-search"></i>
                    <input type="text" id="linkSearch" placeholder="Buscar produtos...">
                </div>
                <div className="links-filters">
                    <select id="categoryFilter">
                        <option value="all">Todas as categorias</option>
                        <option value="roupas">Roupas</option>
                        <option value="tenis">Tênis</option>
                        <option value="perfumes">Perfumes</option>
                        <option value="eletronicos">Eletrônicos</option>
                    </select>
                    <select id="storeFilter">
                        <option value="all">Todas as lojas</option>
                        <option value="aliexpress">AliExpress</option>
                        <option value="amazon">Amazon</option>
                        <option value="dhgate">DHgate</option>
                        <option value="1688">1688</option>
                    </select>
                </div>
            </div>

            <div className="links-grid">
                <div className="link-card" data-category="roupas" data-store="aliexpress">
                    <div className="link-image">
                        <img src="https://via.placeholder.com/200x150/FF7A00/FFFFFF?text=Camiseta" alt="Produto">
                        <div className="link-store">AliExpress</div>
                    </div>
                    <div className="link-content">
                        <h3>Camisetas Básicas Premium</h3>
                        <p>Camisetas de algodão 100% com ótima qualidade e preço competitivo</p>
                        <div className="link-price">$3.99 - $8.99</div>
                        <div className="link-rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <span>4.8 (2.3k)</span>
                        </div>
                        <button className="access-link">Acessar Link</button>
                    </div>
                </div>

                <div className="link-card" data-category="tenis" data-store="dhgate">
                    <div className="link-image">
                        <img src="https://via.placeholder.com/200x150/3B82F6/FFFFFF?text=Tênis" alt="Produto">
                        <div className="link-store">DHgate</div>
                    </div>
                    <div className="link-content">
                        <h3>Tênis Esportivos Replica</h3>
                        <p>Réplicas de alta qualidade de marcas famosas</p>
                        <div className="link-price">$25.00 - $45.00</div>
                        <div className="link-rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="far fa-star"></i>
                            <span>4.2 (856)</span>
                        </div>
                        <button className="access-link">Acessar Link</button>
                    </div>
                </div>

                <div className="link-card" data-category="perfumes" data-store="aliexpress">
                    <div className="link-image">
                        <img src="https://via.placeholder.com/200x150/10B981/FFFFFF?text=Perfume" alt="Produto">
                        <div className="link-store">AliExpress</div>
                    </div>
                    <div className="link-content">
                        <h3>Perfumes Importados 100ml</h3>
                        <p>Fragrâncias inspiradas em marcas famosas com longa duração</p>
                        <div className="link-price">$12.99 - $29.99</div>
                        <div className="link-rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star-half-alt"></i>
                            <span>4.6 (1.2k)</span>
                        </div>
                        <button className="access-link">Acessar Link</button>
                    </div>
                </div>

                <div className="link-card" data-category="eletronicos" data-store="1688">
                    <div className="link-image">
                        <img src="https://via.placeholder.com/200x150/8B5CF6/FFFFFF?text=Fone" alt="Produto">
                        <div className="link-store">1688</div>
                    </div>
                    <div className="link-content">
                        <h3>Fones Bluetooth TWS</h3>
                        <p>Fones sem fio com cancelamento de ruído e case carregador</p>
                        <div className="link-price">$8.50 - $18.00</div>
                        <div className="link-rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="far fa-star"></i>
                            <span>4.3 (567)</span>
                        </div>
                        <button className="access-link">Acessar Link</button>
                    </div>
                </div>

                <div className="link-card" data-category="roupas" data-store="amazon">
                    <div className="link-image">
                        <img src="https://via.placeholder.com/200x150/EF4444/FFFFFF?text=Jaqueta" alt="Produto">
                        <div className="link-store">Amazon</div>
                    </div>
                    <div className="link-content">
                        <h3>Jaquetas de Couro Sintético</h3>
                        <p>Jaquetas estilosas com acabamento premium e várias cores</p>
                        <div className="link-price">$35.00 - $65.00</div>
                        <div className="link-rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <span>4.9 (345)</span>
                        </div>
                        <button className="access-link">Acessar Link</button>
                    </div>
                </div>

                <div className="link-card" data-category="eletronicos" data-store="aliexpress">
                    <div className="link-image">
                        <img src="https://via.placeholder.com/200x150/F59E0B/FFFFFF?text=Smartwatch" alt="Produto">
                        <div className="link-store">AliExpress</div>
                    </div>
                    <div className="link-content">
                        <h3>Smartwatch Fitness</h3>
                        <p>Relógio inteligente com monitor cardíaco e GPS integrado</p>
                        <div className="link-price">$22.00 - $45.00</div>
                        <div className="link-rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="far fa-star"></i>
                            <span>4.1 (789)</span>
                        </div>
                        <button className="access-link">Acessar Link</button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Ferramentas -->
        <section id="ferramentas-section" className="content-section">
            <div className="section-header">
                <h1><i className="fas fa-tools"></i> Ferramentas & Suporte</h1>
                <p>Recursos essenciais para otimizar suas importações</p>
            </div>

            <div className="tools-grid">
                <div className="tool-card">
                    <div className="tool-icon">
                        <i className="fas fa-calculator"></i>
                    </div>
                    <h3>Calculadora de Frete + Taxa</h3>
                    <p>Calcule o custo total da sua importação incluindo frete e impostos</p>
                    <button className="tool-btn" onclick="openCalculator()">Usar Calculadora</button>
                </div>

                <div className="tool-card">
                    <div className="tool-icon">
                        <i className="fas fa-box"></i>
                    </div>
                    <h3>Simulador de Caixa</h3>
                    <p>Simule o redirecionamento e otimize o espaço da sua encomenda</p>
                    <button className="tool-btn" onclick="openBoxSimulator()">Simular Caixa</button>
                </div>

                <div className="tool-card">
                    <div className="tool-icon">
                        <i className="fas fa-question-circle"></i>
                    </div>
                    <h3>Dúvidas Frequentes</h3>
                    <p>Encontre respostas para as perguntas mais comuns sobre importação</p>
                    <button className="tool-btn" onclick="openFAQ()">Ver FAQ</button>
                </div>

                <div className="tool-card">
                    <div className="tool-icon">
                        <i className="fas fa-headset"></i>
                    </div>
                    <h3>Suporte Direto</h3>
                    <p>Fale diretamente com nossa equipe de suporte especializada</p>
                    <button className="tool-btn" onclick="openSupport()">Contatar Suporte</button>
                </div>

                <div className="tool-card">
                    <div className="tool-icon">
                        <i className="fas fa-file-alt"></i>
                    </div>
                    <h3>Gerador de Declaração</h3>
                    <p>Gere declarações personalizadas para suas encomendas</p>
                    <button className="tool-btn" onclick="openDeclaration()">Gerar Declaração</button>
                </div>

                <div className="tool-card">
                    <div className="tool-icon">
                        <i className="fas fa-chart-line"></i>
                    </div>
                    <h3>Análise de Mercado</h3>
                    <p>Relatórios e insights sobre tendências de importação</p>
                    <button className="tool-btn" onclick="openMarketAnalysis()">Ver Análises</button>
                </div>
            </div>

            <!-- FAQ Section -->
            <div className="faq-section">
                <h3>Perguntas Frequentes</h3>
                <div className="faq-list">
                    <div className="faq-item">
                        <div className="faq-question">
                            <span>Como calcular o valor da taxa de importação?</span>
                            <i className="fas fa-chevron-down"></i>
                        </div>
                        <div className="faq-answer">
                            <p>A taxa de importação é calculada sobre o valor da mercadoria + frete. Para produtos até $50, não há cobrança de imposto. Acima disso, é cobrado 60% sobre o valor excedente.</p>
                        </div>
                    </div>

                    <div className="faq-item">
                        <div className="faq-question">
                            <span>Qual o limite de peso para encomendas?</span>
                            <i className="fas fa-chevron-down"></i>
                        </div>
                        <div className="faq-answer">
                            <p>O limite de peso varia conforme o método de envio. Para correios, o limite é 30kg. Para courier (DHL, FedEx), pode chegar até 70kg.</p>
                        </div>
                    </div>

                    <div className="faq-item">
                        <div className="faq-question">
                            <span>Como rastrear minha encomenda?</span>
                            <i className="fas fa-chevron-down"></i>
                        </div>
                        <div className="faq-answer">
                            <p>Use o código de rastreamento fornecido pelo vendedor nos sites dos Correios ou da transportadora responsável. Também recomendamos o app "17track" para rastreamento internacional.</p>
                        </div>
                    </div>

                    <div className="faq-item">
                        <div className="faq-question">
                            <span>O que fazer se a encomenda for taxada?</span>
                            <i className="fas fa-chevron-down"></i>
                        </div>
                        <div className="faq-answer">
                            <p>Se sua encomenda for taxada, você receberá uma notificação dos Correios. Pague a taxa online ou presencialmente para liberar a mercadoria.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Suporte -->
        <section id="suporte-section" className="content-section">
            <div className="section-header">
                <h1><i className="fas fa-headset"></i> Suporte e Ajuda</h1>
                <p>Precisa de ajuda? Abra um ticket e nossa equipe te ajudará!</p>
            </div>

            <!-- Novo Ticket -->
            <div className="support-card">
                <h3><i className="fas fa-plus-circle"></i> Abrir Novo Ticket</h3>
                <form id="supportForm" className="support-form">
                    <div className="form-group">
                        <label htmlFor="ticketSubject">Assunto</label>
                        <input type="text" id="ticketSubject" placeholder="Descreva brevemente sua dúvida..." required>
                    </div>
                    <div className="form-group">
                        <label htmlFor="ticketCategory">Categoria</label>
                        <select id="ticketCategory" required>
                            <option value="">Selecione uma categoria</option>
                            <option value="importacao">Dúvidas sobre Importação</option>
                            <option value="curso">Problemas com o Curso</option>
                            <option value="pagamento">Questões de Pagamento</option>
                            <option value="tecnico">Problemas Técnicos</option>
                            <option value="outros">Outros</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label htmlFor="ticketDescription">Descrição Detalhada</label>
                        <textarea id="ticketDescription" rows="5" placeholder="Descreva sua dúvida ou problema em detalhes..." required></textarea>
                    </div>
                    <button type="submit" className="submit-ticket-btn">
                        <i className="fas fa-paper-plane"></i>
                        Enviar Ticket
                    </button>
                </form>
            </div>

            <!-- Meus Tickets -->
            <div className="support-card">
                <h3><i className="fas fa-ticket-alt"></i> Meus Tickets</h3>
                <div id="ticketsList" className="tickets-list">
                    <!-- Tickets serão carregados aqui -->
                </div>
            </div>
        </section>
    </main>

    <!-- Mobile Sidebar Overlay -->
    <div id="sidebarOverlay" className="sidebar-overlay"></div>

    <!-- Modals -->
    <div id="calculatorModal" className="modal">
        <div className="modal-content">
            <div className="modal-header">
                <h3>Calculadora de Frete + Taxa</h3>
                <button className="modal-close">&times;</button>
            </div>
            <div className="modal-body">
                <div className="calc-form">
                    <div className="form-group">
                        <label>Valor do Produto (USD)</label>
                        <input type="number" id="productValue" placeholder="0.00">
                    </div>
                    <div className="form-group">
                        <label>Valor do Frete (USD)</label>
                        <input type="number" id="shippingValue" placeholder="0.00">
                    </div>
                    <div className="form-group">
                        <label>Peso (kg)</label>
                        <input type="number" id="weight" placeholder="0.0">
                    </div>
                    <button className="calc-btn" onclick="calculateTotal()">Calcular</button>
                    <div id="calcResult" className="calc-result"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="aluno-script.js"></script>
</>
  )
}
