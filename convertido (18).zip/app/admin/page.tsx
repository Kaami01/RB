"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import {
  BarChart3,
  Menu,
  X,
  EyeOff,
  Plus,
  Bell,
  LogOut,
  Shield,
  MessageSquare,
  Settings,
  Globe,
  Lightbulb,
  ShoppingCart,
  Wrench,
  Headphones,
  RefreshCw,
  Zap,
  PieChart,
  Users,
  Database,
  AlertTriangle,
  Edit,
  Trash2,
  Star,
  ExternalLink,
} from "lucide-react"
import * as api from "@/lib/api"
import { StudentsSection } from "@/components/students-section"

// Tipos para os dados
interface Tip {
  id: number
  category: string
  title: string
  description: string
  content?: string
  published: boolean
  created_at: string
  updated_at: string
}

interface Product {
  id: number
  category: string
  store: string
  title: string
  description: string
  price: string
  rating: number
  reviews: string
  image?: string
  link: string
  created_at: string
  updated_at: string
}

interface Community {
  id: number
  icon: string
  title: string
  description: string
  members: string
  online: string
  is_vip: boolean
  created_at: string
  updated_at: string
}

interface Tool {
  id: number
  icon: string
  title: string
  description: string
  link: string
  enabled: boolean
  created_at: string
  updated_at: string
}

interface TicketType {
  id: number
  subject: string
  category: string
  description: string
  status: string
  created_at: string
  user_name: string
  user_id: string
  response?: string
}

export default function AdminDashboard() {
  const [currentSection, setCurrentSection] = useState("dashboard")
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [databaseStatus, setDatabaseStatus] = useState<any>(null)

  // Dados para gerenciamento de conteúdo
  const [tips, setTips] = useState<Tip[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [communities, setCommunities] = useState<Community[]>([])
  const [tools, setTools] = useState<Tool[]>([])
  const [tickets, setTickets] = useState<TicketType[]>([])
  const [students, setStudents] = useState<any[]>([])

  // Estatísticas
  const [stats, setStats] = useState({
    totalTips: 0,
    publishedTips: 0,
    totalProducts: 0,
    totalCommunities: 0,
    totalTools: 0,
    enabledTools: 0,
    openTickets: 0,
    totalTickets: 0,
    totalStudents: 0,
    activeStudents: 0,
  })

  useEffect(() => {
    // Check authentication
    const savedUser = localStorage.getItem("r2b_user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      if (userData.role !== "admin") {
        window.location.href = "/"
        return
      }
    } else {
      window.location.href = "/"
      return
    }

    checkDatabaseStatus()
    loadAllData()
  }, [])

  const checkDatabaseStatus = async () => {
    try {
      const response = await fetch("/api/database/connection")
      const data = await response.json()
      setDatabaseStatus(data)
    } catch (error) {
      console.error("Error checking database status:", error)
      setDatabaseStatus({ success: false, tablesExist: false })
    }
  }

  const loadAllData = async () => {
    setIsLoading(true)
    try {
      await Promise.all([loadTips(), loadProducts(), loadCommunities(), loadTools(), loadTickets(), loadStudents()])
    } catch (error) {
      console.error("Error loading data:", error)
      toast({
        title: "Erro ao carregar dados",
        description: "Alguns dados podem não estar atualizados. Verifique se o banco de dados está configurado.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const refreshData = async () => {
    setRefreshing(true)
    await checkDatabaseStatus()
    await loadAllData()
    setRefreshing(false)
    toast({
      title: "Dados atualizados!",
      description: "Todas as informações foram recarregadas com sucesso.",
    })
  }

  const loadTips = async () => {
    try {
      const data = await api.fetchTips()
      setTips(data)
    } catch (error) {
      console.error("Error loading tips:", error)
      setTips([])
    }
  }

  const loadProducts = async () => {
    try {
      const data = await api.fetchProducts()
      setProducts(data)
    } catch (error) {
      console.error("Error loading products:", error)
      setProducts([])
    }
  }

  const loadCommunities = async () => {
    try {
      const data = await api.fetchCommunities()
      setCommunities(data)
    } catch (error) {
      console.error("Error loading communities:", error)
      setCommunities([])
    }
  }

  const loadTools = async () => {
    try {
      const data = await api.fetchTools()
      setTools(data)
    } catch (error) {
      console.error("Error loading tools:", error)
      setTools([])
    }
  }

  const loadTickets = async () => {
    try {
      const data = await api.fetchTickets()
      setTickets(data)
    } catch (error) {
      console.error("Error loading tickets:", error)
      setTickets([])
    }
  }

  const loadStudents = async () => {
    try {
      const response = await fetch("/api/students")
      if (!response.ok) throw new Error("Failed to fetch students")
      const data = await response.json()
      setStudents(data)
    } catch (error) {
      console.error("Error loading students:", error)
      setStudents([])
    }
  }

  // Calcular estatísticas
  useEffect(() => {
    setStats({
      totalTips: tips.length,
      publishedTips: tips.filter((tip) => tip.published).length,
      totalProducts: products.length,
      totalCommunities: communities.length,
      totalTools: tools.length,
      enabledTools: tools.filter((tool) => tool.enabled).length,
      openTickets: tickets.filter((ticket) => ticket.status === "open").length,
      totalTickets: tickets.length,
      totalStudents: students.length,
      activeStudents: students.filter((student) => student.status === "active").length,
    })
  }, [tips, products, communities, tools, tickets, students])

  const handleLogout = () => {
    localStorage.removeItem("r2b_user")
    window.location.href = "/"
  }

  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: BarChart3, color: "blue" },
    { id: "estudantes", label: "Estudantes", icon: Users, color: "indigo" },
    { id: "dicas", label: "Dicas", icon: Lightbulb, color: "yellow" },
    { id: "produtos", label: "Links de Produtos", icon: ShoppingCart, color: "green" },
    { id: "comunidades", label: "Comunidades", icon: MessageSquare, color: "purple" },
    { id: "ferramentas", label: "Ferramentas", icon: Wrench, color: "orange" },
    { id: "suporte", label: "Suporte", icon: Headphones, color: "red" },
    { id: "analytics", label: "Analytics", icon: PieChart, color: "indigo" },
    { id: "configuracoes", label: "Configurações", icon: Settings, color: "gray" },
  ]

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-6"></div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Carregando Dashboard</h2>
          <p className="text-gray-600">Conectando com o banco de dados...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex">
      {/* Sidebar */}
      <div
        className={`${isSidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white shadow-2xl transition-transform duration-300 ease-in-out`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-gradient-to-r from-blue-600 to-indigo-600">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg">
                <Globe className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <span className="font-bold text-xl text-white">R2B Admin</span>
                <p className="text-blue-100 text-sm">Painel de Controle</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setIsSidebarOpen(false)} className="lg:hidden text-white">
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Database Status Alert */}
          {databaseStatus && !databaseStatus.success && (
            <div className="p-4 bg-yellow-50 border-b border-yellow-200">
              <Alert className="border-yellow-300 bg-yellow-50">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-800 text-sm">
                  Banco não configurado.{" "}
                  <Button
                    variant="link"
                    size="sm"
                    className="p-0 h-auto text-yellow-800 underline"
                    onClick={() => window.open("/setup-database", "_blank")}
                  >
                    Configure aqui
                  </Button>
                </AlertDescription>
              </Alert>
            </div>
          )}

          {/* Quick Stats */}
          <div className="p-6 border-b border-gray-100 bg-gray-50">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.totalStudents}</div>
                <div className="text-xs text-gray-600">Estudantes</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.publishedTips}</div>
                <div className="text-xs text-gray-600">Dicas Ativas</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{stats.totalProducts}</div>
                <div className="text-xs text-gray-600">Produtos</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{stats.openTickets}</div>
                <div className="text-xs text-gray-600">Tickets</div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-6 overflow-y-auto">
            <div className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentSection(item.id)
                      setIsSidebarOpen(false)
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 font-medium group ${
                      currentSection === item.id
                        ? "bg-blue-50 text-blue-700 border-2 border-blue-200 shadow-md"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 hover:shadow-sm"
                    }`}
                  >
                    <div
                      className={`p-2 rounded-lg ${
                        currentSection === item.id
                          ? "bg-blue-100"
                          : "bg-gray-100 group-hover:bg-gray-200 transition-colors"
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="flex-1">{item.label}</span>
                    {item.id === "suporte" && stats.openTickets > 0 && (
                      <Badge className="bg-red-100 text-red-700 text-xs">{stats.openTickets}</Badge>
                    )}
                    {item.id === "estudantes" && stats.totalStudents > 0 && (
                      <Badge className="bg-indigo-100 text-indigo-700 text-xs">{stats.totalStudents}</Badge>
                    )}
                  </button>
                )
              })}
            </div>
          </nav>

          {/* User Info */}
          <div className="p-6 border-t border-gray-100 bg-gray-50">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 truncate">Administrador</p>
                <p className="text-xs text-gray-500 truncate">admin@r2b.com.br</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={refreshData}
                disabled={refreshing}
                className="flex-1 border-gray-300 bg-transparent"
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
                {refreshing ? "..." : "Atualizar"}
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout} className="border-gray-300 bg-transparent">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-100">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => setIsSidebarOpen(true)} className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  {navItems.find((item) => item.id === currentSection)?.label}
                </h1>
                <p className="text-gray-600">Gerencie todo o conteúdo da plataforma R2B Academy</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                {stats.openTickets > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {stats.openTickets}
                  </span>
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open("/aluno", "_blank")}
                className="border-gray-300"
              >
                <EyeOff className="h-4 w-4" />
                <span className="hidden sm:inline ml-2">Ver Portal</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open("/setup-database", "_blank")}
                className="border-gray-300"
              >
                <Database className="h-4 w-4" />
                <span className="hidden sm:inline ml-2">Setup DB</span>
              </Button>
            </div>
          </div>
        </header>

        {/* Database Status Alert */}
        {databaseStatus && !databaseStatus.success && (
          <div className="p-4 bg-yellow-50 border-b border-yellow-200">
            <Alert className="border-yellow-300 bg-yellow-50">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <strong>Banco de dados não configurado:</strong> As tabelas do banco não foram criadas ainda. Para usar
                todas as funcionalidades do admin, você precisa configurar o banco de dados primeiro.{" "}
                <Button
                  variant="link"
                  size="sm"
                  className="p-0 h-auto text-yellow-800 underline font-semibold"
                  onClick={() => window.open("/setup-database", "_blank")}
                >
                  Clique aqui para configurar
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        )}

        {/* Dashboard Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {currentSection === "dashboard" && <DashboardSection stats={stats} databaseStatus={databaseStatus} />}
          {currentSection === "estudantes" && (
            <StudentsSection students={students} setStudents={setStudents} onRefresh={loadStudents} />
          )}
          {currentSection === "dicas" && <TipsSection tips={tips} setTips={setTips} onRefresh={loadTips} />}
          {currentSection === "produtos" && (
            <ProductsSection products={products} setProducts={setProducts} onRefresh={loadProducts} />
          )}
          {currentSection === "comunidades" && (
            <CommunitiesSection communities={communities} setCommunities={setCommunities} onRefresh={loadCommunities} />
          )}
          {currentSection === "ferramentas" && <ToolsSection tools={tools} setTools={setTools} onRefresh={loadTools} />}
          {currentSection === "suporte" && (
            <SupportSection tickets={tickets} setTickets={setTickets} onRefresh={loadTickets} />
          )}
          {currentSection === "analytics" && <AnalyticsSection stats={stats} />}
          {currentSection === "configuracoes" && <ConfiguracoesSection />}
        </main>
      </div>

      {/* Overlay */}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setIsSidebarOpen(false)} />
      )}

      <Toaster />
    </div>
  )
}

// Dashboard Section
function DashboardSection({ stats, databaseStatus }: { stats: any; databaseStatus: any }) {
  return (
    <div className="space-y-8">
      {/* Welcome Card */}
      <Card className="border-0 shadow-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <CardContent className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold mb-2">Bem-vindo ao Painel Admin! 👋</h2>
              <p className="text-blue-100 text-lg">
                Gerencie todo o conteúdo da R2B Academy de forma simples e intuitiva
              </p>
              {databaseStatus && !databaseStatus.success && (
                <div className="mt-4">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => window.open("/setup-database", "_blank")}
                    className="bg-white text-blue-600 hover:bg-blue-50"
                  >
                    <Database className="h-4 w-4 mr-2" />
                    Configurar Banco de Dados
                  </Button>
                </div>
              )}
            </div>
            <div className="hidden md:block">
              <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <BarChart3 className="h-12 w-12 text-white" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total de Estudantes"
          value={stats.totalStudents}
          subtitle={`${stats.activeStudents} ativos`}
          icon={Users}
          color="indigo"
          trend="+15%"
        />
        <StatsCard
          title="Total de Dicas"
          value={stats.totalTips}
          subtitle={`${stats.publishedTips} publicadas`}
          icon={Lightbulb}
          color="yellow"
          trend="+12%"
        />
        <StatsCard
          title="Links de Produtos"
          value={stats.totalProducts}
          subtitle="Produtos curados"
          icon={ShoppingCart}
          color="green"
          trend="+8%"
        />
        <StatsCard
          title="Tickets Abertos"
          value={stats.openTickets}
          subtitle={`${stats.totalTickets} total`}
          icon={Headphones}
          color="red"
          trend="-3%"
        />
      </div>

      {/* Quick Actions */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-gray-900 flex items-center gap-3">
            <Zap className="h-6 w-6 text-yellow-500" />
            Ações Rápidas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <QuickActionCard
              title="Configurar Banco"
              description="Setup do banco de dados"
              icon={Database}
              color="blue"
              onClick={() => window.open("/setup-database", "_blank")}
            />
            <QuickActionCard
              title="Nova Dica"
              description="Adicionar dica de importação"
              icon={Plus}
              color="green"
              onClick={() => {}}
            />
            <QuickActionCard
              title="Novo Produto"
              description="Adicionar link de produto"
              icon={ShoppingCart}
              color="purple"
              onClick={() => {}}
            />
            <QuickActionCard
              title="Ver Tickets"
              description="Gerenciar suporte"
              icon={Headphones}
              color="red"
              onClick={() => {}}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Stats Card Component
function StatsCard({
  title,
  value,
  subtitle,
  icon: Icon,
  color,
  trend,
}: {
  title: string
  value: number
  subtitle: string
  icon: any
  color: string
  trend: string
}) {
  const colorClasses = {
    yellow: "bg-yellow-50 text-yellow-600",
    green: "bg-green-50 text-green-600",
    purple: "bg-purple-50 text-purple-600",
    red: "bg-red-50 text-red-600",
    blue: "bg-blue-50 text-blue-600",
    indigo: "bg-indigo-50 text-indigo-600",
  }

  return (
    <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-3xl font-bold text-gray-900">{value}</p>
            <p className="text-sm text-gray-500">{subtitle}</p>
          </div>
          <div
            className={`w-14 h-14 rounded-xl flex items-center justify-center ${colorClasses[color as keyof typeof colorClasses]}`}
          >
            <Icon className="h-7 w-7" />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <span className={`font-medium ${trend.startsWith("+") ? "text-green-600" : "text-red-600"}`}>{trend}</span>
          <span className="text-gray-500 ml-1">este mês</span>
        </div>
      </CardContent>
    </Card>
  )
}

// Quick Action Card Component
function QuickActionCard({
  title,
  description,
  icon: Icon,
  color,
  onClick,
}: {
  title: string
  description: string
  icon: any
  color: string
  onClick: () => void
}) {
  const colorClasses = {
    blue: "bg-blue-50 text-blue-600 hover:bg-blue-100",
    green: "bg-green-50 text-green-600 hover:bg-green-100",
    purple: "bg-purple-50 text-purple-600 hover:bg-purple-100",
    red: "bg-red-50 text-red-600 hover:bg-red-100",
    indigo: "bg-indigo-50 text-indigo-600 hover:bg-indigo-100",
  }

  return (
    <button
      onClick={onClick}
      className={`p-4 rounded-xl text-left transition-all duration-200 hover:shadow-md ${colorClasses[color as keyof typeof colorClasses]}`}
    >
      <Icon className="h-8 w-8 mb-3" />
      <h3 className="font-semibold text-gray-900">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </button>
  )
}

// Tips Section
function TipsSection({ tips, setTips, onRefresh }: any) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingTip, setEditingTip] = useState<Tip | null>(null)
  const [formData, setFormData] = useState({
    category: "",
    title: "",
    description: "",
    content: "",
    published: false,
  })

  const handleCreateTip = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await api.createTip(formData)
      toast({
        title: "Dica criada com sucesso!",
        description: "A nova dica foi adicionada ao sistema.",
      })
      setIsCreateDialogOpen(false)
      setFormData({ category: "", title: "", description: "", content: "", published: false })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao criar dica",
        description: "Não foi possível criar a dica. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateTip = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingTip) return

    try {
      await api.updateTip(editingTip.id, formData)
      toast({
        title: "Dica atualizada com sucesso!",
        description: "As alterações foram salvas.",
      })
      setEditingTip(null)
      setFormData({ category: "", title: "", description: "", content: "", published: false })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao atualizar dica",
        description: "Não foi possível atualizar a dica. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteTip = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta dica?")) return

    try {
      await api.deleteTip(id)
      toast({
        title: "Dica excluída com sucesso!",
        description: "A dica foi removida do sistema.",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao excluir dica",
        description: "Não foi possível excluir a dica. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const startEdit = (tip: Tip) => {
    setEditingTip(tip)
    setFormData({
      category: tip.category,
      title: tip.title,
      description: tip.description,
      content: tip.content || "",
      published: tip.published,
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Dicas</h2>
          <p className="text-gray-600">
            Total: {tips.length} dicas ({tips.filter((t: Tip) => t.published).length} publicadas)
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Nova Dica
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Criar Nova Dica</DialogTitle>
              <DialogDescription>Adicione uma nova dica de importação para os alunos.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateTip}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Categoria</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="roupas">Roupas</SelectItem>
                        <SelectItem value="tenis">Tênis</SelectItem>
                        <SelectItem value="perfumes">Perfumes</SelectItem>
                        <SelectItem value="eletronicos">Eletrônicos</SelectItem>
                        <SelectItem value="acessorios">Acessórios</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="published"
                      checked={formData.published}
                      onCheckedChange={(checked) => setFormData({ ...formData, published: checked })}
                    />
                    <Label htmlFor="published">Publicar</Label>
                  </div>
                </div>
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Título da dica"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrição breve da dica"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="content">Conteúdo</Label>
                  <Textarea
                    id="content"
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder="Conteúdo completo da dica"
                    className="min-h-[120px]"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  Criar Dica
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tips List */}
      <div className="grid gap-4">
        {tips.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Lightbulb className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma dica encontrada</h3>
              <p className="text-gray-600">Comece criando sua primeira dica de importação.</p>
            </CardContent>
          </Card>
        ) : (
          tips.map((tip: Tip) => (
            <Card key={tip.id} className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <Badge className="capitalize">{tip.category}</Badge>
                    <Badge variant={tip.published ? "default" : "secondary"}>
                      {tip.published ? "Publicada" : "Rascunho"}
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => startEdit(tip)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleDeleteTip(tip.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{tip.title}</h3>
                <p className="text-gray-600 mb-4">{tip.description}</p>
                <div className="text-sm text-gray-500">
                  Criada em: {new Date(tip.created_at).toLocaleDateString("pt-BR")}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingTip} onOpenChange={() => setEditingTip(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Dica</DialogTitle>
            <DialogDescription>Faça as alterações necessárias na dica.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdateTip}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-category">Categoria</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="roupas">Roupas</SelectItem>
                      <SelectItem value="tenis">Tênis</SelectItem>
                      <SelectItem value="perfumes">Perfumes</SelectItem>
                      <SelectItem value="eletronicos">Eletrônicos</SelectItem>
                      <SelectItem value="acessorios">Acessórios</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-published"
                    checked={formData.published}
                    onCheckedChange={(checked) => setFormData({ ...formData, published: checked })}
                  />
                  <Label htmlFor="edit-published">Publicar</Label>
                </div>
              </div>
              <div>
                <Label htmlFor="edit-title">Título</Label>
                <Input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Título da dica"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Descrição</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descrição breve da dica"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-content">Conteúdo</Label>
                <Textarea
                  id="edit-content"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Conteúdo completo da dica"
                  className="min-h-[120px]"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingTip(null)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Products Section
function ProductsSection({ products, setProducts, onRefresh }: any) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [formData, setFormData] = useState({
    category: "",
    store: "",
    title: "",
    description: "",
    price: "",
    rating: 5,
    reviews: "",
    image: "",
    link: "",
  })

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await api.createProduct(formData)
      toast({
        title: "Produto criado com sucesso!",
        description: "O novo produto foi adicionado ao sistema.",
      })
      setIsCreateDialogOpen(false)
      setFormData({
        category: "",
        store: "",
        title: "",
        description: "",
        price: "",
        rating: 5,
        reviews: "",
        image: "",
        link: "",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao criar produto",
        description: "Não foi possível criar o produto. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateProduct = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingProduct) return

    try {
      await api.updateProduct(editingProduct.id, formData)
      toast({
        title: "Produto atualizado com sucesso!",
        description: "As alterações foram salvas.",
      })
      setEditingProduct(null)
      setFormData({
        category: "",
        store: "",
        title: "",
        description: "",
        price: "",
        rating: 5,
        reviews: "",
        image: "",
        link: "",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao atualizar produto",
        description: "Não foi possível atualizar o produto. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteProduct = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este produto?")) return

    try {
      await api.deleteProduct(id)
      toast({
        title: "Produto excluído com sucesso!",
        description: "O produto foi removido do sistema.",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao excluir produto",
        description: "Não foi possível excluir o produto. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const startEdit = (product: Product) => {
    setEditingProduct(product)
    setFormData({
      category: product.category,
      store: product.store,
      title: product.title,
      description: product.description,
      price: product.price,
      rating: product.rating,
      reviews: product.reviews,
      image: product.image || "",
      link: product.link,
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Produtos</h2>
          <p className="text-gray-600">Total: {products.length} produtos</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              Novo Produto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Criar Novo Produto</DialogTitle>
              <DialogDescription>Adicione um novo link de produto para os alunos.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateProduct}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Categoria</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="roupas">Roupas</SelectItem>
                        <SelectItem value="tenis">Tênis</SelectItem>
                        <SelectItem value="perfumes">Perfumes</SelectItem>
                        <SelectItem value="eletronicos">Eletrônicos</SelectItem>
                        <SelectItem value="acessorios">Acessórios</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="store">Loja</Label>
                    <Select
                      value={formData.store}
                      onValueChange={(value) => setFormData({ ...formData, store: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma loja" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="aliexpress">AliExpress</SelectItem>
                        <SelectItem value="amazon">Amazon</SelectItem>
                        <SelectItem value="shein">Shein</SelectItem>
                        <SelectItem value="temu">Temu</SelectItem>
                        <SelectItem value="outros">Outros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Nome do produto"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrição do produto"
                    required
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="price">Preço</Label>
                    <Input
                      id="price"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="R$ 99,90"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="rating">Avaliação</Label>
                    <Select
                      value={formData.rating.toString()}
                      onValueChange={(value) => setFormData({ ...formData, rating: Number.parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 estrela</SelectItem>
                        <SelectItem value="2">2 estrelas</SelectItem>
                        <SelectItem value="3">3 estrelas</SelectItem>
                        <SelectItem value="4">4 estrelas</SelectItem>
                        <SelectItem value="5">5 estrelas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="reviews">Reviews</Label>
                    <Input
                      id="reviews"
                      value={formData.reviews}
                      onChange={(e) => setFormData({ ...formData, reviews: e.target.value })}
                      placeholder="1.2k reviews"
                      required
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="image">URL da Imagem</Label>
                  <Input
                    id="image"
                    value={formData.image}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    placeholder="https://exemplo.com/imagem.jpg"
                  />
                </div>
                <div>
                  <Label htmlFor="link">Link do Produto</Label>
                  <Input
                    id="link"
                    value={formData.link}
                    onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                    placeholder="https://exemplo.com/produto"
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-green-600 hover:bg-green-700">
                  Criar Produto
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Products List */}
      <div className="grid gap-4">
        {products.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <ShoppingCart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-600">Comece adicionando seu primeiro produto.</p>
            </CardContent>
          </Card>
        ) : (
          products.map((product: Product) => (
            <Card key={product.id} className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <div className="w-20 h-20 bg-gray-100 rounded-lg flex-shrink-0 overflow-hidden">
                    {product.image ? (
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingCart className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className="capitalize">{product.category}</Badge>
                        <Badge variant="outline" className="capitalize">
                          {product.store}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => window.open(product.link, "_blank")}>
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => startEdit(product)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteProduct(product.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">{product.title}</h3>
                    <p className="text-gray-600 text-sm mb-2">{product.description}</p>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="font-semibold text-green-600">{product.price}</span>
                      <div className="flex items-center gap-1">
                        <div className="flex text-yellow-400">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`h-4 w-4 ${i < product.rating ? "fill-current" : ""}`} />
                          ))}
                        </div>
                        <span className="text-gray-500">({product.reviews})</span>
                      </div>
                      <span className="text-gray-500">
                        Criado em: {new Date(product.created_at).toLocaleDateString("pt-BR")}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingProduct} onOpenChange={() => setEditingProduct(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Produto</DialogTitle>
            <DialogDescription>Faça as alterações necessárias no produto.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdateProduct}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-category">Categoria</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="roupas">Roupas</SelectItem>
                      <SelectItem value="tenis">Tênis</SelectItem>
                      <SelectItem value="perfumes">Perfumes</SelectItem>
                      <SelectItem value="eletronicos">Eletrônicos</SelectItem>
                      <SelectItem value="acessorios">Acessórios</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-store">Loja</Label>
                  <Select value={formData.store} onValueChange={(value) => setFormData({ ...formData, store: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma loja" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="aliexpress">AliExpress</SelectItem>
                      <SelectItem value="amazon">Amazon</SelectItem>
                      <SelectItem value="shein">Shein</SelectItem>
                      <SelectItem value="temu">Temu</SelectItem>
                      <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="edit-title">Título</Label>
                <Input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Nome do produto"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Descrição</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descrição do produto"
                  required
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="edit-price">Preço</Label>
                  <Input
                    id="edit-price"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    placeholder="R$ 99,90"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-rating">Avaliação</Label>
                  <Select
                    value={formData.rating.toString()}
                    onValueChange={(value) => setFormData({ ...formData, rating: Number.parseInt(value) })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 estrela</SelectItem>
                      <SelectItem value="2">2 estrelas</SelectItem>
                      <SelectItem value="3">3 estrelas</SelectItem>
                      <SelectItem value="4">4 estrelas</SelectItem>
                      <SelectItem value="5">5 estrelas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-reviews">Reviews</Label>
                  <Input
                    id="edit-reviews"
                    value={formData.reviews}
                    onChange={(e) => setFormData({ ...formData, reviews: e.target.value })}
                    placeholder="1.2k reviews"
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-image">URL da Imagem</Label>
                <Input
                  id="edit-image"
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://exemplo.com/imagem.jpg"
                />
              </div>
              <div>
                <Label htmlFor="edit-link">Link do Produto</Label>
                <Input
                  id="edit-link"
                  value={formData.link}
                  onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                  placeholder="https://exemplo.com/produto"
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingProduct(null)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-green-600 hover:bg-green-700">
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Communities Section
function CommunitiesSection({ communities, setCommunities, onRefresh }: any) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingCommunity, setEditingCommunity] = useState<Community | null>(null)
  const [formData, setFormData] = useState({
    icon: "",
    title: "",
    description: "",
    members: "",
    online: "",
    is_vip: false,
  })

  const handleCreateCommunity = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await api.createCommunity(formData)
      toast({
        title: "Comunidade criada com sucesso!",
        description: "A nova comunidade foi adicionada ao sistema.",
      })
      setIsCreateDialogOpen(false)
      setFormData({
        icon: "",
        title: "",
        description: "",
        members: "",
        online: "",
        is_vip: false,
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao criar comunidade",
        description: "Não foi possível criar a comunidade. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateCommunity = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingCommunity) return

    try {
      await api.updateCommunity(editingCommunity.id, formData)
      toast({
        title: "Comunidade atualizada com sucesso!",
        description: "As alterações foram salvas.",
      })
      setEditingCommunity(null)
      setFormData({
        icon: "",
        title: "",
        description: "",
        members: "",
        online: "",
        is_vip: false,
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao atualizar comunidade",
        description: "Não foi possível atualizar a comunidade. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteCommunity = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta comunidade?")) return

    try {
      await api.deleteCommunity(id)
      toast({
        title: "Comunidade excluída com sucesso!",
        description: "A comunidade foi removida do sistema.",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao excluir comunidade",
        description: "Não foi possível excluir a comunidade. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const startEdit = (community: Community) => {
    setEditingCommunity(community)
    setFormData({
      icon: community.icon,
      title: community.title,
      description: community.description,
      members: community.members,
      online: community.online,
      is_vip: community.is_vip,
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Comunidades</h2>
          <p className="text-gray-600">Total: {communities.length} comunidades</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus className="h-4 w-4 mr-2" />
              Nova Comunidade
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Criar Nova Comunidade</DialogTitle>
              <DialogDescription>Adicione uma nova comunidade para os alunos.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateCommunity}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="icon">Emoji/Ícone</Label>
                    <Input
                      id="icon"
                      value={formData.icon}
                      onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                      placeholder="🚀"
                      required
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="is_vip"
                      checked={formData.is_vip}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_vip: checked })}
                    />
                    <Label htmlFor="is_vip">Comunidade VIP</Label>
                  </div>
                </div>
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Nome da comunidade"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrição da comunidade"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="members">Membros</Label>
                    <Input
                      id="members"
                      value={formData.members}
                      onChange={(e) => setFormData({ ...formData, members: e.target.value })}
                      placeholder="1.2k"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="online">Online</Label>
                    <Input
                      id="online"
                      value={formData.online}
                      onChange={(e) => setFormData({ ...formData, online: e.target.value })}
                      placeholder="234"
                      required
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                  Criar Comunidade
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Communities List */}
      <div className="grid gap-4">
        {communities.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma comunidade encontrada</h3>
              <p className="text-gray-600">Comece criando sua primeira comunidade.</p>
            </CardContent>
          </Card>
        ) : (
          communities.map((community: Community) => (
            <Card key={community.id} className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="text-4xl">{community.icon}</div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-semibold text-gray-900">{community.title}</h3>
                        {community.is_vip && <Badge className="bg-purple-100 text-purple-700">VIP</Badge>}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => startEdit(community)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteCommunity(community.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-gray-600 mb-3">{community.description}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>{community.members} membros</span>
                      <span>{community.online} online</span>
                      <span>Criada em: {new Date(community.created_at).toLocaleDateString("pt-BR")}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingCommunity} onOpenChange={() => setEditingCommunity(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Comunidade</DialogTitle>
            <DialogDescription>Faça as alterações necessárias na comunidade.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdateCommunity}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-icon">Emoji/Ícone</Label>
                  <Input
                    id="edit-icon"
                    value={formData.icon}
                    onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                    placeholder="🚀"
                    required
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-is_vip"
                    checked={formData.is_vip}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_vip: checked })}
                  />
                  <Label htmlFor="edit-is_vip">Comunidade VIP</Label>
                </div>
              </div>
              <div>
                <Label htmlFor="edit-title">Título</Label>
                <Input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Nome da comunidade"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Descrição</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descrição da comunidade"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-members">Membros</Label>
                  <Input
                    id="edit-members"
                    value={formData.members}
                    onChange={(e) => setFormData({ ...formData, members: e.target.value })}
                    placeholder="1.2k"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-online">Online</Label>
                  <Input
                    id="edit-online"
                    value={formData.online}
                    onChange={(e) => setFormData({ ...formData, online: e.target.value })}
                    placeholder="234"
                    required
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingCommunity(null)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Tools Section
function ToolsSection({ tools, setTools, onRefresh }: any) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingTool, setEditingTool] = useState<Tool | null>(null)
  const [formData, setFormData] = useState({
    icon: "",
    title: "",
    description: "",
    link: "",
    enabled: true,
  })

  const handleCreateTool = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await api.createTool(formData)
      toast({
        title: "Ferramenta criada com sucesso!",
        description: "A nova ferramenta foi adicionada ao sistema.",
      })
      setIsCreateDialogOpen(false)
      setFormData({
        icon: "",
        title: "",
        description: "",
        link: "",
        enabled: true,
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao criar ferramenta",
        description: "Não foi possível criar a ferramenta. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateTool = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingTool) return

    try {
      await api.updateTool(editingTool.id, formData)
      toast({
        title: "Ferramenta atualizada com sucesso!",
        description: "As alterações foram salvas.",
      })
      setEditingTool(null)
      setFormData({
        icon: "",
        title: "",
        description: "",
        link: "",
        enabled: true,
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao atualizar ferramenta",
        description: "Não foi possível atualizar a ferramenta. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteTool = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta ferramenta?")) return

    try {
      await api.deleteTool(id)
      toast({
        title: "Ferramenta excluída com sucesso!",
        description: "A ferramenta foi removida do sistema.",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao excluir ferramenta",
        description: "Não foi possível excluir a ferramenta. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const startEdit = (tool: Tool) => {
    setEditingTool(tool)
    setFormData({
      icon: tool.icon,
      title: tool.title,
      description: tool.description,
      link: tool.link,
      enabled: tool.enabled,
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Ferramentas</h2>
          <p className="text-gray-600">
            Total: {tools.length} ferramentas ({tools.filter((t: Tool) => t.enabled).length} ativas)
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-orange-600 hover:bg-orange-700">
              <Plus className="h-4 w-4 mr-2" />
              Nova Ferramenta
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Criar Nova Ferramenta</DialogTitle>
              <DialogDescription>Adicione uma nova ferramenta para os alunos.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateTool}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="icon">Ícone</Label>
                    <Select value={formData.icon} onValueChange={(value) => setFormData({ ...formData, icon: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um ícone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Calculator">Calculadora</SelectItem>
                        <SelectItem value="Box">Caixa</SelectItem>
                        <SelectItem value="HelpCircle">Ajuda</SelectItem>
                        <SelectItem value="Headphones">Fones</SelectItem>
                        <SelectItem value="FileText">Arquivo</SelectItem>
                        <SelectItem value="TrendingUp">Gráfico</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="enabled"
                      checked={formData.enabled}
                      onCheckedChange={(checked) => setFormData({ ...formData, enabled: checked })}
                    />
                    <Label htmlFor="enabled">Ativar</Label>
                  </div>
                </div>
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Nome da ferramenta"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrição da ferramenta"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="link">Link</Label>
                  <Input
                    id="link"
                    value={formData.link}
                    onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                    placeholder="https://exemplo.com/ferramenta"
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-orange-600 hover:bg-orange-700">
                  Criar Ferramenta
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tools List */}
      <div className="grid gap-4">
        {tools.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Wrench className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma ferramenta encontrada</h3>
              <p className="text-gray-600">Comece criando sua primeira ferramenta.</p>
            </CardContent>
          </Card>
        ) : (
          tools.map((tool: Tool) => (
            <Card key={tool.id} className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                    <Wrench className="h-6 w-6 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-semibold text-gray-900">{tool.title}</h3>
                        <Badge variant={tool.enabled ? "default" : "secondary"}>
                          {tool.enabled ? "Ativa" : "Inativa"}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => window.open(tool.link, "_blank")}>
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => startEdit(tool)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteTool(tool.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-gray-600 mb-3">{tool.description}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>Criada em: {new Date(tool.created_at).toLocaleDateString("pt-BR")}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingTool} onOpenChange={() => setEditingTool(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Ferramenta</DialogTitle>
            <DialogDescription>Faça as alterações necessárias na ferramenta.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdateTool}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-icon">Ícone</Label>
                  <Select value={formData.icon} onValueChange={(value) => setFormData({ ...formData, icon: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um ícone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Calculator">Calculadora</SelectItem>
                      <SelectItem value="Box">Caixa</SelectItem>
                      <SelectItem value="HelpCircle">Ajuda</SelectItem>
                      <SelectItem value="Headphones">Fones</SelectItem>
                      <SelectItem value="FileText">Arquivo</SelectItem>
                      <SelectItem value="TrendingUp">Gráfico</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-enabled"
                    checked={formData.enabled}
                    onCheckedChange={(checked) => setFormData({ ...formData, enabled: checked })}
                  />
                  <Label htmlFor="edit-enabled">Ativar</Label>
                </div>
              </div>
              <div>
                <Label htmlFor="edit-title">Título</Label>
                <Input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Nome da ferramenta"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Descrição</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descrição da ferramenta"
                  required
                />
              </div>
              <div>
                <Label htmlFor="edit-link">Link</Label>
                <Input
                  id="edit-link"
                  value={formData.link}
                  onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                  placeholder="https://exemplo.com/ferramenta"
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingTool(null)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-orange-600 hover:bg-orange-700">
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Support Section
function SupportSection({ tickets, setTickets, onRefresh }: any) {
  const [selectedTicket, setSelectedTicket] = useState<TicketType | null>(null)
  const [response, setResponse] = useState("")

  const handleUpdateTicketStatus = async (id: number, status: string) => {
    try {
      await api.updateTicket(id, { status })
      toast({
        title: "Status atualizado!",
        description: "O status do ticket foi alterado com sucesso.",
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao atualizar status",
        description: "Não foi possível atualizar o status. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const handleRespondTicket = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedTicket || !response.trim()) return

    try {
      await api.updateTicket(selectedTicket.id, {
        status: "answered",
        response: response.trim(),
      })
      toast({
        title: "Resposta enviada!",
        description: "A resposta foi enviada ao usuário.",
      })
      setSelectedTicket(null)
      setResponse("")
      onRefresh()
    } catch (error) {
      toast({
        title: "Erro ao enviar resposta",
        description: "Não foi possível enviar a resposta. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return <Badge className="bg-yellow-100 text-yellow-700">Aberto</Badge>
      case "answered":
        return <Badge className="bg-blue-100 text-blue-700">Respondido</Badge>
      case "closed":
        return <Badge className="bg-green-100 text-green-700">Fechado</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Suporte</h2>
          <p className="text-gray-600">
            Total: {tickets.length} tickets ({tickets.filter((t: TicketType) => t.status === "open").length} abertos)
          </p>
        </div>
      </div>

      {/* Tickets List */}
      <div className="grid gap-4">
        {tickets.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Headphones className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum ticket encontrado</h3>
              <p className="text-gray-600">Não há tickets de suporte no momento.</p>
            </CardContent>
          </Card>
        ) : (
          tickets.map((ticket: TicketType) => (
            <Card key={ticket.id} className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    {getStatusBadge(ticket.status)}
                    <Badge variant="outline" className="capitalize">
                      {ticket.category}
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    {ticket.status === "open" && (
                      <Button variant="outline" size="sm" onClick={() => setSelectedTicket(ticket)}>
                        Responder
                      </Button>
                    )}
                    <Select value={ticket.status} onValueChange={(value) => handleUpdateTicketStatus(ticket.id, value)}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Aberto</SelectItem>
                        <SelectItem value="answered">Respondido</SelectItem>
                        <SelectItem value="closed">Fechado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{ticket.subject}</h3>
                <p className="text-gray-600 mb-3">{ticket.description}</p>
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                  <span>Por: {ticket.user_name}</span>
                  <span>Em: {new Date(ticket.created_at).toLocaleDateString("pt-BR")}</span>
                </div>
                {ticket.response && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                    <p className="text-sm font-medium text-blue-700 mb-1">Resposta:</p>
                    <p className="text-sm text-gray-800">{ticket.response}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Response Dialog */}
      <Dialog open={!!selectedTicket} onOpenChange={() => setSelectedTicket(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Responder Ticket</DialogTitle>
            <DialogDescription>
              Ticket de {selectedTicket?.user_name}: {selectedTicket?.subject}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="mb-4 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-800">{selectedTicket?.description}</p>
            </div>
            <form onSubmit={handleRespondTicket}>
              <div className="grid gap-4">
                <div>
                  <Label htmlFor="response">Sua Resposta</Label>
                  <Textarea
                    id="response"
                    value={response}
                    onChange={(e) => setResponse(e.target.value)}
                    placeholder="Digite sua resposta aqui..."
                    className="min-h-[120px]"
                    required
                  />
                </div>
              </div>
              <DialogFooter className="mt-4">
                <Button type="button" variant="outline" onClick={() => setSelectedTicket(null)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-red-600 hover:bg-red-700">
                  Enviar Resposta
                </Button>
              </DialogFooter>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Analytics Section
function AnalyticsSection({ stats }: any) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Analytics</h2>
        <p className="text-gray-600">Visão geral das métricas da plataforma</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Taxa de Publicação</p>
                <p className="text-2xl font-bold text-blue-600">
                  {stats.totalTips > 0 ? Math.round((stats.publishedTips / stats.totalTips) * 100) : 0}%
                </p>
                <p className="text-sm text-gray-500">
                  {stats.publishedTips} de {stats.totalTips} dicas
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                <Lightbulb className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Estudantes Ativos</p>
                <p className="text-2xl font-bold text-green-600">
                  {stats.totalStudents > 0 ? Math.round((stats.activeStudents / stats.totalStudents) * 100) : 0}%
                </p>
                <p className="text-sm text-gray-500">
                  {stats.activeStudents} de {stats.totalStudents} estudantes
                </p>
              </div>
              <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ferramentas Ativas</p>
                <p className="text-2xl font-bold text-orange-600">
                  {stats.totalTools > 0 ? Math.round((stats.enabledTools / stats.totalTools) * 100) : 0}%
                </p>
                <p className="text-sm text-gray-500">
                  {stats.enabledTools} de {stats.totalTools} ferramentas
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                <Wrench className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Tickets Resolvidos</p>
                <p className="text-2xl font-bold text-purple-600">
                  {stats.totalTickets > 0
                    ? Math.round(((stats.totalTickets - stats.openTickets) / stats.totalTickets) * 100)
                    : 0}
                  %
                </p>
                <p className="text-sm text-gray-500">
                  {stats.totalTickets - stats.openTickets} de {stats.totalTickets} tickets
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                <Headphones className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Distribution */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Distribuição de Conteúdo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Dicas Publicadas</span>
              <span className="text-sm text-gray-500">{stats.publishedTips}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Links de Produtos</span>
              <span className="text-sm text-gray-500">{stats.totalProducts}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Comunidades</span>
              <span className="text-sm text-gray-500">{stats.totalCommunities}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Ferramentas Ativas</span>
              <span className="text-sm text-gray-500">{stats.enabledTools}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Configurações Section
function ConfiguracoesSection() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Configurações</h2>
        <p className="text-gray-600">Configurações gerais da plataforma</p>
      </div>

      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Configurações do Sistema</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Banco de Dados</h3>
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={() => window.open("/setup-database", "_blank")}
                  className="border-blue-300 text-blue-700 hover:bg-blue-50"
                >
                  <Database className="h-4 w-4 mr-2" />
                  Configurar Banco
                </Button>
                <Button
                  variant="outline"
                  onClick={() => window.open("/diagnostics", "_blank")}
                  className="border-gray-300"
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Diagnósticos
                </Button>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Acesso Rápido</h3>
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={() => window.open("/aluno", "_blank")}
                  className="border-green-300 text-green-700 hover:bg-green-50"
                >
                  <EyeOff className="h-4 w-4 mr-2" />
                  Portal do Aluno
                </Button>
                <Button variant="outline" onClick={() => window.location.reload()} className="border-gray-300">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Recarregar Página
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
