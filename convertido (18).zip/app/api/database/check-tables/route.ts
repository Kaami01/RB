import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET() {
  try {
    // Verificar se a tabela users existe e suas colunas
    const tableExists = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'users'
      )
    `

    if (!tableExists[0].exists) {
      return NextResponse.json({
        success: false,
        message: "Tabela users não existe",
        action: "Execute o script 005-create-users-table-complete.sql",
      })
    }

    // Verificar colunas da tabela users
    const columns = await sql`
      SELECT column_name, data_type, is_nullable 
      FROM information_schema.columns 
      WHERE table_name = 'users' 
      ORDER BY ordinal_position
    `

    // Verificar se todas as colunas necessárias existem
    const requiredColumns = ["id", "name", "email", "password_hash", "role", "status", "created_at"]
    const existingColumns = columns.map((col: any) => col.column_name)
    const missingColumns = requiredColumns.filter((col) => !existingColumns.includes(col))

    // Contar registros
    const userCount = await sql`SELECT COUNT(*) as count FROM users`
    const studentCount = await sql`SELECT COUNT(*) as count FROM users WHERE role = 'aluno'`

    return NextResponse.json({
      success: missingColumns.length === 0,
      table_exists: true,
      columns: columns,
      missing_columns: missingColumns,
      total_users: userCount[0].count,
      total_students: studentCount[0].count,
      message:
        missingColumns.length === 0
          ? "Tabela users está configurada corretamente"
          : `Colunas faltando: ${missingColumns.join(", ")}`,
    })
  } catch (error) {
    console.error("Error checking tables:", error)
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    })
  }
}
