import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { sendEmail, createPasswordResetTemplate } from "@/lib/email"
import { generateRandomPassword, hashPassword } from "@/lib/password"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const student = await sql.query("SELECT * FROM users WHERE id = $1 AND role = $2", [params.id, "aluno"])

    if (student.length === 0) {
      return NextResponse.json({ error: "Student not found" }, { status: 404 })
    }

    const { password_hash, ...studentData } = student[0]
    return NextResponse.json(studentData)
  } catch (error) {
    console.error("Error fetching student:", error)
    return NextResponse.json({ error: "Failed to fetch student" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { name, email, phone, status, reset_password } = body

    // Verificar se o estudante existe
    const existingStudent = await sql.query("SELECT * FROM users WHERE id = $1 AND role = $2", [params.id, "aluno"])

    if (existingStudent.length === 0) {
      return NextResponse.json({ error: "Student not found" }, { status: 404 })
    }

    let updateQuery = `
      UPDATE users 
      SET name = $1, email = $2, phone = $3, status = $4, updated_at = NOW()
      WHERE id = $5 AND role = $6
      RETURNING *
    `
    const params_list = [name, email, phone, status, params.id, "aluno"]

    // Se solicitado reset de senha
    let newPassword = null
    if (reset_password) {
      newPassword = generateRandomPassword(12)
      const hashedPassword = await hashPassword(newPassword)

      updateQuery = `
        UPDATE users 
        SET name = $1, email = $2, phone = $3, status = $4, password_hash = $7, updated_at = NOW()
        WHERE id = $5 AND role = $6
        RETURNING *
      `
      params_list.push(hashedPassword)
    }

    const updatedStudent = await sql.query(updateQuery, params_list)
    const student = updatedStudent[0]

    // Enviar email com nova senha se foi resetada
    if (reset_password && newPassword) {
      const loginUrl = `${process.env.NEXT_PUBLIC_APP_URL}/aluno`

      const emailHtml = createPasswordResetTemplate({
        name: student.name,
        newPassword,
        loginUrl,
      })

      await sendEmail({
        to: student.email,
        subject: "🔐 Nova senha - R2B Academy",
        html: emailHtml,
      })
    }

    const { password_hash, ...studentData } = student

    return NextResponse.json({
      ...studentData,
      new_password: reset_password ? newPassword : undefined,
    })
  } catch (error) {
    console.error("Error updating student:", error)
    return NextResponse.json({ error: "Failed to update student" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const deletedStudent = await sql.query("DELETE FROM users WHERE id = $1 AND role = $2 RETURNING *", [
      params.id,
      "aluno",
    ])

    if (deletedStudent.length === 0) {
      return NextResponse.json({ error: "Student not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Student deleted successfully" })
  } catch (error) {
    console.error("Error deleting student:", error)
    return NextResponse.json({ error: "Failed to delete student" }, { status: 500 })
  }
}
