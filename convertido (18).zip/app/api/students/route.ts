import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { sendEmail, createWelcomeEmailTemplate } from "@/lib/email"
import { generateRandomPassword, hashPassword } from "@/lib/password"

// Função para validar CPF
function isValidCPF(cpf: string): boolean {
  if (!cpf) return true // CPF é opcional

  // Remove caracteres não numéricos
  const cleanCPF = cpf.replace(/[^\d]/g, "")

  // Verifica se tem 11 dígitos
  if (cleanCPF.length !== 11) {
    return false
  }

  // Verifica se todos os dígitos são iguais
  if (/^(\d)\1{10}$/.test(cleanCPF)) {
    return false
  }

  // Validação do algoritmo do CPF
  let sum = 0
  for (let i = 0; i < 9; i++) {
    sum += Number.parseInt(cleanCPF.charAt(i)) * (10 - i)
  }
  let remainder = (sum * 10) % 11
  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== Number.parseInt(cleanCPF.charAt(9))) {
    return false
  }

  sum = 0
  for (let i = 0; i < 10; i++) {
    sum += Number.parseInt(cleanCPF.charAt(i)) * (11 - i)
  }
  remainder = (sum * 10) % 11
  if (remainder === 10 || remainder === 11) remainder = 0
  if (remainder !== Number.parseInt(cleanCPF.charAt(10))) {
    return false
  }

  return true
}

// Função para verificar se uma coluna existe na tabela
async function columnExists(tableName: string, columnName: string): Promise<boolean> {
  try {
    const result = await sql`
      SELECT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = ${tableName}
        AND column_name = ${columnName}
      ) as exists
    `
    return result[0]?.exists || false
  } catch (error) {
    console.error(`Error checking if column ${columnName} exists in ${tableName}:`, error)
    return false
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const status = searchParams.get("status")

    console.log("GET /api/students - Fetching students with filters:", { search, status })

    // Verificar se a tabela existe
    const tableExists = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'users'
      )
    `

    if (!tableExists[0].exists) {
      console.log("Table 'users' does not exist")
      return NextResponse.json([])
    }

    // Verificar quais colunas existem
    const hasRole = await columnExists("users", "role")
    const hasCpf = await columnExists("users", "cpf")
    const hasStatus = await columnExists("users", "status")
    const hasPhone = await columnExists("users", "phone")
    const hasBirthDate = await columnExists("users", "birth_date")
    const hasAddress = await columnExists("users", "street")

    console.log("Column existence check:", { hasRole, hasCpf, hasStatus, hasPhone, hasBirthDate, hasAddress })

    // Construir lista de colunas dinamicamente
    let columns = "id, email, name"
    if (hasPhone) columns += ", phone"
    if (hasCpf) columns += ", cpf"
    if (hasBirthDate) columns += ", birth_date"
    if (hasAddress) columns += ", cep, street, number, complement, neighborhood, city, state, country"
    if (hasStatus) columns += ", status"
    columns += ", created_at, updated_at"

    // Construir query base
    let baseQuery = `
      SELECT ${columns}
      FROM users
    `

    // Adicionar filtro de role se a coluna existir
    if (hasRole) {
      baseQuery += ` WHERE role = 'aluno'`
    }

    const params: any[] = []
    let paramIndex = 1
    let whereOrAnd = hasRole ? "AND" : "WHERE"

    // Adicionar filtro de busca
    if (search) {
      baseQuery += ` ${whereOrAnd} (name ILIKE $${paramIndex} OR email ILIKE $${paramIndex + 1}`
      params.push(`%${search}%`, `%${search}%`)
      paramIndex += 2

      // Adicionar busca por CPF se a coluna existir
      if (hasCpf && search.replace(/[^\d]/g, "").length > 0) {
        baseQuery += ` OR cpf ILIKE $${paramIndex}`
        params.push(`%${search.replace(/[^\d]/g, "")}%`)
        paramIndex++
      }

      baseQuery += `)`
      whereOrAnd = "AND"
    }

    // Adicionar filtro de status se a coluna existir
    if (hasStatus && status && status !== "all") {
      baseQuery += ` ${whereOrAnd} status = $${paramIndex}`
      params.push(status)
      paramIndex++
    }

    // Adicionar ordenação
    baseQuery += ` ORDER BY created_at DESC`

    console.log("Query final:", baseQuery)
    console.log("Params:", params)

    const students = params.length > 0 ? await sql.query(baseQuery, params) : await sql.query(baseQuery)

    console.log(`Found ${students.length} students`)
    return NextResponse.json(students)
  } catch (error) {
    console.error("Error fetching students:", error)
    return NextResponse.json({ error: "Failed to fetch students" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  console.log("POST /api/students - Starting student creation")

  try {
    const body = await request.json()
    console.log("Received request body:", JSON.stringify(body, null, 2))

    const {
      name,
      email,
      phone,
      cpf,
      birth_date,
      cep,
      street,
      number,
      complement,
      neighborhood,
      city,
      state,
      status = "active",
      send_email = true,
    } = body

    // Validar dados obrigatórios
    if (!name || !email) {
      console.log("Validation failed: Missing required fields")
      return NextResponse.json({ error: "Nome e email são obrigatórios" }, { status: 400 })
    }

    // Validar CPF se fornecido
    if (cpf && !isValidCPF(cpf)) {
      console.log("Validation failed: Invalid CPF")
      return NextResponse.json({ error: "CPF inválido" }, { status: 400 })
    }

    console.log("Basic validation passed")

    // Verificar se a tabela existe
    const tableExists = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'users'
      )
    `

    if (!tableExists[0].exists) {
      return NextResponse.json({ error: "Database not initialized" }, { status: 500 })
    }

    // Verificar quais colunas existem
    const hasRole = await columnExists("users", "role")
    const hasCpf = await columnExists("users", "cpf")
    const hasStatus = await columnExists("users", "status")
    const hasPhone = await columnExists("users", "phone")
    const hasBirthDate = await columnExists("users", "birth_date")
    const hasAddress = await columnExists("users", "street")

    console.log("Column existence check:", { hasRole, hasCpf, hasStatus, hasPhone, hasBirthDate, hasAddress })

    // Verificar se o email já existe
    console.log("Checking if email exists:", email)
    const existingUser = await sql`SELECT id FROM users WHERE email = ${email}`
    if (existingUser.length > 0) {
      console.log("Email already exists")
      return NextResponse.json({ error: "Email já cadastrado no sistema" }, { status: 400 })
    }

    // Gerar senha aleatória
    const plainPassword = generateRandomPassword(12)
    const hashedPassword = await hashPassword(plainPassword)
    console.log("Password generated and hashed")

    // Construir colunas e valores dinamicamente
    const columns = ["name", "email", "password_hash"]
    const values = [name.trim(), email.trim().toLowerCase(), hashedPassword]
    const placeholders = ["$1", "$2", "$3"]
    let paramIndex = 4

    // Adicionar role se a coluna existir
    if (hasRole) {
      columns.push("role")
      values.push("aluno")
      placeholders.push(`$${paramIndex++}`)
    }

    // Adicionar status se a coluna existir
    if (hasStatus) {
      columns.push("status")
      values.push(status)
      placeholders.push(`$${paramIndex++}`)
    }

    // Adicionar phone se a coluna existir
    if (hasPhone && phone) {
      columns.push("phone")
      values.push(phone)
      placeholders.push(`$${paramIndex++}`)
    }

    // Adicionar cpf se a coluna existir
    if (hasCpf && cpf) {
      columns.push("cpf")
      values.push(cpf.replace(/[^\d]/g, ""))
      placeholders.push(`$${paramIndex++}`)
    }

    // Adicionar birth_date se a coluna existir
    if (hasBirthDate && birth_date) {
      columns.push("birth_date")
      values.push(birth_date)
      placeholders.push(`$${paramIndex++}`)
    }

    // Adicionar campos de endereço se as colunas existirem
    if (hasAddress) {
      if (cep) {
        columns.push("cep")
        values.push(cep.replace(/[^\d]/g, ""))
        placeholders.push(`$${paramIndex++}`)
      }

      if (street) {
        columns.push("street")
        values.push(street)
        placeholders.push(`$${paramIndex++}`)
      }

      if (number) {
        columns.push("number")
        values.push(number)
        placeholders.push(`$${paramIndex++}`)
      }

      if (complement) {
        columns.push("complement")
        values.push(complement)
        placeholders.push(`$${paramIndex++}`)
      }

      if (neighborhood) {
        columns.push("neighborhood")
        values.push(neighborhood)
        placeholders.push(`$${paramIndex++}`)
      }

      if (city) {
        columns.push("city")
        values.push(city)
        placeholders.push(`$${paramIndex++}`)
      }

      if (state) {
        columns.push("state")
        values.push(state)
        placeholders.push(`$${paramIndex++}`)
      }

      columns.push("country")
      values.push("Brasil")
      placeholders.push(`$${paramIndex++}`)
    }

    // Construir a query de inserção
    const insertQuery = `
      INSERT INTO users (${columns.join(", ")})
      VALUES (${placeholders.join(", ")})
      RETURNING id, name, email${hasPhone ? ", phone" : ""}${hasCpf ? ", cpf" : ""}${hasBirthDate ? ", birth_date" : ""}
      ${hasAddress ? ", cep, street, number, complement, neighborhood, city, state, country" : ""}
      ${hasStatus ? ", status" : ""}, created_at, updated_at
    `

    console.log("Insert query:", insertQuery)
    console.log("Insert values:", values)

    // Executar a query
    const result = await sql.query(insertQuery, values)
    const student = result[0]
    console.log("Student created successfully with ID:", student.id)

    // Enviar email de boas-vindas se solicitado
    let emailSent = false
    let emailError = null

    if (send_email) {
      console.log("Attempting to send welcome email...")
      try {
        const loginUrl = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/aluno`

        const emailHtml = createWelcomeEmailTemplate({
          name: student.name,
          email: student.email,
          password: plainPassword,
          loginUrl,
        })

        const emailResult = await sendEmail({
          to: student.email,
          subject: "🎉 Bem-vindo à R2B Academy - Suas credenciais de acesso",
          html: emailHtml,
        })

        emailSent = emailResult.success
        if (!emailResult.success) {
          emailError = emailResult.error
          console.error("Failed to send welcome email:", emailResult.error)
        } else {
          console.log("Welcome email sent successfully")
        }
      } catch (error) {
        console.error("Error sending email:", error)
        emailError = error instanceof Error ? error.message : "Unknown email error"
      }
    }

    // Retornar dados do estudante
    const response = {
      ...student,
      email_sent: emailSent,
      email_error: emailError,
      temporary_password: send_email ? plainPassword : undefined,
    }

    console.log("Returning response:", JSON.stringify(response, null, 2))
    return NextResponse.json(response, { status: 201 })
  } catch (error) {
    console.error("Error creating student - Full error:", error)
    console.error("Error stack:", error instanceof Error ? error.stack : "No stack trace")

    return NextResponse.json(
      {
        error: "Failed to create student",
        details: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
