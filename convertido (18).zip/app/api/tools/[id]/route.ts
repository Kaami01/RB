import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Tool } from "@/lib/db"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const tools = (await sql.query("SELECT * FROM tools WHERE id = $1", [id])) as Tool[]

    if (tools.length === 0) {
      return NextResponse.json({ error: "Tool not found" }, { status: 404 })
    }

    return NextResponse.json(tools[0])
  } catch (error) {
    console.error("Error fetching tool:", error)
    return NextResponse.json({ error: "Failed to fetch tool" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const body = await request.json()
    const { icon, title, description, link, enabled } = body

    // Usando sql.query em vez de sql diretamente
    const tools = (await sql.query(
      "UPDATE tools SET icon = $1, title = $2, description = $3, link = $4, enabled = $5, updated_at = NOW() WHERE id = $6 RETURNING *",
      [icon, title, description, link, enabled, id],
    )) as Tool[]

    if (tools.length === 0) {
      return NextResponse.json({ error: "Tool not found" }, { status: 404 })
    }

    return NextResponse.json(tools[0])
  } catch (error) {
    console.error("Error updating tool:", error)
    return NextResponse.json({ error: "Failed to update tool" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const tools = (await sql.query("DELETE FROM tools WHERE id = $1 RETURNING *", [id])) as Tool[]

    if (tools.length === 0) {
      return NextResponse.json({ error: "Tool not found" }, { status: 404 })
    }

    return NextResponse.json(tools[0])
  } catch (error) {
    console.error("Error deleting tool:", error)
    return NextResponse.json({ error: "Failed to delete tool" }, { status: 500 })
  }
}
