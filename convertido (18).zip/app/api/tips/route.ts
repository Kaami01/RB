import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Tip } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const published = searchParams.get("published")
    const category = searchParams.get("category")

    let query = `SELECT * FROM tips`
    const conditions: string[] = []
    const values: any[] = []

    if (published !== null) {
      conditions.push(`published = $${values.length + 1}`)
      values.push(published === "true")
    }

    if (category && category !== "todos") {
      conditions.push(`category = $${values.length + 1}`)
      values.push(category)
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(" AND ")}`
    }

    query += ` ORDER BY created_at DESC`

    const tips = (await sql.unsafe(query, values)) as Tip[]
    return NextResponse.json(tips)
  } catch (error) {
    console.error("Error fetching tips:", error)
    return NextResponse.json({ error: "Failed to fetch tips" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { category, title, description, content, published } = body

    if (!category || !title || !description) {
      return NextResponse.json(
        {
          error: "Missing required fields: category, title, description",
        },
        { status: 400 },
      )
    }

    const tips = (await sql`
      INSERT INTO tips (category, title, description, content, published)
      VALUES (${category}, ${title}, ${description}, ${content || ""}, ${published || false})
      RETURNING *
    `) as Tip[]

    return NextResponse.json(tips[0], { status: 201 })
  } catch (error) {
    console.error("Error creating tip:", error)
    return NextResponse.json({ error: "Failed to create tip" }, { status: 500 })
  }
}
