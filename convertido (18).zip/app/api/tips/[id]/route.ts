import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Tip } from "@/lib/db"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const tips = (await sql.query("SELECT * FROM tips WHERE id = $1", [id])) as Tip[]

    if (tips.length === 0) {
      return NextResponse.json({ error: "Tip not found" }, { status: 404 })
    }

    return NextResponse.json(tips[0])
  } catch (error) {
    console.error("Error fetching tip:", error)
    return NextResponse.json({ error: "Failed to fetch tip" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const body = await request.json()
    const { category, title, description, content, published } = body

    // Usando sql.query em vez de sql diretamente
    const tips = (await sql.query(
      "UPDATE tips SET category = $1, title = $2, description = $3, content = $4, published = $5, updated_at = NOW() WHERE id = $6 RETURNING *",
      [category, title, description, content, published, id],
    )) as Tip[]

    if (tips.length === 0) {
      return NextResponse.json({ error: "Tip not found" }, { status: 404 })
    }

    return NextResponse.json(tips[0])
  } catch (error) {
    console.error("Error updating tip:", error)
    return NextResponse.json({ error: "Failed to update tip" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const tips = (await sql.query("DELETE FROM tips WHERE id = $1 RETURNING *", [id])) as Tip[]

    if (tips.length === 0) {
      return NextResponse.json({ error: "Tip not found" }, { status: 404 })
    }

    return NextResponse.json(tips[0])
  } catch (error) {
    console.error("Error deleting tip:", error)
    return NextResponse.json({ error: "Failed to delete tip" }, { status: 500 })
  }
}
