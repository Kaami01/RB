import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { hashPassword } from "@/lib/password"

export async function GET() {
  try {
    // Verificar conexão com o banco
    await sql`SELECT 1`

    // Verificar se as tabelas existem
    const tables = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('users', 'tips', 'products', 'communities', 'tools', 'tickets')
      ORDER BY table_name
    `

    const counts = {}
    for (const table of tables) {
      try {
        const result = await sql.unsafe(`SELECT COUNT(*) as count FROM ${table.table_name}`)
        counts[table.table_name] = Number.parseInt(result[0].count)
      } catch (error) {
        counts[table.table_name] = 0
      }
    }

    return NextResponse.json({
      success: true,
      tables: tables.map((t) => t.table_name),
      counts,
      tablesExist: tables.length === 6,
    })
  } catch (error) {
    console.error("Database connection error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        tables: [],
        counts: {},
        tablesExist: false,
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { dataType, data } = body

    if (!data || !Array.isArray(data) || data.length === 0) {
      return NextResponse.json({
        success: true,
        data: { count: 0 },
        message: `No ${dataType} data to migrate`,
      })
    }

    let count = 0

    switch (dataType) {
      case "users":
        count = await migrateUsers(data)
        break
      case "tips":
        count = await migrateTips(data)
        break
      case "products":
        count = await migrateProducts(data)
        break
      case "communities":
        count = await migrateCommunities(data)
        break
      case "tools":
        count = await migrateTools(data)
        break
      case "tickets":
        count = await migrateTickets(data)
        break
      default:
        throw new Error(`Unknown data type: ${dataType}`)
    }

    return NextResponse.json({
      success: true,
      data: { count },
      message: `Successfully migrated ${count} ${dataType} records`,
    })
  } catch (error) {
    console.error(`Migration error:`, error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

async function migrateUsers(users: any[]): Promise<number> {
  let count = 0
  for (const user of users) {
    try {
      // Verificar se o usuário já existe
      const existing = await sql`SELECT id FROM users WHERE email = ${user.email}`
      if (existing.length > 0) {
        console.log(`User ${user.email} already exists, skipping`)
        continue
      }

      // Hash da senha se existir, senão usar uma padrão
      const password_hash = user.password ? await hashPassword(user.password) : await hashPassword("123456")

      await sql`
        INSERT INTO users (
          email, name, role, password_hash, phone, cpf, birth_date, cep, 
          street, number, complement, neighborhood, city, state, country, status
        ) 
        VALUES (
          ${user.email}, ${user.name}, ${user.role || "aluno"}, ${password_hash}, 
          ${user.phone || null}, ${user.cpf || null}, ${user.birth_date || null}, 
          ${user.cep || null}, ${user.street || null}, ${user.number || null}, 
          ${user.complement || null}, ${user.neighborhood || null}, ${user.city || null}, 
          ${user.state || null}, ${user.country || "Brasil"}, ${user.status || "active"}
        )
      `
      count++
    } catch (error) {
      console.error(`Error migrating user ${user.email}:`, error)
    }
  }
  return count
}

async function migrateTips(tips: any[]): Promise<number> {
  let count = 0
  for (const tip of tips) {
    try {
      await sql`
        INSERT INTO tips (category, title, description, content, published) 
        VALUES (
          ${tip.category}, ${tip.title}, ${tip.description}, 
          ${tip.content || null}, ${tip.published || false}
        )
      `
      count++
    } catch (error) {
      console.error(`Error migrating tip ${tip.title}:`, error)
    }
  }
  return count
}

async function migrateProducts(products: any[]): Promise<number> {
  let count = 0
  for (const product of products) {
    try {
      await sql`
        INSERT INTO products (category, store, title, description, price, rating, reviews, image, link) 
        VALUES (
          ${product.category}, ${product.store}, ${product.title}, ${product.description}, 
          ${product.price}, ${product.rating || 5.0}, ${product.reviews || "0"}, 
          ${product.image || null}, ${product.link}
        )
      `
      count++
    } catch (error) {
      console.error(`Error migrating product ${product.title}:`, error)
    }
  }
  return count
}

async function migrateCommunities(communities: any[]): Promise<number> {
  let count = 0
  for (const community of communities) {
    try {
      await sql`
        INSERT INTO communities (icon, title, description, members, online, is_vip) 
        VALUES (
          ${community.icon}, ${community.title}, ${community.description}, 
          ${community.members}, ${community.online}, ${community.is_vip || false}
        )
      `
      count++
    } catch (error) {
      console.error(`Error migrating community ${community.title}:`, error)
    }
  }
  return count
}

async function migrateTools(tools: any[]): Promise<number> {
  let count = 0
  for (const tool of tools) {
    try {
      await sql`
        INSERT INTO tools (icon, title, description, link, enabled) 
        VALUES (
          ${tool.icon}, ${tool.title}, ${tool.description}, 
          ${tool.link}, ${tool.enabled !== false}
        )
      `
      count++
    } catch (error) {
      console.error(`Error migrating tool ${tool.title}:`, error)
    }
  }
  return count
}

async function migrateTickets(tickets: any[]): Promise<number> {
  let count = 0
  for (const ticket of tickets) {
    try {
      await sql`
        INSERT INTO tickets (subject, category, description, status, user_name, user_id, response) 
        VALUES (
          ${ticket.subject}, ${ticket.category}, ${ticket.description}, 
          ${ticket.status || "open"}, ${ticket.user_name}, ${ticket.user_id}, 
          ${ticket.response || null}
        )
      `
      count++
    } catch (error) {
      console.error(`Error migrating ticket ${ticket.subject}:`, error)
    }
  }
  return count
}
