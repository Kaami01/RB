"use client"
import { useState, useEffect } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import {
  Menu,
  X,
  User,
  LogOut,
  Lightbulb,
  ShoppingCart,
  MessageSquare,
  Wrench,
  Headphones,
  Star,
  ExternalLink,
  Crown,
  Users,
  Activity,
  Filter,
  Search,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Clock,
  MessageCircle,
} from "lucide-react"
import * as api from "@/lib/api"

// Tipos para os dados
interface Tip {
  id: number
  category: string
  title: string
  description: string
  content?: string
  published: boolean
  created_at: string
  updated_at: string
}

interface Product {
  id: number
  category: string
  store: string
  title: string
  description: string
  price: string
  rating: number
  reviews: string
  image?: string
  link: string
  created_at: string
  updated_at: string
}

interface Community {
  id: number
  icon: string
  title: string
  description: string
  members: string
  online: string
  is_vip: boolean
  created_at: string
  updated_at: string
}

interface Tool {
  id: number
  icon: string
  title: string
  description: string
  link: string
  enabled: boolean
  created_at: string
  updated_at: string
}

interface TicketType {
  id: number
  subject: string
  category: string
  description: string
  status: string
  created_at: string
  user_name: string
  user_id: string
  response?: string
}

export default function AlunoPortal() {
  const [currentSection, setCurrentSection] = useState("dicas")
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  // Dados
  const [tips, setTips] = useState<Tip[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [communities, setCommunities] = useState<Community[]>([])
  const [tools, setTools] = useState<Tool[]>([])
  const [tickets, setTickets] = useState<TicketType[]>([])

  // Filtros
  const [tipCategory, setTipCategory] = useState("todos")
  const [productCategory, setProductCategory] = useState("todos")
  const [productStore, setProductStore] = useState("todos")
  const [searchTerm, setSearchTerm] = useState("")

  // Support form
  const [supportForm, setSupportForm] = useState({
    subject: "",
    category: "",
    description: "",
  })

  useEffect(() => {
    // Check authentication
    const savedUser = localStorage.getItem("r2b_user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      setUser(userData)
    } else {
      // Redirect to login or set default user
      setUser({
        id: "guest",
        name: "Usuário Convidado",
        email: "guest@example.com",
        role: "aluno",
      })
    }

    loadData()
  }, [])

  const loadData = async () => {
    setIsLoading(true)
    try {
      await Promise.all([loadTips(), loadProducts(), loadCommunities(), loadTools(), loadTickets()])
    } catch (error) {
      console.error("Error loading data:", error)
      toast({
        title: "Erro ao carregar dados",
        description: "Alguns dados podem não estar atualizados.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const loadTips = async () => {
    try {
      const data = await api.fetchTips(true) // Only published tips
      setTips(data)
    } catch (error) {
      console.error("Error loading tips:", error)
      setTips([])
    }
  }

  const loadProducts = async () => {
    try {
      const data = await api.fetchProducts()
      setProducts(data)
    } catch (error) {
      console.error("Error loading products:", error)
      setProducts([])
    }
  }

  const loadCommunities = async () => {
    try {
      const data = await api.fetchCommunities()
      setCommunities(data)
    } catch (error) {
      console.error("Error loading communities:", error)
      setCommunities([])
    }
  }

  const loadTools = async () => {
    try {
      const data = await api.fetchTools(true) // Only enabled tools
      setTools(data)
    } catch (error) {
      console.error("Error loading tools:", error)
      setTools([])
    }
  }

  const loadTickets = async () => {
    if (!user?.id) return
    try {
      const data = await api.fetchTickets(undefined, user.id)
      setTickets(data)
    } catch (error) {
      console.error("Error loading tickets:", error)
      setTickets([])
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("r2b_user")
    window.location.href = "/"
  }

  const createTicket = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!supportForm.subject || !supportForm.category || !supportForm.description) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      })
      return
    }

    try {
      console.log("Creating ticket with user:", user)
      console.log("Support form data:", supportForm)

      const ticketData = {
        subject: supportForm.subject,
        category: supportForm.category,
        description: supportForm.description,
        user_name: user?.name || "Usuário Anônimo",
        user_id: user?.id || "unknown",
        status: "open",
      }

      console.log("Final ticket data:", ticketData)

      await api.createTicket(ticketData)

      toast({
        title: "Ticket criado com sucesso!",
        description: "Sua solicitação foi enviada. Aguarde nossa resposta.",
      })

      setSupportForm({ subject: "", category: "", description: "" })
      loadTickets()
    } catch (error) {
      console.error("Error creating ticket:", error)
      toast({
        title: "Erro ao criar ticket",
        description: "Não foi possível enviar sua solicitação. Tente novamente.",
        variant: "destructive",
      })
    }
  }

  const navItems = [
    { id: "dicas", label: "Dicas de Importação", icon: Lightbulb, color: "yellow" },
    { id: "produtos", label: "Links de Produtos", icon: ShoppingCart, color: "green" },
    { id: "comunidades", label: "Comunidades", icon: MessageSquare, color: "purple" },
    { id: "ferramentas", label: "Ferramentas", icon: Wrench, color: "orange" },
    { id: "suporte", label: "Suporte", icon: Headphones, color: "red" },
  ]

  // Filter functions
  const filteredTips = tips.filter((tip) => {
    const matchesCategory = tipCategory === "todos" || tip.category === tipCategory
    const matchesSearch =
      tip.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tip.description.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const filteredProducts = products.filter((product) => {
    const matchesCategory = productCategory === "todos" || product.category === productCategory
    const matchesStore = productStore === "todos" || product.store === productStore
    const matchesSearch =
      product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesStore && matchesSearch
  })

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-6"></div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Carregando Portal</h2>
          <p className="text-gray-600">Preparando seu conteúdo...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex">
      {/* Sidebar */}
      <div
        className={`${isSidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white shadow-2xl transition-transform duration-300 ease-in-out`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-100 bg-gradient-to-r from-blue-600 to-indigo-600">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg">
                <User className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <span className="font-bold text-xl text-white">R2B Academy</span>
                <p className="text-blue-100 text-sm">Portal do Aluno</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setIsSidebarOpen(false)} className="lg:hidden text-white">
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="p-6 border-b border-gray-100 bg-gray-50">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{tips.length}</div>
                <div className="text-xs text-gray-600">Dicas</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{products.length}</div>
                <div className="text-xs text-gray-600">Produtos</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{communities.length}</div>
                <div className="text-xs text-gray-600">Comunidades</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{tools.length}</div>
                <div className="text-xs text-gray-600">Ferramentas</div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-6 overflow-y-auto">
            <div className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setCurrentSection(item.id)
                      setIsSidebarOpen(false)
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-200 font-medium group ${
                      currentSection === item.id
                        ? "bg-blue-50 text-blue-700 border-2 border-blue-200 shadow-md"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 hover:shadow-sm"
                    }`}
                  >
                    <div
                      className={`p-2 rounded-lg ${
                        currentSection === item.id
                          ? "bg-blue-100"
                          : "bg-gray-100 group-hover:bg-gray-200 transition-colors"
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="flex-1">{item.label}</span>
                    {item.id === "suporte" && tickets.filter((t) => t.status === "open").length > 0 && (
                      <Badge className="bg-red-100 text-red-700 text-xs">
                        {tickets.filter((t) => t.status === "open").length}
                      </Badge>
                    )}
                  </button>
                )
              })}
            </div>
          </nav>

          {/* User Info */}
          <div className="p-6 border-t border-gray-100 bg-gray-50">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
                <User className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 truncate">{user?.name}</p>
                <p className="text-xs text-gray-500 truncate">{user?.email}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={loadData} className="flex-1 border-gray-300 bg-transparent">
                <RefreshCw className="h-4 w-4 mr-2" />
                Atualizar
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout} className="border-gray-300 bg-transparent">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-100">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => setIsSidebarOpen(true)} className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  {navItems.find((item) => item.id === currentSection)?.label}
                </h1>
                <p className="text-gray-600">Bem-vindo ao portal da R2B Academy</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {currentSection === "dicas" && (
            <TipsSection tips={filteredTips} category={tipCategory} setCategory={setTipCategory} />
          )}
          {currentSection === "produtos" && (
            <ProductsSection
              products={filteredProducts}
              category={productCategory}
              setCategory={setProductCategory}
              store={productStore}
              setStore={setProductStore}
            />
          )}
          {currentSection === "comunidades" && <CommunitiesSection communities={communities} />}
          {currentSection === "ferramentas" && <ToolsSection tools={tools} />}
          {currentSection === "suporte" && (
            <SupportSection
              tickets={tickets}
              supportForm={supportForm}
              setSupportForm={setSupportForm}
              onSubmit={createTicket}
            />
          )}
        </main>
      </div>

      {/* Overlay */}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setIsSidebarOpen(false)} />
      )}

      <Toaster />
    </div>
  )
}

// Tips Section
function TipsSection({
  tips,
  category,
  setCategory,
}: {
  tips: Tip[]
  category: string
  setCategory: (category: string) => void
}) {
  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex items-center gap-4">
        <Filter className="h-5 w-5 text-gray-500" />
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtrar por categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas as categorias</SelectItem>
            <SelectItem value="roupas">Roupas</SelectItem>
            <SelectItem value="tenis">Tênis</SelectItem>
            <SelectItem value="perfumes">Perfumes</SelectItem>
            <SelectItem value="eletronicos">Eletrônicos</SelectItem>
            <SelectItem value="acessorios">Acessórios</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-sm text-gray-500">{tips.length} dicas encontradas</span>
      </div>

      {/* Tips Grid */}
      <div className="grid gap-6">
        {tips.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Lightbulb className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma dica encontrada</h3>
              <p className="text-gray-600">Não há dicas disponíveis no momento.</p>
            </CardContent>
          </Card>
        ) : (
          tips.map((tip) => (
            <Card key={tip.id} className="border border-gray-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-yellow-50 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Lightbulb className="h-6 w-6 text-yellow-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className="capitalize">{tip.category}</Badge>
                      <span className="text-sm text-gray-500">
                        {new Date(tip.created_at).toLocaleDateString("pt-BR")}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{tip.title}</h3>
                    <p className="text-gray-600 mb-4">{tip.description}</p>
                    {tip.content && (
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <p className="text-sm text-gray-800">{tip.content}</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}

// Products Section
function ProductsSection({
  products,
  category,
  setCategory,
  store,
  setStore,
}: {
  products: Product[]
  category: string
  setCategory: (category: string) => void
  store: string
  setStore: (store: string) => void
}) {
  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex items-center gap-4 flex-wrap">
        <Filter className="h-5 w-5 text-gray-500" />
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtrar por categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas as categorias</SelectItem>
            <SelectItem value="roupas">Roupas</SelectItem>
            <SelectItem value="tenis">Tênis</SelectItem>
            <SelectItem value="perfumes">Perfumes</SelectItem>
            <SelectItem value="eletronicos">Eletrônicos</SelectItem>
            <SelectItem value="acessorios">Acessórios</SelectItem>
          </SelectContent>
        </Select>
        <Select value={store} onValueChange={setStore}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtrar por loja" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas as lojas</SelectItem>
            <SelectItem value="aliexpress">AliExpress</SelectItem>
            <SelectItem value="amazon">Amazon</SelectItem>
            <SelectItem value="shein">Shein</SelectItem>
            <SelectItem value="temu">Temu</SelectItem>
            <SelectItem value="outros">Outros</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-sm text-gray-500">{products.length} produtos encontrados</span>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.length === 0 ? (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-8 text-center">
                <ShoppingCart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum produto encontrado</h3>
                <p className="text-gray-600">Não há produtos disponíveis no momento.</p>
              </CardContent>
            </Card>
          </div>
        ) : (
          products.map((product) => (
            <Card key={product.id} className="border border-gray-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Product Image */}
                  <div className="w-full h-48 bg-gray-100 rounded-lg overflow-hidden">
                    {product.image ? (
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ShoppingCart className="h-12 w-12 text-gray-400" />
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge className="capitalize">{product.category}</Badge>
                      <Badge variant="outline" className="capitalize">
                        {product.store}
                      </Badge>
                    </div>
                    <h3 className="font-semibold text-gray-900 line-clamp-2">{product.title}</h3>
                    <p className="text-sm text-gray-600 line-clamp-2">{product.description}</p>
                  </div>

                  {/* Price and Rating */}
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-green-600">{product.price}</span>
                    <div className="flex items-center gap-1">
                      <div className="flex text-yellow-400">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`h-4 w-4 ${i < product.rating ? "fill-current" : ""}`} />
                        ))}
                      </div>
                      <span className="text-sm text-gray-500">({product.reviews})</span>
                    </div>
                  </div>

                  {/* Action Button */}
                  <Button className="w-full" onClick={() => window.open(product.link, "_blank")}>
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Ver Produto
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}

// Communities Section
function CommunitiesSection({ communities }: { communities: Community[] }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {communities.length === 0 ? (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-8 text-center">
                <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma comunidade encontrada</h3>
                <p className="text-gray-600">Não há comunidades disponíveis no momento.</p>
              </CardContent>
            </Card>
          </div>
        ) : (
          communities.map((community) => (
            <Card
              key={community.id}
              className={`border-2 hover:shadow-lg transition-all ${
                community.is_vip ? "border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50" : "border-gray-200"
              }`}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="text-4xl">{community.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{community.title}</h3>
                      {community.is_vip && (
                        <Badge className="bg-purple-100 text-purple-700">
                          <Crown className="h-3 w-3 mr-1" />
                          VIP
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-600 mb-4">{community.description}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        <span>{community.members} membros</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Activity className="h-4 w-4 text-green-500" />
                        <span>{community.online} online</span>
                      </div>
                    </div>
                  </div>
                </div>
                <Button className="w-full mt-4" variant={community.is_vip ? "default" : "outline"}>
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Entrar na Comunidade
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}

// Tools Section
function ToolsSection({ tools }: { tools: Tool[] }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.length === 0 ? (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-8 text-center">
                <Wrench className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhuma ferramenta encontrada</h3>
                <p className="text-gray-600">Não há ferramentas disponíveis no momento.</p>
              </CardContent>
            </Card>
          </div>
        ) : (
          tools.map((tool) => (
            <Card key={tool.id} className="border border-gray-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                    <Wrench className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">{tool.title}</h3>
                    <p className="text-sm text-gray-600">{tool.description}</p>
                  </div>
                  <Button className="w-full" onClick={() => window.open(tool.link, "_blank")}>
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Usar Ferramenta
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}

// Support Section
function SupportSection({
  tickets,
  supportForm,
  setSupportForm,
  onSubmit,
}: {
  tickets: TicketType[]
  supportForm: any
  setSupportForm: (form: any) => void
  onSubmit: (e: React.FormEvent) => void
}) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "open":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "answered":
        return <MessageCircle className="h-4 w-4 text-blue-500" />
      case "closed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return <Badge className="bg-yellow-100 text-yellow-700">Aberto</Badge>
      case "answered":
        return <Badge className="bg-blue-100 text-blue-700">Respondido</Badge>
      case "closed":
        return <Badge className="bg-green-100 text-green-700">Fechado</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Create Ticket Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Headphones className="h-5 w-5" />
            Criar Novo Ticket
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="subject">Assunto</Label>
                <Input
                  id="subject"
                  value={supportForm.subject}
                  onChange={(e) => setSupportForm({ ...supportForm, subject: e.target.value })}
                  placeholder="Descreva brevemente o problema"
                  required
                />
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select
                  value={supportForm.category}
                  onValueChange={(value) => setSupportForm({ ...supportForm, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tecnico">Problema Técnico</SelectItem>
                    <SelectItem value="conta">Problema com Conta</SelectItem>
                    <SelectItem value="pagamento">Problema de Pagamento</SelectItem>
                    <SelectItem value="conteudo">Problema com Conteúdo</SelectItem>
                    <SelectItem value="geral">Dúvida Geral</SelectItem>
                    <SelectItem value="sugestao">Sugestão</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={supportForm.description}
                onChange={(e) => setSupportForm({ ...supportForm, description: e.target.value })}
                placeholder="Descreva detalhadamente o problema ou dúvida"
                className="min-h-[120px]"
                required
              />
            </div>
            <Button type="submit" className="w-full">
              <Headphones className="h-4 w-4 mr-2" />
              Enviar Ticket
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Tickets List */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Meus Tickets ({tickets.length})</h3>
        <div className="space-y-4">
          {tickets.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Headphones className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Nenhum ticket encontrado</h3>
                <p className="text-gray-600">Você ainda não criou nenhum ticket de suporte.</p>
              </CardContent>
            </Card>
          ) : (
            tickets.map((ticket) => (
              <Card key={ticket.id} className="border border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(ticket.status)}
                      <div>
                        <h4 className="font-semibold text-gray-900">{ticket.subject}</h4>
                        <p className="text-sm text-gray-500">
                          {new Date(ticket.created_at).toLocaleDateString("pt-BR")} às{" "}
                          {new Date(ticket.created_at).toLocaleTimeString("pt-BR")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(ticket.status)}
                      <Badge variant="outline" className="capitalize">
                        {ticket.category}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4">{ticket.description}</p>
                  {ticket.response && (
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                      <p className="text-sm font-medium text-blue-700 mb-1">Resposta do Suporte:</p>
                      <p className="text-sm text-gray-800">{ticket.response}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
