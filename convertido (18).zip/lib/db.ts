import { neon } from "@neondatabase/serverless"

// Função para validar e criar conexão
function createDatabaseConnection() {
  const databaseUrl = process.env.DATABASE_URL || process.env.NEXT_PUBLIC_DATABASE_URL

  if (!databaseUrl) {
    throw new Error("DATABASE_URL não encontrada nas variáveis de ambiente")
  }

  // Validar formato da URL
  try {
    new URL(databaseUrl)
  } catch (error) {
    throw new Error("DATABASE_URL tem formato inválido")
  }

  return neon(databaseUrl)
}

// Criar conexão com tratamento de erro
export const sql = createDatabaseConnection()

// Função para testar conexão
export async function testConnection() {
  try {
    const result = await sql`SELECT 1 as test`
    return { success: true, message: "Conexão estabelecida com sucesso" }
  } catch (error) {
    console.error("Erro de conexão:", error)
    return {
      success: false,
      message: error instanceof Error ? error.message : "Erro desconhecido",
      error: error,
    }
  }
}

// Função para verificar se uma tabela existe
export async function tableExists(tableName: string): Promise<boolean> {
  try {
    const result = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = ${tableName}
      );
    `
    return result[0]?.exists || false
  } catch (error) {
    console.error(`Erro ao verificar tabela ${tableName}:`, error)
    return false
  }
}

// Tipos para as entidades
export interface Tip {
  id: number
  category: string
  title: string
  description: string
  content?: string
  published: boolean
  created_at: string
  updated_at: string
}

export interface Product {
  id: number
  category: string
  store: string
  title: string
  description: string
  price: string
  rating: number
  reviews: string
  image?: string
  link: string
  created_at: string
  updated_at: string
}

export interface Community {
  id: number
  icon: string
  title: string
  description: string
  members: string
  online: string
  is_vip: boolean
  created_at: string
  updated_at: string
}

export interface Tool {
  id: number
  icon: string
  title: string
  description: string
  link: string
  enabled: boolean
  created_at: string
  updated_at: string
}

export interface Ticket {
  id: number
  subject: string
  category: string
  description: string
  status: string
  created_at: string
  user_name: string
  user_id: string
  response?: string
  updated_at: string
}

export interface Student {
  id: number
  name: string
  email: string
  password_hash: string
  kirvano_customer_id?: string
  kirvano_order_id?: string
  phone?: string
  status: "active" | "inactive" | "pending"
  created_at: string
  updated_at: string
}
