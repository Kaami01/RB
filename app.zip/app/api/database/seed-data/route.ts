import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { hashPassword } from "@/lib/password"

export async function POST(request: NextRequest) {
  console.log("Seeding database with sample data...")

  try {
    // Verificar conexão com o banco
    await sql`SELECT 1`
    console.log("Database connection successful")

    // Limpar dados existentes
    console.log("Clearing existing data...")
    await sql`TRUNCATE users, tips, products, communities, tools, tickets RESTART IDENTITY CASCADE`

    // Criar usuário admin
    console.log("Creating admin user...")
    const adminPasswordHash = await hashPassword("admin123")
    await sql`
      INSERT INTO users (name, email, password_hash, role, status)
      VALUES ('Administrador', 'admin@r2b.com.br', ${adminPasswordHash}, 'admin', 'active')
    `

    // Criar alguns estudantes de exemplo
    console.log("Creating sample students...")
    const studentPasswordHash = await hashPassword("aluno123")
    await sql`
      INSERT INTO users (name, email, password_hash, role, phone, cpf, status)
      VALUES 
        ('João Silva', 'joao@exemplo.com', ${studentPasswordHash}, 'aluno', '(11) 98765-4321', '12345678901', 'active'),
        ('Maria Oliveira', 'maria@exemplo.com', ${studentPasswordHash}, 'aluno', '(21) 98765-4321', '98765432109', 'active'),
        ('Pedro Santos', 'pedro@exemplo.com', ${studentPasswordHash}, 'aluno', '(31) 98765-4321', '45678912345', 'inactive')
    `

    // Criar algumas dicas
    console.log("Creating sample tips...")
    await sql`
      INSERT INTO tips (category, title, description, content, published)
      VALUES 
        ('Tecidos', 'Como Identificar Tecidos de Qualidade', 'Aprenda a identificar tecidos de alta qualidade para importação', 'Conteúdo detalhado sobre identificação de tecidos...', true),
        ('Fornecedores', 'Top 10 Fornecedores Confiáveis', 'Lista dos melhores fornecedores verificados', 'Conteúdo detalhado sobre fornecedores...', true),
        ('Logística', 'Otimizando Custos de Frete', 'Estratégias para reduzir custos de frete internacional', 'Conteúdo detalhado sobre logística...', false)
    `

    // Criar alguns produtos
    console.log("Creating sample products...")
    await sql`
      INSERT INTO products (category, store, title, description, price, rating, reviews, link)
      VALUES 
        ('Tecidos', 'AliExpress', 'Tecido de Algodão Premium', 'Tecido 100% algodão de alta qualidade', 'US$ 5,99/metro', 4.8, '256', 'https://exemplo.com/produto1'),
        ('Acessórios', 'Alibaba', 'Kit de Botões Sortidos', 'Kit com 100 botões de diversos tamanhos e cores', 'US$ 8,50', 4.5, '128', 'https://exemplo.com/produto2'),
        ('Máquinas', '1688', 'Máquina de Costura Industrial', 'Máquina de costura industrial de alta velocidade', 'US$ 299,00', 4.9, '45', 'https://exemplo.com/produto3')
    `

    // Criar algumas comunidades
    console.log("Creating sample communities...")
    await sql`
      INSERT INTO communities (icon, title, description, members, online, is_vip)
      VALUES 
        ('users', 'Importadores Iniciantes', 'Grupo para quem está começando no mundo da importação', '1.2k', '45', false),
        ('zap', 'Experts em Dropshipping', 'Comunidade exclusiva para dropshippers avançados', '850', '32', true),
        ('globe', 'Importadores de Tecidos', 'Grupo focado em importação de tecidos e materiais têxteis', '650', '28', false)
    `

    // Criar algumas ferramentas
    console.log("Creating sample tools...")
    await sql`
      INSERT INTO tools (icon, title, description, link, enabled)
      VALUES 
        ('calculator', 'Calculadora de Impostos', 'Calcule todos os impostos e taxas para sua importação', 'https://exemplo.com/calculadora', true),
        ('search', 'Verificador de Fornecedores', 'Verifique a reputação e confiabilidade de fornecedores', 'https://exemplo.com/verificador', true),
        ('truck', 'Rastreador de Encomendas', 'Acompanhe suas encomendas internacionais', 'https://exemplo.com/rastreador', false)
    `

    // Criar alguns tickets
    console.log("Creating sample tickets...")
    await sql`
      INSERT INTO tickets (subject, category, description, status, user_name, user_id)
      VALUES 
        ('Dúvida sobre impostos', 'Suporte', 'Tenho dúvidas sobre o cálculo de impostos para tecidos', 'open', 'João Silva', '1'),
        ('Problema com acesso', 'Técnico', 'Não consigo acessar a ferramenta de cálculo', 'in_progress', 'Maria Oliveira', '2'),
        ('Sugestão de conteúdo', 'Conteúdo', 'Gostaria de sugerir um tema para próximas dicas', 'resolved', 'Pedro Santos', '3')
    `

    // Verificar se os dados foram inseridos
    console.log("Verifying inserted data...")
    const counts = await sql`
      SELECT 
        (SELECT COUNT(*) FROM users) as users_count,
        (SELECT COUNT(*) FROM tips) as tips_count,
        (SELECT COUNT(*) FROM products) as products_count,
        (SELECT COUNT(*) FROM communities) as communities_count,
        (SELECT COUNT(*) FROM tools) as tools_count,
        (SELECT COUNT(*) FROM tickets) as tickets_count
    `

    console.log("Data inserted successfully:", counts[0])

    return NextResponse.json({
      success: true,
      message: "Sample data inserted successfully",
      counts: counts[0],
    })
  } catch (error) {
    console.error("Error seeding database:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to seed database",
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
