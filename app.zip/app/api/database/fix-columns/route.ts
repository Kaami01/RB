import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function POST() {
  try {
    console.log("Iniciando correção da tabela users...")

    // Verificar se a tabela users existe
    const tableExists = await sql`
      SELECT EXISTS (
        SELECT FROM pg_tables 
        WHERE tablename = 'users'
      ) as exists
    `

    if (!tableExists[0].exists) {
      console.log("Tabela users não existe, criando...")
      await sql`
        CREATE TABLE users (
          id SERIAL PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) UNIQUE NOT NULL,
          password_hash VARCHAR(255) NOT NULL,
          role VARCHAR(50) NOT NULL DEFAULT 'aluno',
          status VARCHAR(50) NOT NULL DEFAULT 'active',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
      `
      console.log("Tabela users criada com sucesso!")
    }

    // Verificar e adicionar colunas necessárias
    const requiredColumns = [
      { name: "role", type: "VARCHAR(50) NOT NULL DEFAULT 'aluno'" },
      { name: "status", type: "VARCHAR(50) NOT NULL DEFAULT 'active'" },
      { name: "phone", type: "VARCHAR(20)" },
      { name: "cpf", type: "VARCHAR(14)" },
      { name: "birth_date", type: "DATE" },
      { name: "cep", type: "VARCHAR(10)" },
      { name: "street", type: "VARCHAR(255)" },
      { name: "number", type: "VARCHAR(20)" },
      { name: "complement", type: "VARCHAR(100)" },
      { name: "neighborhood", type: "VARCHAR(100)" },
      { name: "city", type: "VARCHAR(100)" },
      { name: "state", type: "VARCHAR(2)" },
      { name: "country", type: "VARCHAR(50) DEFAULT 'Brasil'" },
      { name: "created_at", type: "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP" },
      { name: "updated_at", type: "TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP" },
    ]

    // Obter colunas existentes
    const existingColumns = await sql`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users'
    `
    const existingColumnNames = existingColumns.map((col: any) => col.column_name)
    console.log("Colunas existentes:", existingColumnNames)

    // Adicionar colunas ausentes
    const addedColumns = []
    for (const column of requiredColumns) {
      if (!existingColumnNames.includes(column.name)) {
        console.log(`Adicionando coluna ${column.name}...`)
        await sql.query(`ALTER TABLE users ADD COLUMN ${column.name} ${column.type}`)
        addedColumns.push(column.name)
      }
    }

    // Criar índices para os campos principais
    const indices = [
      { name: "idx_users_email", column: "email", unique: true },
      { name: "idx_users_role", column: "role", unique: false },
      { name: "idx_users_status", column: "status", unique: false },
      { name: "idx_users_cpf", column: "cpf", unique: false },
    ]

    // Verificar e criar índices
    const createdIndices = []
    for (const index of indices) {
      const indexExists = await sql.query(`
        SELECT 1 FROM pg_indexes 
        WHERE indexname = '${index.name}'
      `)

      if (indexExists.length === 0 && existingColumnNames.includes(index.column)) {
        console.log(`Criando índice ${index.name}...`)
        const uniqueStr = index.unique ? "UNIQUE" : ""
        await sql.query(`CREATE ${uniqueStr} INDEX ${index.name} ON users(${index.column})`)
        createdIndices.push(index.name)
      }
    }

    // Verificar estrutura final
    const finalColumns = await sql`
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'users' 
      ORDER BY ordinal_position
    `

    return NextResponse.json({
      success: true,
      message: "Estrutura da tabela users corrigida com sucesso!",
      addedColumns,
      createdIndices,
      finalStructure: finalColumns,
    })
  } catch (error) {
    console.error("Erro ao corrigir tabela users:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
