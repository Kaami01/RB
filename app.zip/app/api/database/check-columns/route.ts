import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET() {
  try {
    // Verificar se a tabela users existe
    const tableExists = await sql`
      SELECT EXISTS (
        SELECT FROM pg_tables 
        WHERE tablename = 'users'
      ) as exists
    `

    if (!tableExists[0].exists) {
      return NextResponse.json({
        success: false,
        error: "A tabela 'users' não existe",
        tables: [],
      })
    }

    // Obter todas as colunas da tabela users
    const columns = await sql`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns
      WHERE table_name = 'users'
      ORDER BY ordinal_position
    `

    // Verificar colunas necessárias
    const requiredColumns = [
      "id",
      "name",
      "email",
      "password_hash",
      "role",
      "status",
      "cpf",
      "birth_date",
      "phone",
      "cep",
      "street",
      "number",
      "complement",
      "neighborhood",
      "city",
      "state",
      "country",
    ]

    const missingColumns = requiredColumns.filter((col) => !columns.some((c: any) => c.column_name === col))

    // Contar registros
    const countResult = await sql`SELECT COUNT(*) as count FROM users`
    const recordCount = countResult[0].count

    return NextResponse.json({
      success: true,
      table: "users",
      columns: columns,
      missingColumns: missingColumns,
      recordCount: recordCount,
      hasAllRequiredColumns: missingColumns.length === 0,
    })
  } catch (error) {
    console.error("Error checking columns:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
