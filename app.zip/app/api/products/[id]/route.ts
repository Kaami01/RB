import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Product } from "@/lib/db"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const products = (await sql.query("SELECT * FROM products WHERE id = $1", [id])) as Product[]

    if (products.length === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json(products[0])
  } catch (error) {
    console.error("Error fetching product:", error)
    return NextResponse.json({ error: "Failed to fetch product" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const body = await request.json()
    const { category, store, title, description, price, rating, reviews, image, link } = body

    // Usando sql.query em vez de sql diretamente
    const products = (await sql.query(
      "UPDATE products SET category = $1, store = $2, title = $3, description = $4, price = $5, rating = $6, reviews = $7, image = $8, link = $9, updated_at = NOW() WHERE id = $10 RETURNING *",
      [category, store, title, description, price, rating, reviews, image, link, id],
    )) as Product[]

    if (products.length === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json(products[0])
  } catch (error) {
    console.error("Error updating product:", error)
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const products = (await sql.query("DELETE FROM products WHERE id = $1 RETURNING *", [id])) as Product[]

    if (products.length === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json(products[0])
  } catch (error) {
    console.error("Error deleting product:", error)
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 })
  }
}
