import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { Community } from "@/lib/db"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const communities = (await sql.query("SELECT * FROM communities WHERE id = $1", [id])) as Community[]

    if (communities.length === 0) {
      return NextResponse.json({ error: "Community not found" }, { status: 404 })
    }

    return NextResponse.json(communities[0])
  } catch (error) {
    console.error("Error fetching community:", error)
    return NextResponse.json({ error: "Failed to fetch community" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    const body = await request.json()
    const { icon, title, description, members, online, is_vip } = body

    // Usando sql.query em vez de sql diretamente
    const communities = (await sql.query(
      "UPDATE communities SET icon = $1, title = $2, description = $3, members = $4, online = $5, is_vip = $6, updated_at = NOW() WHERE id = $7 RETURNING *",
      [icon, title, description, members, online, is_vip, id],
    )) as Community[]

    if (communities.length === 0) {
      return NextResponse.json({ error: "Community not found" }, { status: 404 })
    }

    return NextResponse.json(communities[0])
  } catch (error) {
    console.error("Error updating community:", error)
    return NextResponse.json({ error: "Failed to update community" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id
    // Usando sql.query em vez de sql diretamente
    const communities = (await sql.query("DELETE FROM communities WHERE id = $1 RETURNING *", [id])) as Community[]

    if (communities.length === 0) {
      return NextResponse.json({ error: "Community not found" }, { status: 404 })
    }

    return NextResponse.json(communities[0])
  } catch (error) {
    console.error("Error deleting community:", error)
    return NextResponse.json({ error: "Failed to delete community" }, { status: 500 })
  }
}
