// Funções utilitárias para fazer chamadas à API

export async function fetchTips(published?: boolean, category?: string) {
  const params = new URLSearchParams()
  if (published !== undefined) params.append("published", published.toString())
  if (category && category !== "todos") params.append("category", category)

  const response = await fetch(`/api/tips?${params}`)
  if (!response.ok) throw new Error("Failed to fetch tips")
  return response.json()
}

export async function createTip(tip: any) {
  const response = await fetch("/api/tips", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(tip),
  })
  if (!response.ok) throw new Error("Failed to create tip")
  return response.json()
}

export async function updateTip(id: number, tip: any) {
  const response = await fetch(`/api/tips/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(tip),
  })
  if (!response.ok) throw new Error("Failed to update tip")
  return response.json()
}

export async function deleteTip(id: number) {
  const response = await fetch(`/api/tips/${id}`, {
    method: "DELETE",
  })
  if (!response.ok) throw new Error("Failed to delete tip")
  return response.json()
}

export async function fetchProducts(category?: string, store?: string) {
  const params = new URLSearchParams()
  if (category && category !== "todos") params.append("category", category)
  if (store && store !== "todos") params.append("store", store)

  const response = await fetch(`/api/products?${params}`)
  if (!response.ok) throw new Error("Failed to fetch products")
  return response.json()
}

export async function createProduct(product: any) {
  const response = await fetch("/api/products", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product),
  })
  if (!response.ok) throw new Error("Failed to create product")
  return response.json()
}

export async function updateProduct(id: number, product: any) {
  const response = await fetch(`/api/products/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(product),
  })
  if (!response.ok) throw new Error("Failed to update product")
  return response.json()
}

export async function deleteProduct(id: number) {
  const response = await fetch(`/api/products/${id}`, {
    method: "DELETE",
  })
  if (!response.ok) throw new Error("Failed to delete product")
  return response.json()
}

export async function fetchCommunities() {
  const response = await fetch("/api/communities")
  if (!response.ok) throw new Error("Failed to fetch communities")
  return response.json()
}

export async function createCommunity(community: any) {
  const response = await fetch("/api/communities", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(community),
  })
  if (!response.ok) throw new Error("Failed to create community")
  return response.json()
}

export async function updateCommunity(id: number, community: any) {
  const response = await fetch(`/api/communities/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(community),
  })
  if (!response.ok) throw new Error("Failed to update community")
  return response.json()
}

export async function deleteCommunity(id: number) {
  const response = await fetch(`/api/communities/${id}`, {
    method: "DELETE",
  })
  if (!response.ok) throw new Error("Failed to delete community")
  return response.json()
}

export async function fetchTools(enabled?: boolean) {
  const params = new URLSearchParams()
  if (enabled !== undefined) params.append("enabled", enabled.toString())

  const response = await fetch(`/api/tools?${params}`)
  if (!response.ok) throw new Error("Failed to fetch tools")
  return response.json()
}

export async function createTool(tool: any) {
  const response = await fetch("/api/tools", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(tool),
  })
  if (!response.ok) throw new Error("Failed to create tool")
  return response.json()
}

export async function updateTool(id: number, tool: any) {
  const response = await fetch(`/api/tools/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(tool),
  })
  if (!response.ok) throw new Error("Failed to update tool")
  return response.json()
}

export async function deleteTool(id: number) {
  const response = await fetch(`/api/tools/${id}`, {
    method: "DELETE",
  })
  if (!response.ok) throw new Error("Failed to delete tool")
  return response.json()
}

export async function fetchTickets(status?: string, user_id?: string) {
  const params = new URLSearchParams()
  if (status && status !== "all") params.append("status", status)
  if (user_id) params.append("user_id", user_id)

  const response = await fetch(`/api/tickets?${params}`)
  if (!response.ok) throw new Error("Failed to fetch tickets")
  return response.json()
}

export async function createTicket(ticket: any) {
  const response = await fetch("/api/tickets", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(ticket),
  })
  if (!response.ok) throw new Error("Failed to create ticket")
  return response.json()
}

export async function updateTicket(id: number, ticket: any) {
  const response = await fetch(`/api/tickets/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(ticket),
  })
  if (!response.ok) throw new Error("Failed to update ticket")
  return response.json()
}

export async function deleteTicket(id: number) {
  const response = await fetch(`/api/tickets/${id}`, {
    method: "DELETE",
  })
  if (!response.ok) throw new Error("Failed to delete ticket")
  return response.json()
}
